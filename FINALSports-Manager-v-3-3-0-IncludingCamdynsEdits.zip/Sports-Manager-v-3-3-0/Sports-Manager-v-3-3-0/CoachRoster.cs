﻿/*
    Authors: Hamza, Ed, Nick, Camdyn, Kenyang, and Soham
    Date: 7:44 PM 11/4/2024
    Purpose: Defines the interface of the coach roster
*/

using Microsoft.Extensions.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class CoachRoster : Form
    {
        private ProgDB context; // creates a new DB "session"

        // initialize the roster: display the coaches
        public CoachRoster()
        {
            InitializeComponent();
            context = new ProgDB();
            context.Database.EnsureCreated(); // does the DB exists?
            load_coaches(); // load/display the coaches
        }

    //-------------- Add, Update, & Delete Coaches -------------------------------------------------

        // adds a coach to the roster via the info card
        private void add_coach(object sender, EventArgs e)
        {
            var win = new Form { Text = "Add a New Coach" }; // new window
            var card = new Ch_info_card { Dock = DockStyle.Fill }; // new info card
            win.ClientSize = card.Size; // match window & card sizes
            win.Controls.Add(card);
            win.Show();

            win.FormClosed += (s, args) => { // reload the roster upon closing
                load_coaches();
            };
        }

        // deletes the selected coach from the roster
        private void del_coach(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) { // none selected
                MessageBox.Show("Error: a coach hasn't been selected");
            }
            else {
                var select = coach_by_id(listBox1); // get coach by id
                if (select != null) {
                    context.Coachs.Remove(select); // delete them
                    context.SaveChanges();
                }
                load_coaches();
            }
        }

        // edits the "double clicked" coach from the roster
        private void edit_coach(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) { // none selected
                return;
            }

            var select = coach_by_id(listBox1); // get coach by id
            if (select != null) {
                var win = new Form { Text = "Edit a Coach"}; // new window
                var card = new Ch_info_card { Dock = DockStyle.Fill }; // new info card
                win.ClientSize = card.Size; // match window & card sizes

                card.fill_fields(select); // fill in the fields
                win.Controls.Add(card);
                win.Show();

                win.FormClosed += (s, args) => { // reload the roster upon closing
                    context.SaveChanges();
                    load_coaches();
                };
            }
        }

    //-------------- Utility Functions -------------------------------------------------------------

        // refresh the roster size
        private void load_size()
        {
            label1.Text = $"Roster size: {listBox1.Items.Count.ToString()}";
        }

        // load the coach roster
        private void load_coaches()
        {
            listBox1.Items.Clear(); // clear the roster
            context.SaveChanges();

            var chs = context.Coachs.ToList(); // load coaches from the DB
            foreach (var x in chs) { // add them as sequential "columns"
                string num = (x.id.ToString() + '.').PadRight(4);
                string first = x.first_name.PadRight(12), last = x.last_name.PadRight(11);
                string age = x.age.ToString().PadRight(5), pos = x.position.PadRight(10);
                listBox1.Items.Add($"{num}{first}{last}{age}{pos}");
            }
            load_size();
        }

        // data validation
        private bool is_valid_coach(Coach x)
        {
            return x.id != 0 && x.first_name != "" && x.last_name != "";
        }

        // get a coach by id given a roster
        private Coach coach_by_id(ListBox x)
        {
            string row = x.SelectedItem.ToString(); // the selected row
            int id = Int32.Parse(row.Substring(0, row.IndexOf('.'))); // extract the id
            var target = context.Coachs.SingleOrDefault(a => a.id == id); // get coach by id
            return target;
        }
    }
}
