﻿/*
    Authors: Hamza, Ed, Nick, Camdyn, Kenyang, and Soham
    Date: 7:44 PM 11/4/2024
    Purpose: Defines the interface of the athlete roster
*/

using Microsoft.Extensions.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;

namespace SportsManagement_Dashboard
{
    public partial class AthleteRoster : Form
    {
        private ProgDB context; // creates a new DB "session"

        // initialize the roster: display the athletes
        public AthleteRoster()
        {
            InitializeComponent();
            context = new ProgDB();
            context.Database.EnsureCreated(); // does the DB exists?
            load_aths(); // load/display the athletes
        }

    //-------------- Add, Update, & Delete Athletes ------------------------------------------------

        // adds a athlete to the roster via the info card
        private void add_ath(object sender, EventArgs e)
        {
            var win = new Form {Text = "Add a New Athlete"}; // new window
            var card = new Ath_info_card {Dock = DockStyle.Fill}; // new info card
            win.ClientSize = card.Size; // match window & card sizes
            win.Controls.Add(card);
            win.Show();

            win.FormClosed += (s, args) => { // reload the roster upon closing
                load_aths();
            };
        }

        // deletes the selected coach from the roster
        private void del_ath(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) { // none selected
                MessageBox.Show("Error: a athlete hasn't been selected");
            }
            else {
                var select = ath_by_id(listBox1); // get athlete by id
                if (select != null) {
                    context.Athletes.Remove(select); // delete them
                    context.SaveChanges();
                }
                load_aths();
            }
        }

        // edits the "double clicked" athlete from the roster
        private void edit_ath(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            { // none selected
                return;
            }

            var select = ath_by_id(listBox1); // get athlete by id
            if (select != null)
            {
                var win = new Form { Text = "Edit an Athlete" }; // new window
                var card = new Ath_info_card { Dock = DockStyle.Fill }; // new info card
                win.ClientSize = card.Size; // match window & card sizes

                card.fill_fields(select); // fill in the fields
                win.Controls.Add(card);
                win.Show();

                win.FormClosed += (s, args) => { // reload the roster upon closing
                    context.SaveChanges();
                    load_aths();
                };
            }
        }

    //-------------- Utility Functions -------------------------------------------------------------

        // "refreshes" the roster size
        private void load_size()
        {
            // overwrite the GUI label with the new size
            label1.Text = "Roster size: " + listBox1.Items.Count.ToString();
        }

        /* Load/"refresh" the athlete roster. The athletes are a sequence of strings with padding 
         * consisting of spaces so that the "columns" may align, hence, don't change the font. There
         * probably is a better solution "out there"; however, time is limited. */
        private void load_aths()
        {
            listBox1.Items.Clear(); // clear the list box

            context.SaveChanges();
            var athletes = context.Athletes.ToList(); // load athletes from the DB
            foreach (var x in athletes) { // add athletes to the roster as sequential "columns"
                string num = (x.id.ToString() + '.').PadRight(4);
                string first = x.first_name.PadRight(12), last = x.last_name.PadRight(11);
                string age = x.age.ToString().PadRight(5), pos = x.position.PadRight(10);
                listBox1.Items.Add($"{num}{first}{last}{age}{pos}");
            }
            load_size(); // "refresh" the roster size
        }

        // get a athlete by id given a roster
        private Athlete ath_by_id(ListBox x)
        {
            string row = x.SelectedItem.ToString(); // the selected row
            int id = Int32.Parse(row.Substring(0, row.IndexOf('.'))); // extract the id
            var selection = context.Athletes.SingleOrDefault(a => a.id == id); // get coach by id
            return selection;
        }
    }
}
