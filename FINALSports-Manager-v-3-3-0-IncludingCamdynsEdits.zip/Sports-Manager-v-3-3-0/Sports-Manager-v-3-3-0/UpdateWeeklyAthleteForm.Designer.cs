﻿namespace SportsManagement_Dashboard
{
    partial class UpdateWeeklyAthleteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbAthletes = new System.Windows.Forms.ComboBox();
            this.txtAccomplishments = new System.Windows.Forms.TextBox();
            this.btnAddWeeklyAthleteInfo = new System.Windows.Forms.Button();
            this.cmbDeleteAthlete = new System.Windows.Forms.ComboBox();
            this.btnDeleteWeeklyAthlete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmbAthletes
            // 
            this.cmbAthletes.FormattingEnabled = true;
            this.cmbAthletes.Location = new System.Drawing.Point(86, 52);
            this.cmbAthletes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbAthletes.Name = "cmbAthletes";
            this.cmbAthletes.Size = new System.Drawing.Size(187, 21);
            this.cmbAthletes.TabIndex = 2;
            this.cmbAthletes.Text = "Athlete to Add";
            // 
            // txtAccomplishments
            // 
            this.txtAccomplishments.Location = new System.Drawing.Point(86, 96);
            this.txtAccomplishments.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAccomplishments.Name = "txtAccomplishments";
            this.txtAccomplishments.Size = new System.Drawing.Size(187, 20);
            this.txtAccomplishments.TabIndex = 4;
            this.txtAccomplishments.Text = "Accomplishments";
            // 
            // btnAddWeeklyAthleteInfo
            // 
            this.btnAddWeeklyAthleteInfo.Location = new System.Drawing.Point(130, 141);
            this.btnAddWeeklyAthleteInfo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddWeeklyAthleteInfo.Name = "btnAddWeeklyAthleteInfo";
            this.btnAddWeeklyAthleteInfo.Size = new System.Drawing.Size(91, 33);
            this.btnAddWeeklyAthleteInfo.TabIndex = 7;
            this.btnAddWeeklyAthleteInfo.Text = "Add";
            this.btnAddWeeklyAthleteInfo.UseVisualStyleBackColor = true;
            this.btnAddWeeklyAthleteInfo.Click += new System.EventHandler(this.btnAddWeeklyAthleteInfo_Click);
            // 
            // cmbDeleteAthlete
            // 
            this.cmbDeleteAthlete.FormattingEnabled = true;
            this.cmbDeleteAthlete.Location = new System.Drawing.Point(86, 270);
            this.cmbDeleteAthlete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbDeleteAthlete.Name = "cmbDeleteAthlete";
            this.cmbDeleteAthlete.Size = new System.Drawing.Size(187, 21);
            this.cmbDeleteAthlete.TabIndex = 8;
            this.cmbDeleteAthlete.Text = "Athlete To Delete";
            // 
            // btnDeleteWeeklyAthlete
            // 
            this.btnDeleteWeeklyAthlete.Location = new System.Drawing.Point(130, 312);
            this.btnDeleteWeeklyAthlete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDeleteWeeklyAthlete.Name = "btnDeleteWeeklyAthlete";
            this.btnDeleteWeeklyAthlete.Size = new System.Drawing.Size(91, 33);
            this.btnDeleteWeeklyAthlete.TabIndex = 9;
            this.btnDeleteWeeklyAthlete.Text = "Remove";
            this.btnDeleteWeeklyAthlete.UseVisualStyleBackColor = true;
            this.btnDeleteWeeklyAthlete.Click += new System.EventHandler(this.btnDeleteAthlete_Click);
            // 
            // UpdateWeeklyAthleteForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 450);
            this.Controls.Add(this.btnDeleteWeeklyAthlete);
            this.Controls.Add(this.cmbDeleteAthlete);
            this.Controls.Add(this.btnAddWeeklyAthleteInfo);
            this.Controls.Add(this.txtAccomplishments);
            this.Controls.Add(this.cmbAthletes);
            this.Name = "UpdateWeeklyAthleteForm";
            this.Text = "UpdateWeeklyAthleteForm";
            this.Load += new System.EventHandler(this.UpdateWeeklyAthleteForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbAthletes;
        private System.Windows.Forms.TextBox txtAccomplishments;
        private System.Windows.Forms.Button btnAddWeeklyAthleteInfo;
        private System.Windows.Forms.ComboBox cmbDeleteAthlete;
        private System.Windows.Forms.Button btnDeleteWeeklyAthlete;
    }
}