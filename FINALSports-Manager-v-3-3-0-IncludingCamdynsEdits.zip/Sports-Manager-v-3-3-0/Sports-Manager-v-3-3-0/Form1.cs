﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Globalization;
using System.Runtime.Remoting.Contexts;
using System.Reflection.Emit;

namespace SportsManagement_Dashboard
{
    public partial class Form1 : Form
    {
        private ProgDB context; // creates a new DB "session"

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,     // x-coordinate of upper-left corner
            int nTopRect,      // y-coordinate of upper-left corner
            int nRightRect,    // x-coordinate of lower-right corner
            int nBottomRect,   // y-coordinate of lower-right corner
            int nWidthEllipse, // width of ellipse
            int nHeightEllipse // height of ellipse
        );

        private string _username;
        
        public Form1()
        {
            InitializeComponent();

            context = new ProgDB();
            context.Database.EnsureCreated(); // verify that the DB exists
            LoadAthletesIntoDataGridView();  //Added by Camdyn


            // Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25));
            pnlNav.Height = btnDashboard.Height;
            pnlNav.Top = btnDashboard.Top;
            pnlNav.Left = btnDashboard.Left;
            btnDashboard.BackColor = Color.FromArgb(46, 51, 73);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void userName_Label_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = coachbutton1.Height;
            pnlNav.Top = coachbutton1.Top;
            pnlNav.Left = coachbutton1.Left;
            coachbutton1.BackColor = Color.FromArgb(46, 51, 73);
            CoachRoster coachRoster = new CoachRoster();
            coachRoster.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

       

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btnDashboard.Height;
            pnlNav.Top = btnDashboard.Top;
            pnlNav.Left = btnDashboard.Left;
            btnDashboard.BackColor = Color.FromArgb(46, 51, 73);
        }

        private void teambutton1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = teambutton1.Height;
            pnlNav.Top = teambutton1.Top;
            pnlNav.Left = teambutton1.Left;
            teambutton1.BackColor = Color.FromArgb(46, 51, 73);
            AthleteRoster athleteRoster = new AthleteRoster();
            athleteRoster.Show();
        }

        private void matchesbutton3_Click(object sender, EventArgs e)
        {
            pnlNav.Height = matchesbutton3.Height;
            pnlNav.Top = matchesbutton3.Top;
            pnlNav.Left = matchesbutton3.Left;
            matchesbutton3.BackColor = Color.FromArgb(46, 51, 73);

            Calendar sistema = new Calendar();
            sistema.ShowDialog();

        }

        private void statsbutton1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = statsbutton1.Height;
            pnlNav.Top = statsbutton1.Top;
            pnlNav.Left = statsbutton1.Left;
            statsbutton1.BackColor = Color.FromArgb(46, 51, 73);
        }

        private void settingsbutton1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = settingsbutton1.Height;
            pnlNav.Top = settingsbutton1.Top;
            pnlNav.Left = settingsbutton1.Left;
            settingsbutton1.BackColor = Color.FromArgb(46, 51, 73);

            // Show Settings Form
            Settings settingsPage = new Settings(_username); // Pass the current username
            settingsPage.Show();
        }

        private void btnDashboard_Leave(object sender, EventArgs e)
        {
            btnDashboard.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void teambutton1_Leave(object sender, EventArgs e)
        {
            teambutton1.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void coachbutton1_Leave(object sender, EventArgs e)
        {
            coachbutton1.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void matchesbutton3_Leave(object sender, EventArgs e)
        {
            matchesbutton3.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void statsbutton1_Leave(object sender, EventArgs e)
        {
            statsbutton1.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void settingsbutton1_Leave(object sender, EventArgs e)
        {
            settingsbutton1.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Everything below this was added by Camdyn
        private void btnUpdateWeeklyAthlete_Click(object sender, EventArgs e)
        {
            // Pass 'this' (Form1) and the displayed athletes list to the UpdateWeeklyAthleteForm constructor
            var updateForm = new UpdateWeeklyAthleteForm(this);

            // Show the update form
            updateForm.ShowDialog();
        }

        public void LoadSelectedAthleteData(int athleteId)
        {
            var selectedAthlete = context.Athletes
                    .Where(a => a.id == athleteId)
                    .Select(a => new
                    {
                        a.id,
                        a.first_name,
                        a.last_name,
                        a.position,
                        a.accomplishments,
                    })
                    .FirstOrDefault();

            if (selectedAthlete != null)
            {
                // Check if the athlete is already in AthleteDisplay table
                var existingAthlete = context.AthleteDisplays
                    .FirstOrDefault(ad => ad.Id == selectedAthlete.id);

                if (existingAthlete == null)
                {
                    // Add new athlete to the AthleteDisplay table
                    AthleteDisplay newAthleteDisplay = new AthleteDisplay
                    {
                        Id = selectedAthlete.id,  // Add the selected athlete's id
                        FirstName = selectedAthlete.first_name,
                        LastName = selectedAthlete.last_name,
                        Position = selectedAthlete.position,
                        Accomplishments = selectedAthlete.accomplishments
                    };

                    // Add to the database
                    context.AthleteDisplays.Add(newAthleteDisplay);
                    context.SaveChanges(); // Save changes to persist in database

                    MessageBox.Show("Athlete data added to AthleteDisplay table.");
                }
                else
                {
                    MessageBox.Show("Athlete is already in the AthleteDisplay table.");
                }

                // Refresh the DataGridView with updated data
                LoadAthletesIntoDataGridView();


                


                // Show the current count of the AthleteDisplay records
                var athleteDisplayCount = context.AthleteDisplays.Count();
                MessageBox.Show($"AthleteDisplay Count: {athleteDisplayCount}");
            }
            else
            {
                MessageBox.Show("Athlete not found in database.");
            }
        }

        // Method to load AthleteDisplay data into the DataGridView
        public void LoadAthletesIntoDataGridView()
        {
            // Retrieve all athletes from the AthleteDisplay table
            var athleteDisplayList = context.AthleteDisplays
                .Select(ad => new
                {
                    ad.Id,
                    ad.FirstName,
                    ad.LastName,
                    ad.Accomplishments
                })
                .ToList();

            // Bind the data to the DataGridView
            dataGridViewAthletes.DataSource = athleteDisplayList;
        }


        // Method in Form1 to remove an athlete from the DataGridView
        public void RemoveAthleteFromDataGridView(int athleteToRemoveId)
        {
            var selectedRemoval = context.AthleteDisplays.FirstOrDefault(a => a.Id == athleteToRemoveId);

            if (selectedRemoval != null)
            {
                // Remove the athlete from the AthleteDisplays table
                context.AthleteDisplays.Remove(selectedRemoval);

                // Save the changes to the database
                context.SaveChanges();



                // Optionally, remove the athlete from the DataGridView if it's displayed there
                LoadAthletesIntoDataGridView();
            }
            else
            {
                MessageBox.Show("Athlete not found.");
            }
        }



        // Edits the "double clicked" athlete from the roster

        private void edit_ath(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewAthletes.SelectedRows.Count == 0)
            { // No row selected
                return;
            }

            var selectedRow = dataGridViewAthletes.SelectedRows[0]; // Get the first selected row
            int selectedId = (int)selectedRow.Cells["id"].Value; // Assuming the column name is "id"

            var selectedAthlete = context.Athletes.SingleOrDefault(a => a.id == selectedId); // Get athlete by id
            if (selectedAthlete != null)
            {
                var win = new Form { Text = "Edit an Athlete" }; // New window
                var card = new Ath_info_card 
                { 
                    Dock = DockStyle.Fill,
                    HideButtons = true // Hide Save and Clear All Fields buttons
                }; // New info card
                win.ClientSize = card.Size; // Match window & card sizes

                card.fill_fields(selectedAthlete); // Fill in the fields
                win.Controls.Add(card);
                win.Show();
                

                win.FormClosed += (s, args) => { // Reload the roster upon closing
                    context.SaveChanges();
                };
            }
        }



       
    }
}
