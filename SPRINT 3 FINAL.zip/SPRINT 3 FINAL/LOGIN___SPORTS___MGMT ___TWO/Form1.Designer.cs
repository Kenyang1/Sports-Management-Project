﻿namespace SportsManagement_Dashboard
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.settingsbutton1 = new System.Windows.Forms.Button();
            this.coachbutton1 = new System.Windows.Forms.Button();
            this.matchesbutton3 = new System.Windows.Forms.Button();
            this.statsbutton1 = new System.Windows.Forms.Button();
            this.teambutton1 = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlNav = new System.Windows.Forms.Panel();
            this.userName_Label = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.exit = new System.Windows.Forms.Button();
            this.weeklyAthlete = new System.Windows.Forms.Label();
            this.athleteInfo = new System.Windows.Forms.ListBox();
            this.profileImagePathTextBox = new System.Windows.Forms.TextBox();
            this.achievementsTextBox = new System.Windows.Forms.TextBox();
            this.athletePositionTextBox = new System.Windows.Forms.TextBox();
            this.gradeYearTextBox = new System.Windows.Forms.TextBox();
            this.athleteIdTextBox = new System.Windows.Forms.TextBox();
            this.enterAthleteInfo = new System.Windows.Forms.TextBox();
            this.clearAthleteInfoButton = new System.Windows.Forms.Button();
            this.addAthleteInfoButton = new System.Windows.Forms.Button();
            this.eventDatePicker = new System.Windows.Forms.DateTimePicker();
            this.eventDescriptionTextBox = new System.Windows.Forms.TextBox();
            this.eventLengthTextBox = new System.Windows.Forms.TextBox();
            this.eventIDTextBox = new System.Windows.Forms.TextBox();
            this.eventTypeTextBox = new System.Windows.Forms.TextBox();
            this.upcomingEventsLabel = new System.Windows.Forms.Label();
            this.clearEventInfo = new System.Windows.Forms.Button();
            this.addEventInfo = new System.Windows.Forms.Button();
            this.upcomingEvents = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(this.settingsbutton1);
            this.panel1.Controls.Add(this.coachbutton1);
            this.panel1.Controls.Add(this.matchesbutton3);
            this.panel1.Controls.Add(this.statsbutton1);
            this.panel1.Controls.Add(this.teambutton1);
            this.panel1.Controls.Add(this.btnDashboard);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(93, 588);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // settingsbutton1
            // 
            this.settingsbutton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.settingsbutton1.Font = new System.Drawing.Font("Nirmala UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingsbutton1.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.settingsbutton1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.settingsbutton1.Location = new System.Drawing.Point(-1, 527);
            this.settingsbutton1.Margin = new System.Windows.Forms.Padding(1);
            this.settingsbutton1.Name = "settingsbutton1";
            this.settingsbutton1.Size = new System.Drawing.Size(93, 32);
            this.settingsbutton1.TabIndex = 8;
            this.settingsbutton1.Text = "Settings";
            this.settingsbutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.settingsbutton1.UseVisualStyleBackColor = true;
            this.settingsbutton1.Click += new System.EventHandler(this.settingsbutton1_Click);
            this.settingsbutton1.Leave += new System.EventHandler(this.settingsbutton1_Leave);
            // 
            // coachbutton1
            // 
            this.coachbutton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.coachbutton1.Font = new System.Drawing.Font("Nirmala UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coachbutton1.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.coachbutton1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.coachbutton1.Location = new System.Drawing.Point(3, 409);
            this.coachbutton1.Margin = new System.Windows.Forms.Padding(1);
            this.coachbutton1.Name = "coachbutton1";
            this.coachbutton1.Size = new System.Drawing.Size(93, 81);
            this.coachbutton1.TabIndex = 7;
            this.coachbutton1.Text = "Coaches";
            this.coachbutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.coachbutton1.UseVisualStyleBackColor = true;
            this.coachbutton1.Click += new System.EventHandler(this.button1_Click);
            this.coachbutton1.Leave += new System.EventHandler(this.coachbutton1_Leave);
            // 
            // matchesbutton3
            // 
            this.matchesbutton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.matchesbutton3.Font = new System.Drawing.Font("Nirmala UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.matchesbutton3.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.matchesbutton3.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.matchesbutton3.Location = new System.Drawing.Point(0, 241);
            this.matchesbutton3.Margin = new System.Windows.Forms.Padding(1);
            this.matchesbutton3.Name = "matchesbutton3";
            this.matchesbutton3.Size = new System.Drawing.Size(92, 81);
            this.matchesbutton3.TabIndex = 6;
            this.matchesbutton3.Text = "Matches";
            this.matchesbutton3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.matchesbutton3.UseVisualStyleBackColor = true;
            this.matchesbutton3.Click += new System.EventHandler(this.matchesbutton3_Click);
            this.matchesbutton3.Leave += new System.EventHandler(this.matchesbutton3_Leave);
            // 
            // statsbutton1
            // 
            this.statsbutton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.statsbutton1.Font = new System.Drawing.Font("Nirmala UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statsbutton1.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.statsbutton1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.statsbutton1.Location = new System.Drawing.Point(1, 325);
            this.statsbutton1.Margin = new System.Windows.Forms.Padding(1);
            this.statsbutton1.Name = "statsbutton1";
            this.statsbutton1.Size = new System.Drawing.Size(93, 81);
            this.statsbutton1.TabIndex = 5;
            this.statsbutton1.Text = "Stats";
            this.statsbutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.statsbutton1.UseVisualStyleBackColor = true;
            this.statsbutton1.Click += new System.EventHandler(this.statsbutton1_Click);
            this.statsbutton1.Leave += new System.EventHandler(this.statsbutton1_Leave);
            // 
            // teambutton1
            // 
            this.teambutton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.teambutton1.Font = new System.Drawing.Font("Nirmala UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teambutton1.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.teambutton1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.teambutton1.Location = new System.Drawing.Point(1, 158);
            this.teambutton1.Margin = new System.Windows.Forms.Padding(1);
            this.teambutton1.Name = "teambutton1";
            this.teambutton1.Size = new System.Drawing.Size(92, 81);
            this.teambutton1.TabIndex = 4;
            this.teambutton1.Text = "Teams";
            this.teambutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.teambutton1.UseVisualStyleBackColor = true;
            this.teambutton1.Click += new System.EventHandler(this.teambutton1_Click);
            this.teambutton1.Leave += new System.EventHandler(this.teambutton1_Leave);
            // 
            // btnDashboard
            // 
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Nirmala UI", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.btnDashboard.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnDashboard.Location = new System.Drawing.Point(3, 74);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(1);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(92, 81);
            this.btnDashboard.TabIndex = 3;
            this.btnDashboard.Text = "dashboard";
            this.btnDashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDashboard.UseVisualStyleBackColor = true;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            this.btnDashboard.Leave += new System.EventHandler(this.btnDashboard_Leave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(48, 78);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(51, 26);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pnlNav);
            this.panel2.Controls.Add(this.userName_Label);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(93, 74);
            this.panel2.TabIndex = 1;
            // 
            // pnlNav
            // 
            this.pnlNav.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.pnlNav.Location = new System.Drawing.Point(1, 74);
            this.pnlNav.Margin = new System.Windows.Forms.Padding(1);
            this.pnlNav.Name = "pnlNav";
            this.pnlNav.Size = new System.Drawing.Size(11, 303);
            this.pnlNav.TabIndex = 2;
            // 
            // userName_Label
            // 
            this.userName_Label.AutoSize = true;
            this.userName_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userName_Label.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.userName_Label.Location = new System.Drawing.Point(15, 52);
            this.userName_Label.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.userName_Label.Name = "userName_Label";
            this.userName_Label.Size = new System.Drawing.Size(69, 13);
            this.userName_Label.TabIndex = 1;
            this.userName_Label.Text = "USer Name";
            this.userName_Label.Click += new System.EventHandler(this.userName_Label_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SportsManagement_Dashboard.Properties.Resources.user;
            this.pictureBox2.Location = new System.Drawing.Point(29, 11);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 32);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(839, 11);
            this.exit.Margin = new System.Windows.Forms.Padding(1);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(36, 31);
            this.exit.TabIndex = 1;
            this.exit.Text = "x";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // weeklyAthlete
            // 
            this.weeklyAthlete.AutoSize = true;
            this.weeklyAthlete.BackColor = System.Drawing.Color.White;
            this.weeklyAthlete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weeklyAthlete.Location = new System.Drawing.Point(213, 73);
            this.weeklyAthlete.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.weeklyAthlete.Name = "weeklyAthlete";
            this.weeklyAthlete.Size = new System.Drawing.Size(183, 25);
            this.weeklyAthlete.TabIndex = 15;
            this.weeklyAthlete.Text = "Athlete of the Week";
            // 
            // athleteInfo
            // 
            this.athleteInfo.FormattingEnabled = true;
            this.athleteInfo.ItemHeight = 16;
            this.athleteInfo.Location = new System.Drawing.Point(213, 119);
            this.athleteInfo.Margin = new System.Windows.Forms.Padding(4);
            this.athleteInfo.Name = "athleteInfo";
            this.athleteInfo.Size = new System.Drawing.Size(193, 100);
            this.athleteInfo.TabIndex = 16;
            // 
            // profileImagePathTextBox
            // 
            this.profileImagePathTextBox.Location = new System.Drawing.Point(238, 394);
            this.profileImagePathTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.profileImagePathTextBox.Name = "profileImagePathTextBox";
            this.profileImagePathTextBox.Size = new System.Drawing.Size(132, 22);
            this.profileImagePathTextBox.TabIndex = 31;
            this.profileImagePathTextBox.Text = "Profile Image Path";
            // 
            // achievementsTextBox
            // 
            this.achievementsTextBox.Location = new System.Drawing.Point(238, 364);
            this.achievementsTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.achievementsTextBox.Name = "achievementsTextBox";
            this.achievementsTextBox.Size = new System.Drawing.Size(132, 22);
            this.achievementsTextBox.TabIndex = 30;
            this.achievementsTextBox.Text = "Achievements";
            // 
            // athletePositionTextBox
            // 
            this.athletePositionTextBox.Location = new System.Drawing.Point(238, 332);
            this.athletePositionTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.athletePositionTextBox.Name = "athletePositionTextBox";
            this.athletePositionTextBox.Size = new System.Drawing.Size(132, 22);
            this.athletePositionTextBox.TabIndex = 29;
            this.athletePositionTextBox.Text = "Position";
            // 
            // gradeYearTextBox
            // 
            this.gradeYearTextBox.Location = new System.Drawing.Point(238, 301);
            this.gradeYearTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.gradeYearTextBox.Name = "gradeYearTextBox";
            this.gradeYearTextBox.Size = new System.Drawing.Size(132, 22);
            this.gradeYearTextBox.TabIndex = 28;
            this.gradeYearTextBox.Text = "Grade Year";
            // 
            // athleteIdTextBox
            // 
            this.athleteIdTextBox.Location = new System.Drawing.Point(238, 271);
            this.athleteIdTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.athleteIdTextBox.Name = "athleteIdTextBox";
            this.athleteIdTextBox.Size = new System.Drawing.Size(132, 22);
            this.athleteIdTextBox.TabIndex = 27;
            this.athleteIdTextBox.Text = "ID";
            // 
            // enterAthleteInfo
            // 
            this.enterAthleteInfo.Location = new System.Drawing.Point(238, 241);
            this.enterAthleteInfo.Margin = new System.Windows.Forms.Padding(4);
            this.enterAthleteInfo.Name = "enterAthleteInfo";
            this.enterAthleteInfo.Size = new System.Drawing.Size(132, 22);
            this.enterAthleteInfo.TabIndex = 26;
            this.enterAthleteInfo.Text = "Name";
            // 
            // clearAthleteInfoButton
            // 
            this.clearAthleteInfoButton.Location = new System.Drawing.Point(250, 470);
            this.clearAthleteInfoButton.Margin = new System.Windows.Forms.Padding(4);
            this.clearAthleteInfoButton.Name = "clearAthleteInfoButton";
            this.clearAthleteInfoButton.Size = new System.Drawing.Size(100, 28);
            this.clearAthleteInfoButton.TabIndex = 33;
            this.clearAthleteInfoButton.Text = "Clear Item";
            this.clearAthleteInfoButton.UseVisualStyleBackColor = true;
            // 
            // addAthleteInfoButton
            // 
            this.addAthleteInfoButton.Location = new System.Drawing.Point(250, 434);
            this.addAthleteInfoButton.Margin = new System.Windows.Forms.Padding(4);
            this.addAthleteInfoButton.Name = "addAthleteInfoButton";
            this.addAthleteInfoButton.Size = new System.Drawing.Size(100, 28);
            this.addAthleteInfoButton.TabIndex = 32;
            this.addAthleteInfoButton.Text = "Add";
            this.addAthleteInfoButton.UseVisualStyleBackColor = true;
            // 
            // eventDatePicker
            // 
            this.eventDatePicker.Location = new System.Drawing.Point(587, 299);
            this.eventDatePicker.Margin = new System.Windows.Forms.Padding(4);
            this.eventDatePicker.Name = "eventDatePicker";
            this.eventDatePicker.Size = new System.Drawing.Size(132, 22);
            this.eventDatePicker.TabIndex = 42;
            // 
            // eventDescriptionTextBox
            // 
            this.eventDescriptionTextBox.Location = new System.Drawing.Point(587, 363);
            this.eventDescriptionTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.eventDescriptionTextBox.Name = "eventDescriptionTextBox";
            this.eventDescriptionTextBox.Size = new System.Drawing.Size(132, 22);
            this.eventDescriptionTextBox.TabIndex = 41;
            this.eventDescriptionTextBox.Text = "Description";
            // 
            // eventLengthTextBox
            // 
            this.eventLengthTextBox.Location = new System.Drawing.Point(587, 331);
            this.eventLengthTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.eventLengthTextBox.Name = "eventLengthTextBox";
            this.eventLengthTextBox.Size = new System.Drawing.Size(132, 22);
            this.eventLengthTextBox.TabIndex = 40;
            this.eventLengthTextBox.Text = "Length";
            // 
            // eventIDTextBox
            // 
            this.eventIDTextBox.Location = new System.Drawing.Point(587, 266);
            this.eventIDTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.eventIDTextBox.Name = "eventIDTextBox";
            this.eventIDTextBox.Size = new System.Drawing.Size(132, 22);
            this.eventIDTextBox.TabIndex = 39;
            this.eventIDTextBox.Text = "ID";
            // 
            // eventTypeTextBox
            // 
            this.eventTypeTextBox.Location = new System.Drawing.Point(587, 234);
            this.eventTypeTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.eventTypeTextBox.Name = "eventTypeTextBox";
            this.eventTypeTextBox.Size = new System.Drawing.Size(132, 22);
            this.eventTypeTextBox.TabIndex = 38;
            this.eventTypeTextBox.Text = "Type";
            // 
            // upcomingEventsLabel
            // 
            this.upcomingEventsLabel.AutoSize = true;
            this.upcomingEventsLabel.BackColor = System.Drawing.Color.White;
            this.upcomingEventsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upcomingEventsLabel.Location = new System.Drawing.Point(565, 73);
            this.upcomingEventsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.upcomingEventsLabel.Name = "upcomingEventsLabel";
            this.upcomingEventsLabel.Size = new System.Drawing.Size(165, 25);
            this.upcomingEventsLabel.TabIndex = 37;
            this.upcomingEventsLabel.Text = "Upcoming Events";
            // 
            // clearEventInfo
            // 
            this.clearEventInfo.Location = new System.Drawing.Point(602, 475);
            this.clearEventInfo.Margin = new System.Windows.Forms.Padding(4);
            this.clearEventInfo.Name = "clearEventInfo";
            this.clearEventInfo.Size = new System.Drawing.Size(100, 28);
            this.clearEventInfo.TabIndex = 36;
            this.clearEventInfo.Text = "Clear Item";
            this.clearEventInfo.UseVisualStyleBackColor = true;
            // 
            // addEventInfo
            // 
            this.addEventInfo.Location = new System.Drawing.Point(602, 434);
            this.addEventInfo.Margin = new System.Windows.Forms.Padding(4);
            this.addEventInfo.Name = "addEventInfo";
            this.addEventInfo.Size = new System.Drawing.Size(100, 28);
            this.addEventInfo.TabIndex = 35;
            this.addEventInfo.Text = "Add";
            this.addEventInfo.UseVisualStyleBackColor = true;
            // 
            // upcomingEvents
            // 
            this.upcomingEvents.FormattingEnabled = true;
            this.upcomingEvents.ItemHeight = 16;
            this.upcomingEvents.Location = new System.Drawing.Point(558, 119);
            this.upcomingEvents.Margin = new System.Windows.Forms.Padding(4);
            this.upcomingEvents.Name = "upcomingEvents";
            this.upcomingEvents.Size = new System.Drawing.Size(193, 100);
            this.upcomingEvents.TabIndex = 34;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(888, 588);
            this.Controls.Add(this.eventDatePicker);
            this.Controls.Add(this.eventDescriptionTextBox);
            this.Controls.Add(this.eventLengthTextBox);
            this.Controls.Add(this.eventIDTextBox);
            this.Controls.Add(this.eventTypeTextBox);
            this.Controls.Add(this.upcomingEventsLabel);
            this.Controls.Add(this.clearEventInfo);
            this.Controls.Add(this.addEventInfo);
            this.Controls.Add(this.upcomingEvents);
            this.Controls.Add(this.clearAthleteInfoButton);
            this.Controls.Add(this.addAthleteInfoButton);
            this.Controls.Add(this.profileImagePathTextBox);
            this.Controls.Add(this.achievementsTextBox);
            this.Controls.Add(this.athletePositionTextBox);
            this.Controls.Add(this.gradeYearTextBox);
            this.Controls.Add(this.athleteIdTextBox);
            this.Controls.Add(this.enterAthleteInfo);
            this.Controls.Add(this.athleteInfo);
            this.Controls.Add(this.weeklyAthlete);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label userName_Label;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button coachbutton1;
        private System.Windows.Forms.Button matchesbutton3;
        private System.Windows.Forms.Button statsbutton1;
        private System.Windows.Forms.Button teambutton1;
        private System.Windows.Forms.Button settingsbutton1;
        private System.Windows.Forms.Panel pnlNav;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Label weeklyAthlete;
        private System.Windows.Forms.ListBox athleteInfo;
        private System.Windows.Forms.TextBox profileImagePathTextBox;
        private System.Windows.Forms.TextBox achievementsTextBox;
        private System.Windows.Forms.TextBox athletePositionTextBox;
        private System.Windows.Forms.TextBox gradeYearTextBox;
        private System.Windows.Forms.TextBox athleteIdTextBox;
        private System.Windows.Forms.TextBox enterAthleteInfo;
        private System.Windows.Forms.Button clearAthleteInfoButton;
        private System.Windows.Forms.Button addAthleteInfoButton;
        private System.Windows.Forms.DateTimePicker eventDatePicker;
        private System.Windows.Forms.TextBox eventDescriptionTextBox;
        private System.Windows.Forms.TextBox eventLengthTextBox;
        private System.Windows.Forms.TextBox eventIDTextBox;
        private System.Windows.Forms.TextBox eventTypeTextBox;
        private System.Windows.Forms.Label upcomingEventsLabel;
        private System.Windows.Forms.Button clearEventInfo;
        private System.Windows.Forms.Button addEventInfo;
        private System.Windows.Forms.ListBox upcomingEvents;
    }
}

