﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class Calendar : Form
    {
        int month, year;
        public static string static_month, static_year;
        public Calendar()
        {
            InitializeComponent();
            // Initialize month and year to the current date
            DateTime now = DateTime.Now;
            month = now.Month;
            year = now.Year;

            // Display the current month when the form loads
            displayDays();
        }

        private void Calendar_Load(object sender, EventArgs e)
        {
            
        }

        private void displayDays()
        {
            DateTime now = DateTime.Now;
            month = now.Month;
            year = now.Year;

            String monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            LBDATE.Text = monthname + " " + year;

            // static_month = month;
            // static_year = year;

            // First day of month
            DateTime startofthemonth = new DateTime(year, month, 1);
            //Count days of month
            int days = DateTime.DaysInMonth(year, month);
            //Convert the startofthemonth into int
            int daysoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d")) + 1;

            for (int i = 1; i < daysoftheweek; i++)
            {
                UserControlBlank ucblank = new UserControlBlank();
                dayContainer.Controls.Add(ucblank);
            }
            for (int i = 1; i <= days; i++)
            {
                UserControlDays ucdays = new UserControlDays();
                ucdays.days(i);
                dayContainer.Controls.Add(ucdays);
            }

        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void LBDATE_Click(object sender, EventArgs e)
        {

        }

        private void btnNext_Click_1(object sender, EventArgs e)
        {
            dayContainer.Controls.Clear();

            // Increment month to go to next month
            month++;
            if (month > 12)
            {
                month = 1;
                year++;  // Move to the next year
            }

            // static_month = month;
            // static_year = year;
            String monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            LBDATE.Text = monthname + " " + year;

            DateTime startofthemonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int daysoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d")) + 1;

            for (int i = 1; i < daysoftheweek; i++)
            {
                UserControlBlank ucblank = new UserControlBlank();
                dayContainer.Controls.Add(ucblank);
            }
            for (int i = 1; i <= days; i++)
            {
                UserControlDays ucdays = new UserControlDays();
                ucdays.days(i);
                dayContainer.Controls.Add(ucdays);
            }
        }

        private void btnPrevious_Click_1(object sender, EventArgs e)
        {
            dayContainer.Controls.Clear();

            // Decrement month to go to previous month
            month--;
            if (month < 1)
            {
                month = 12;
                year--;  // Move to the previous year
            }

            // static_month = month;
            // static_year = year;
            String monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            LBDATE.Text = monthname + " " + year;

            DateTime startofthemonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int daysoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d")) + 1;

            for (int i = 1; i < daysoftheweek; i++)
            {
                UserControlBlank ucblank = new UserControlBlank();
                dayContainer.Controls.Add(ucblank);
            }
            for (int i = 1; i <= days; i++)
            {
                UserControlDays ucdays = new UserControlDays();
                ucdays.days(i);
                dayContainer.Controls.Add(ucdays);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
           
        }
        
        private void btnPrevious_Click(object sender, EventArgs e)
        {
           
        }

        /*
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }*/
    }
}
