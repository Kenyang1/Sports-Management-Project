﻿namespace SportsManagement_Dashboard
{
    partial class Calendar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.LBDATE = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dayContainer = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.dayContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(219, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Monday";
            // 
            // LBDATE
            // 
            this.LBDATE.AutoSize = true;
            this.LBDATE.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 15.9F, System.Drawing.FontStyle.Bold);
            this.LBDATE.Location = new System.Drawing.Point(475, 9);
            this.LBDATE.Name = "LBDATE";
            this.LBDATE.Size = new System.Drawing.Size(177, 27);
            this.LBDATE.TabIndex = 3;
            this.LBDATE.Text = "Month, YEAR";
            this.LBDATE.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.LBDATE.Click += new System.EventHandler(this.LBDATE_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(61, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "Sunday";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(992, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Saturday";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(837, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Friday";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(672, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Thursday";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(512, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Wednseday";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(364, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tuesday";
            // 
            // dayContainer
            // 
            this.dayContainer.Controls.Add(this.panel1);
            this.dayContainer.Controls.Add(this.panel2);
            this.dayContainer.Controls.Add(this.panel3);
            this.dayContainer.Controls.Add(this.panel4);
            this.dayContainer.Controls.Add(this.panel5);
            this.dayContainer.Controls.Add(this.panel6);
            this.dayContainer.Controls.Add(this.panel7);
            this.dayContainer.Controls.Add(this.panel8);
            this.dayContainer.Controls.Add(this.panel9);
            this.dayContainer.Controls.Add(this.panel10);
            this.dayContainer.Controls.Add(this.panel11);
            this.dayContainer.Controls.Add(this.panel12);
            this.dayContainer.Controls.Add(this.panel13);
            this.dayContainer.Controls.Add(this.panel14);
            this.dayContainer.Controls.Add(this.panel15);
            this.dayContainer.Controls.Add(this.panel16);
            this.dayContainer.Controls.Add(this.panel17);
            this.dayContainer.Controls.Add(this.panel18);
            this.dayContainer.Controls.Add(this.panel19);
            this.dayContainer.Controls.Add(this.panel20);
            this.dayContainer.Controls.Add(this.panel21);
            this.dayContainer.Controls.Add(this.panel22);
            this.dayContainer.Controls.Add(this.panel23);
            this.dayContainer.Controls.Add(this.panel24);
            this.dayContainer.Controls.Add(this.panel25);
            this.dayContainer.Controls.Add(this.panel26);
            this.dayContainer.Controls.Add(this.panel27);
            this.dayContainer.Controls.Add(this.panel28);
            this.dayContainer.Controls.Add(this.panel29);
            this.dayContainer.Controls.Add(this.panel30);
            this.dayContainer.Controls.Add(this.panel31);
            this.dayContainer.Controls.Add(this.panel32);
            this.dayContainer.Controls.Add(this.panel33);
            this.dayContainer.Controls.Add(this.panel34);
            this.dayContainer.Controls.Add(this.panel35);
            this.dayContainer.Location = new System.Drawing.Point(10, 72);
            this.dayContainer.Margin = new System.Windows.Forms.Padding(1);
            this.dayContainer.Name = "dayContainer";
            this.dayContainer.Size = new System.Drawing.Size(1112, 638);
            this.dayContainer.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(152, 119);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(161, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(152, 119);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(319, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(152, 119);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(477, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(152, 119);
            this.panel4.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(635, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(152, 119);
            this.panel5.TabIndex = 4;
            // 
            // panel6
            // 
            this.panel6.Location = new System.Drawing.Point(793, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(152, 119);
            this.panel6.TabIndex = 5;
            // 
            // panel7
            // 
            this.panel7.Location = new System.Drawing.Point(951, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(152, 119);
            this.panel7.TabIndex = 6;
            // 
            // panel8
            // 
            this.panel8.Location = new System.Drawing.Point(3, 128);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(152, 119);
            this.panel8.TabIndex = 7;
            // 
            // panel9
            // 
            this.panel9.Location = new System.Drawing.Point(161, 128);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(152, 119);
            this.panel9.TabIndex = 8;
            // 
            // panel10
            // 
            this.panel10.Location = new System.Drawing.Point(319, 128);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(152, 119);
            this.panel10.TabIndex = 9;
            // 
            // panel11
            // 
            this.panel11.Location = new System.Drawing.Point(477, 128);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(152, 119);
            this.panel11.TabIndex = 10;
            // 
            // panel12
            // 
            this.panel12.Location = new System.Drawing.Point(635, 128);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(152, 119);
            this.panel12.TabIndex = 11;
            // 
            // panel13
            // 
            this.panel13.Location = new System.Drawing.Point(793, 128);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(152, 119);
            this.panel13.TabIndex = 12;
            // 
            // panel14
            // 
            this.panel14.Location = new System.Drawing.Point(951, 128);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(152, 119);
            this.panel14.TabIndex = 13;
            // 
            // panel15
            // 
            this.panel15.Location = new System.Drawing.Point(3, 253);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(152, 119);
            this.panel15.TabIndex = 14;
            // 
            // panel16
            // 
            this.panel16.Location = new System.Drawing.Point(161, 253);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(152, 119);
            this.panel16.TabIndex = 15;
            // 
            // panel17
            // 
            this.panel17.Location = new System.Drawing.Point(319, 253);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(152, 119);
            this.panel17.TabIndex = 16;
            // 
            // panel18
            // 
            this.panel18.Location = new System.Drawing.Point(477, 253);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(152, 119);
            this.panel18.TabIndex = 17;
            // 
            // panel19
            // 
            this.panel19.Location = new System.Drawing.Point(635, 253);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(152, 119);
            this.panel19.TabIndex = 18;
            // 
            // panel20
            // 
            this.panel20.Location = new System.Drawing.Point(793, 253);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(152, 119);
            this.panel20.TabIndex = 19;
            // 
            // panel21
            // 
            this.panel21.Location = new System.Drawing.Point(951, 253);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(152, 119);
            this.panel21.TabIndex = 20;
            // 
            // panel22
            // 
            this.panel22.Location = new System.Drawing.Point(3, 378);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(152, 119);
            this.panel22.TabIndex = 21;
            // 
            // panel23
            // 
            this.panel23.Location = new System.Drawing.Point(161, 378);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(152, 119);
            this.panel23.TabIndex = 22;
            // 
            // panel24
            // 
            this.panel24.Location = new System.Drawing.Point(319, 378);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(152, 119);
            this.panel24.TabIndex = 23;
            // 
            // panel25
            // 
            this.panel25.Location = new System.Drawing.Point(477, 378);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(152, 119);
            this.panel25.TabIndex = 24;
            // 
            // panel26
            // 
            this.panel26.Location = new System.Drawing.Point(635, 378);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(152, 119);
            this.panel26.TabIndex = 25;
            // 
            // panel27
            // 
            this.panel27.Location = new System.Drawing.Point(793, 378);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(152, 119);
            this.panel27.TabIndex = 26;
            // 
            // panel28
            // 
            this.panel28.Location = new System.Drawing.Point(951, 378);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(152, 119);
            this.panel28.TabIndex = 27;
            // 
            // panel29
            // 
            this.panel29.Location = new System.Drawing.Point(3, 503);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(152, 119);
            this.panel29.TabIndex = 28;
            // 
            // panel30
            // 
            this.panel30.Location = new System.Drawing.Point(161, 503);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(152, 119);
            this.panel30.TabIndex = 29;
            // 
            // panel31
            // 
            this.panel31.Location = new System.Drawing.Point(319, 503);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(152, 119);
            this.panel31.TabIndex = 30;
            // 
            // panel32
            // 
            this.panel32.Location = new System.Drawing.Point(477, 503);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(152, 119);
            this.panel32.TabIndex = 31;
            // 
            // panel33
            // 
            this.panel33.Location = new System.Drawing.Point(635, 503);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(152, 119);
            this.panel33.TabIndex = 32;
            // 
            // panel34
            // 
            this.panel34.Location = new System.Drawing.Point(793, 503);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(152, 119);
            this.panel34.TabIndex = 33;
            // 
            // panel35
            // 
            this.panel35.Location = new System.Drawing.Point(951, 503);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(152, 119);
            this.panel35.TabIndex = 34;
            // 
            // btnPrevious
            // 
            this.btnPrevious.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnPrevious.Location = new System.Drawing.Point(927, 727);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(86, 37);
            this.btnPrevious.TabIndex = 14;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click_1);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnNext.Location = new System.Drawing.Point(1019, 727);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(94, 37);
            this.btnNext.TabIndex = 15;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click_1);
            // 
            // Calendar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 793);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.dayContainer);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LBDATE);
            this.Controls.Add(this.label2);
            this.Name = "Calendar";
            this.Text = "Calendar";
            this.dayContainer.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LBDATE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel dayContainer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
    }
}