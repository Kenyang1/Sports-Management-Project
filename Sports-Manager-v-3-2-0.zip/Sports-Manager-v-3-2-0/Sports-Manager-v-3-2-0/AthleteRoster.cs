﻿/*
 * Authors: Hamza, Ed, Nick, Camdyn, Kenyang, and Soham
 * Last updated: 1:56 PM 11/14/2024
 * Purpose: N/A
 * Due Date: N/A
 * Title: The work in progress
 * Copyright (C) 2024, no warranties as to its correctness.
 * 
 */

using Microsoft.Extensions.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System./*xml*/Xml.Linq;

// #include "LoginData.txt"

namespace SportsManagement_Dashboard
{
    public partial class AthleteRoster : Form
    {
        private ProgDB context; // creates a new DB "session"

        // initialize the roster, i.e., load the athletes from the DB
        public AthleteRoster()
        {
            InitializeComponent();
            context = new ProgDB();
            context.Database.EnsureCreated(); // verify that the DB exists
            load_aths();
        }

        // "refreshes" the roster size
        private void load_size()
        {
            // overwrite the GUI label with the new size
            label1.Text = "Roster size: " + listBox1.Items.Count.ToString();
        }

        // load/"refresh" the athlete roster
        private void load_aths()
        {
            // clear/empty the list box
            listBox1.Items.Clear();

            // load athletes from the DB
            var athletes = context.Athletes.ToList();
            foreach (var x in athletes)
            {
                // add each athlete to the roster as a string of the their members/columns
                listBox1.Items.Add($"{x.id}. {x.first_name} {x.last_name}; {x.age.ToString()}; " +
                    $"{x.position}");
            }
            load_size(); // "refresh" the roster size
        }

        private bool is_valid_ath(Athlete x)
        {
            return x.id != 0 && x.first_name != "" && x.last_name != "" && x.age > 0 
                && x.position != "";
        }

//------------ Add, Update, & Delete Functions ----------------------------------------------------

        // I forgot what this function does. I was mistaken with the idea that it was related to 
        // editing athletes' info
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is a work-in-progress feature.");
        }

        // adds an athlete to the roster list given their bio data
        private void add_ath(object sender, EventArgs e)
        {
            //// create a new athlete from the text boxes' extracted values (bio data)
            //var ath = new Athlete()
            //{
            //    id = (int)numericUpDown2.Value,
            //    first_name = textBox1.Text.ToString(),
            //    last_name = textBox2.Text.ToString(),
            //    age = ((int)numericUpDown1.Value),
            //    position = comboBox1.Text.ToString()
            //};
            //// determine if the fields have been filled out, add the athlete if they are filled out
            //if (is_valid_ath(ath))
            //{
            //    context.Athletes.Add(ath); // add the newly created athlete to the athlete table
            //    context.SaveChanges(); // save the changes made to the DB after adding the athlete
            //    load_aths(); // refreshes the athlete roster with the updated data
            //}
            //else
            //{
            //    MessageBox.Show("Error: all fields must be filled out.");
            //}

            var temp = new Form { Text = "Add a New Athlete", Size = new System.Drawing.Size(667, 431) };
            var instance = new Ath_info_card { Dock = DockStyle.Fill};

            temp.FormClosed += (s, args) => { // reload the athlete roster upon closing
                load_aths();
            };

            temp.Controls.Add(instance);
            temp.Show();
        }

        // deletes an athlete from the roster list given the current selection
        private void del_ath(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            { // a selection must be made
                MessageBox.Show("Error: an athlete must be selected before deletion");
            }
            else
            {
                string row = listBox1.SelectedItem.ToString(); // get the selected row info
                int id = Int32.Parse(row.Substring(0, row.IndexOf('.'))); // extract the id
                var target = context.Athletes.SingleOrDefault(x => x.id == id); // get athlete by id
                if (target != null)
                {
                    context.Athletes.Remove(target); // remove them from the DB
                    context.SaveChanges();
                }
                load_aths();
            }
        }

//------------ Don't Delete the "Methods" (a.k.a. Functions) Below --------------------------------

        /* Laughably, I have no clue why an error is throw when an element is deleted from the 
         * form. I think it has something it has to do with name not being declared before usage.
         * The following "mess" is quite the spectacle. */

        // I *forgot* what this function does, either way - don't delete it
        //    ^~~~~~~ I will investigate this further if time allows
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Do nothing
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // Again, do nothing
        }

        private void AthleteRoster_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) { // an athlete isn't selected
                return;
            }

            string row = listBox1.SelectedItem.ToString(); // get the selected row info
            int id = Int32.Parse(row.Substring(0, row.IndexOf('.'))); // get the id
            var selection = context.Athletes.SingleOrDefault(x => x.id == id); // athlete from the DB

            if (selection != null) { // an athlete is selected
                // pop-up the info card
                var temp = new Form {Text = "Edit an Athlete", Size = new System.Drawing.Size(667, 431)};
                var pop_up = new Ath_info_card {Dock = DockStyle.Fill};

                pop_up.fill_fields(selection); // fill in the fields

                temp.FormClosed += (s, args) => { // reload the athlete roster upon closing
                    load_aths();
                };

                temp.Controls.Add(pop_up);
                temp.Show();
            }
        }
    }
}
