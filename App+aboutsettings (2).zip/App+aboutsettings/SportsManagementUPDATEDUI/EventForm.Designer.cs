﻿namespace matchInfoPage
{
    partial class EventForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtdate = new TextBox();
            txtevent = new TextBox();
            btnsave = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 27);
            label1.Margin = new Padding(1, 0, 1, 0);
            label1.Name = "label1";
            label1.Size = new Size(30, 15);
            label1.TabIndex = 0;
            label1.Text = "date";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(32, 100);
            label2.Margin = new Padding(1, 0, 1, 0);
            label2.Name = "label2";
            label2.Size = new Size(36, 15);
            label2.TabIndex = 1;
            label2.Text = "event";
            // 
            // txtdate
            // 
            txtdate.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtdate.Location = new Point(32, 61);
            txtdate.Margin = new Padding(1, 1, 1, 1);
            txtdate.Name = "txtdate";
            txtdate.Size = new Size(309, 21);
            txtdate.TabIndex = 2;
            // 
            // txtevent
            // 
            txtevent.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtevent.Location = new Point(31, 138);
            txtevent.Margin = new Padding(1, 1, 1, 1);
            txtevent.Name = "txtevent";
            txtevent.Size = new Size(309, 21);
            txtevent.TabIndex = 3;
            txtevent.TextChanged += txtevent_TextChanged;
            // 
            // btnsave
            // 
            btnsave.Location = new Point(219, 177);
            btnsave.Margin = new Padding(1, 1, 1, 1);
            btnsave.Name = "btnsave";
            btnsave.Size = new Size(95, 28);
            btnsave.TabIndex = 4;
            btnsave.Text = "Save";
            btnsave.UseVisualStyleBackColor = true;
            btnsave.Click += btnsave_Click;
            // 
            // EventForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(369, 301);
            Controls.Add(btnsave);
            Controls.Add(txtevent);
            Controls.Add(txtdate);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(1, 1, 1, 1);
            Name = "EventForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EventForm";
            Load += EventForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtdate;
        private TextBox txtevent;
        private Button btnsave;
    }
}