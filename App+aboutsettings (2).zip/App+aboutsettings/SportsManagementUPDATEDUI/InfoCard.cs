﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class InfoCard : UserControl
    {
        public InfoCard()
        {
            InitializeComponent();
        }

        public void SetAthleteDetails(string athleteName, string nationality, string position, string team, string height, string weight, string age) // You can expand this to include more details
        {
            // Assuming you have a label to display the name
            lblAthleteName.Text = athleteName;
            lblAthleteNationality.Text = nationality;
            lblAthletePosition.Text = position;
            lblAthleteTeam.Text = team;
            lblAthleteHeight.Text = height;
            lblAthleteWeight.Text = weight;
            lblAthleteAge.Text = age;
        }



        private void InfoCard_Load(object sender, EventArgs e)
        {

        }

        private void InitializeComponent()
        {
            ComponentResourceManager resources = new ComponentResourceManager(typeof(InfoCard));
            lblAthleteName = new Label();
            lblAthleteNationality = new Label();
            lblAthletePosition = new Label();
            lblAthleteTeam = new Label();
            lblAthleteHeight = new Label();
            lblAthleteWeight = new Label();
            lblAthleteAge = new Label();
            pictureBox1 = new PictureBox();
            ((ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblAthleteName
            // 
            lblAthleteName.AutoSize = true;
            lblAthleteName.Location = new Point(55, 111);
            lblAthleteName.Name = "lblAthleteName";
            lblAthleteName.Size = new Size(90, 15);
            lblAthleteName.TabIndex = 0;
            lblAthleteName.Text = "lblAthleteName";
            // 
            // lblAthleteNationality
            // 
            lblAthleteNationality.AutoSize = true;
            lblAthleteNationality.Location = new Point(3, 224);
            lblAthleteNationality.Name = "lblAthleteNationality";
            lblAthleteNationality.Size = new Size(38, 15);
            lblAthleteNationality.TabIndex = 1;
            lblAthleteNationality.Text = "label2";
            // 
            // lblAthletePosition
            // 
            lblAthletePosition.AutoSize = true;
            lblAthletePosition.Location = new Point(3, 140);
            lblAthletePosition.Name = "lblAthletePosition";
            lblAthletePosition.Size = new Size(38, 15);
            lblAthletePosition.TabIndex = 2;
            lblAthletePosition.Text = "label3";
            // 
            // lblAthleteTeam
            // 
            lblAthleteTeam.AutoSize = true;
            lblAthleteTeam.Location = new Point(131, 224);
            lblAthleteTeam.Name = "lblAthleteTeam";
            lblAthleteTeam.Size = new Size(38, 15);
            lblAthleteTeam.TabIndex = 3;
            lblAthleteTeam.Text = "label4";
            // 
            // lblAthleteHeight
            // 
            lblAthleteHeight.AutoSize = true;
            lblAthleteHeight.Location = new Point(131, 140);
            lblAthleteHeight.Name = "lblAthleteHeight";
            lblAthleteHeight.Size = new Size(94, 15);
            lblAthleteHeight.TabIndex = 4;
            lblAthleteHeight.Text = "lblAthleteHeight";
            // 
            // lblAthleteWeight
            // 
            lblAthleteWeight.AutoSize = true;
            lblAthleteWeight.Location = new Point(3, 181);
            lblAthleteWeight.Name = "lblAthleteWeight";
            lblAthleteWeight.Size = new Size(96, 15);
            lblAthleteWeight.TabIndex = 5;
            lblAthleteWeight.Text = "lblAthleteWeight";
            // 
            // lblAthleteAge
            // 
            lblAthleteAge.AutoSize = true;
            lblAthleteAge.Location = new Point(131, 181);
            lblAthleteAge.Name = "lblAthleteAge";
            lblAthleteAge.Size = new Size(79, 15);
            lblAthleteAge.TabIndex = 6;
            lblAthleteAge.Text = "lblAthleteAge";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(55, 19);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(90, 76);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // InfoCard
            // 
            BackColor = Color.White;
            BorderStyle = BorderStyle.Fixed3D;
            Controls.Add(pictureBox1);
            Controls.Add(lblAthleteAge);
            Controls.Add(lblAthleteWeight);
            Controls.Add(lblAthleteHeight);
            Controls.Add(lblAthleteTeam);
            Controls.Add(lblAthletePosition);
            Controls.Add(lblAthleteNationality);
            Controls.Add(lblAthleteName);
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "InfoCard";
            Size = new Size(304, 312);
            ((ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void InfoCard_Load_1(object sender, EventArgs e)
        {

        }

        private Label lblAthleteName;
        private Label lblAthleteNationality;
        private Label lblAthletePosition;
        private Label lblAthleteTeam;
        private Label lblAthleteHeight;
        private Label lblAthleteAge;
        private PictureBox pictureBox1;
        private Label lblAthleteWeight;

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
