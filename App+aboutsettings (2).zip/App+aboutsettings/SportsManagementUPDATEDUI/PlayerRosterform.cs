﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class AthleteRoster : Form
    {
        public AthleteRoster()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string selectedAthlete = listBox1.SelectedItem.ToString();
                string nationality = "Unknown";
                string position = "Unknown";
                string team = "Unknown";
                string height = "Unknown";
                string weight = "Unknown";
                string age = "Unknown";



                if (selectedAthlete == "John Lansing")
                {
                    nationality = "American";
                    position = "QuarterBack";
                    team = "American Football Team";
                    height = "6'3 (190.5 cm)";
                    weight = "225 lbs (102 kg)";
                    age = "27";

                }


                if (selectedAthlete == "Robert Wayne")
                {
                    nationality = "American";
                    position = "Wide Receiver";
                    team = "American Football Team";
                    height = "6'1 (185.4 cm)";
                    weight = "210 lbs (95 kg)";
                    age = "25";
                }

                if (selectedAthlete == "Bruce Papadopoulos")
                {
                    nationality = "American";
                    position = "Linebacker";
                    team = "American Football Team";
                    height = "6'2 (187.9 cm)";
                    weight = "240 lbs (109 kg)";
                    age = "30";
                }

                if (selectedAthlete == "Steve Hornbee")
                {
                    nationality = "American";
                    position = "Running Back";
                    team = "American Football Team";
                    height = "5'11 (180.3 cm)";
                    weight = "215 lbs (97.5 kg)";
                    age = "24";
                }

                if (selectedAthlete == "Sam McQueen")
                {
                    nationality = "American";
                    position = "Tight End";
                    team = "American Football Team";
                    height = "6'4 (193 cm)";
                    weight = "250 lbs (113.4 kg)";
                    age = "28";
                }

                if (selectedAthlete == "Butch Bunyan")
                {
                    nationality = "American";
                    position = "Defensive Tackle";
                    team = "American Football Team";
                    height = "6'5 (195.6 cm)";
                    weight = "300 lbs (136 kg)";
                    age = "31";
                }

                if (selectedAthlete == "Jill Cassidy")
                {
                    nationality = "American";
                    position = "Cornerback";
                    team = "American Football Team";
                    height = "5'9 (175.3 cm)";
                    weight = "190 lbs (86.2 kg)";
                    age = "26";
                }

                if (selectedAthlete == "Hercule Paget")
                {
                    nationality = "American";
                    position = "Safety";
                    team = "American Football Team";
                    height = "6'0 (182.9 cm)";
                    weight = "205 lbs (93.2 kg)";
                    age = "29";
                }

                if (selectedAthlete == "Jamieson Hudson")
                {
                    nationality = "American";
                    position = "Offensive Tackle";
                    team = "American Football Team";
                    height = "6'6 (198.1 cm)";
                    weight = "320 lbs (145.1 kg)";
                    age = "32";
                }

                if (selectedAthlete == "Merriam Spencer")
                {
                    nationality = "American";
                    position = "Kicker";
                    team = "American Football Team";
                    height = "5'10 (177.8 cm)";
                    weight = "180 lbs (81.6 kg)";
                    age = "23";
                }

                if (selectedAthlete == "Jamie Webster")
                {
                    nationality = "American";
                    position = "Defensive End";
                    team = "American Football Team";
                    height = "6'3 (190.5 cm)";
                    weight = "275 lbs (124.7 kg)";
                    age = "27";
                }

                if (selectedAthlete == "Lisa McIntoss")
                {
                    nationality = "American";
                    position = "Fullback";
                    team = "American Football Team";
                    height = "5'8 (172.7 cm)";
                    weight = "195 lbs (88.5 kg)";
                    age = "24";
                }

                if (selectedAthlete == "Lorem Ipsum")
                {
                    nationality = "American";
                    position = "Wide Reciever";
                    team = "American Football Team";
                    height = "6'0 (182.9 cm)";
                    weight = "210 lbs (95 kg)";
                    age = "25";
                }

                if (selectedAthlete == "Ramjo Bolbolas")
                {
                    nationality = "American";
                    position = "Quarterback";
                    team = "American Football Team";
                    height = "6'4 (193 cm)";
                    weight = "230 lbs (104.3 kg)";
                    age = "26";
                }

                if (selectedAthlete == "Penny Chateaubout")
                {
                    nationality = "American";
                    position = "Running Back";
                    team = "American Football Team";
                    height = "5'7 (170.2 cm)";
                    weight = "195 lbs (88.5 kg)";
                    age = "22";
                }

                if (selectedAthlete == "Nimby Yimby")
                {
                    nationality = "American";
                    position = "Offensive Guard";
                    team = "American Football Team";
                    height = "6'2 (187.9 cm)";
                    weight = "305 lbs (138.3 kg)";
                    age = "27";
                }

                if (selectedAthlete == "Yimby Nimby")
                {
                    nationality = "American";
                    position = "Tight End";
                    team = "American Football Team";
                    height = "6'0 (182.9 cm)";
                    weight = "240 lbs (108.9 kg)";
                    age = "29";
                }

                if (selectedAthlete == "Theo McIntoss")
                {
                    nationality = "American";
                    position = "Defensive Back";
                    team = "American Football Team";
                    height = "5'11 (180.3 cm)";
                    weight = "200 lbs (90.7 kg)";
                    age = "24";
                }

                if (selectedAthlete == "Alexa Amanda")
                {
                    nationality = "American";
                    position = "Wide Reciever";
                    team = "American Football Team";
                    height = "5'9 (175.3 cm)";
                    weight = "170 lbs (77.1 kg)";
                    age = "23";
                }

                if (selectedAthlete == "Bud Flambeau")
                {
                    nationality = "American";
                    position = "Offensive Tackle";
                    team = "American Football Team";
                    height = "6'5 (195.6 cm)";
                    weight = "325 lbs (147.4 kg)";
                    age = "32";
                }

                if (selectedAthlete == "Burt Bogart")
                {
                    nationality = "American";
                    position = "Defensive Lineman";
                    team = "American Football Team";
                    height = "6'4 (193 cm)";
                    weight = "275 lbs (124.7 kg)";
                    age = "30";
                };



                // Create an instance of the InfoCard user control
                InfoCard infoCard = new InfoCard();

                // Set the details for the selected athlete
                infoCard.SetAthleteDetails(selectedAthlete, nationality, position, team, height, weight, age);


                // Optionally, create a new form to display the InfoCard
                Form infoCardForm = new Form(); // Create a new form
                infoCardForm.Controls.Add(infoCard); // Add the InfoCard to the form
                infoCard.Dock = DockStyle.Fill; // Make the InfoCard fill the form
                infoCardForm.Text = "Athlete Info"; // Set the title for the form
                infoCardForm.StartPosition = FormStartPosition.CenterParent; // Center the form

                // Show the form as a modal dialog
                infoCardForm.ShowDialog();
            }

        }
    }
}
