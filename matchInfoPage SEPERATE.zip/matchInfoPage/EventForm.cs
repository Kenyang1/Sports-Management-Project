﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;  // For MSSQL database connection

namespace matchInfoPage
{
    public partial class EventForm : Form
    {
        // Connection to Database
        // String connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\kenya\OneDrive\Desktop\CS217-CS250\matchInfoPage\MatchTestDatabase.mdf;Integrated Security=True;";

        public EventForm()
        {
            InitializeComponent();
        }

        private void EventForm_Load(object sender, EventArgs e)
        {
            // Populate txtdate with selected date information
            txtdate.Text = UserControlDays.static_day + "/" + Form1.static_year;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            // Using SqlConnection for MSSQL database
            /* SqlConnection conn = new SqlConnection(connString);
            try
            {
                // SQL Insert query using parameters
                String sql = "INSERT INTO tbl_calendar(date, event) VALUES (@date, @event)";
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = sql;

                // Adding values from textboxes to SQL parameters
                cmd.Parameters.AddWithValue("@date", txtdate.Text);
                cmd.Parameters.AddWithValue("@event", txtevent.Text);

                // Open connection, execute query, and show confirmation
                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Saved successfully!");
            }
            catch (Exception ex)
            {
                // Handle potential errors
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                // Ensure connection is closed after execution
                conn.Close();
            */
            }
        }
    }

