﻿namespace matchInfoPage
{
    partial class UserControlDays
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbday = new Label();
            SuspendLayout();
            // 
            // lbday
            // 
            lbday.AutoSize = true;
            lbday.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold);
            lbday.Location = new Point(214, 43);
            lbday.Name = "lbday";
            lbday.Size = new Size(59, 40);
            lbday.TabIndex = 1;
            lbday.Text = "00";
            // 
            // UserControlDays
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(lbday);
            Name = "UserControlDays";
            Size = new Size(323, 243);
            Load += UserControlDays_Load;
            Click += UserControlDays_Click;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbday;
    }
}
