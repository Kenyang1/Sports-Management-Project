﻿namespace matchInfoPage
{
    partial class EventForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtdate = new TextBox();
            txtevent = new TextBox();
            btnsave = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(75, 74);
            label1.Name = "label1";
            label1.Size = new Size(77, 41);
            label1.TabIndex = 0;
            label1.Text = "date";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(77, 272);
            label2.Name = "label2";
            label2.Size = new Size(91, 41);
            label2.TabIndex = 1;
            label2.Text = "event";
            // 
            // txtdate
            // 
            txtdate.Font = new Font("Monotxt_IV25", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtdate.Location = new Point(77, 145);
            txtdate.Name = "txtdate";
            txtdate.Size = new Size(745, 45);
            txtdate.TabIndex = 2;
            // 
            // txtevent
            // 
            txtevent.Font = new Font("Monotxt_IV25", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtevent.Location = new Point(75, 377);
            txtevent.Name = "txtevent";
            txtevent.Size = new Size(745, 45);
            txtevent.TabIndex = 3;
            // 
            // btnsave
            // 
            btnsave.Enabled = false;
            btnsave.Location = new Point(683, 522);
            btnsave.Name = "btnsave";
            btnsave.Size = new Size(139, 77);
            btnsave.TabIndex = 4;
            btnsave.Text = "Save";
            btnsave.UseVisualStyleBackColor = true;
            btnsave.Click += btnsave_Click;
            // 
            // EventForm
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(896, 823);
            Controls.Add(btnsave);
            Controls.Add(txtevent);
            Controls.Add(txtdate);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "EventForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EventForm";
            Load += EventForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtdate;
        private TextBox txtevent;
        private Button btnsave;
    }
}