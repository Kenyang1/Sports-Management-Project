﻿/*
 * Authors: Authors: Hamza, Ed, Nick, Camdyn, Kenyang, and Soham
 * Date: 7:44 PM 11/4/2024
 * Purpose: Defines the coach roster.
 */

// The C# "equivalent" of using directives in C++. How does it work without includes?
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    // a "list" of coaches
    public partial class CoachRoster : Form
    {
//------------ Setup the Roster -------------------------------------------------------------------

        private ProgDB context; // creates a new DB "session"
        
        // initialize the roster, i.e., load the coaches from the DB
        public CoachRoster()
        {
            InitializeComponent();
            reload_size(); // refresh the roster size
            context = new ProgDB();
            context.Database.EnsureCreated(); // verify that the DB exists
            load_coaches(); // display the coaches as a list
        }

        // "refreshes" the roster size
        private void reload_size()
        {
            // overwrite the GUI label with the new size
            label1.Text = "Roster size: " + listBox1.Items.Count.ToString();
        }

//------------ "Button Events Related to the DB" --------------------------------------------------

        // adds a coach to the roster list given their bio data
        private void button1_Click_1(object sender, EventArgs e)
        {
            // create a new coach from the text boxs' extracted values (bio data)
            var coach = new Coach()
            {
                id = (int)numericUpDown2.Value,
                first_name = textBox1.Text.ToString(),
                last_name = textBox2.Text.ToString(),
                age = ((int)numericUpDown1.Value)

            };
            // determine if the fields have been filled out, add the coach if they are filled out
            if (is_valid_coach(coach))
            {
                context.Coachs.Add(coach); // add the newly created coach to the coach's table
                context.SaveChanges(); // save the changes made to the DB after adding the coach
                load_coaches(); // refreshes the coach roster with the updated data
            }
            else
            {
                MessageBox.Show("Error: all fields must be filled out.");
            }
        }

        // deletes a coach from the roster list given the current selection
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature is a work-in-progress.");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
            comboBox1.Text = "";
        }

        // load/"refresh" the coach roster
        private void load_coaches()
        {
            // clear/empty the list box
            listBox1.Items.Clear();

            // load coaches from the DB
            var coaches = context.Coachs.ToList();
            foreach (var coach in coaches)
            {
                // add each coach to the roster as a string of the their members/columns
                listBox1.Items.Add($"{coach.id}. {coach.first_name} {coach.last_name}; " +
                    $"{coach.age.ToString()}");
            }
            reload_size(); // "refresh" the roster size
        }

        private bool is_valid_coach(Coach a_coach)
        {
            return a_coach.id != 0 && a_coach.first_name != "" && a_coach.last_name != "";
        }

//------------ Miscellaneous "Methods" & Don't Delete Methods -------------------------------------

        /* Do not delete this function, otherwise it will produce an error. I gave up trying to 
         * understand why the latter happens. Perhaps the drag-and-drop convenience of WinForms 
         * doesn't correlate with an understanding of C#. Well, it figures.
         */
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        // The same rehash. DO NOT delete this function, otherwise it will produce an error
        private void label5_Click(object sender, EventArgs e)
        {
        }

        // ignore this dumpster fire of a "method", the commented code may still be of use to us
        // in other words, don't delete it
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("Age: 45;", "", 0);
            //CoachInfoCard coachInfoCard = new CoachInfoCard(); // Create an info card control

            //Form infoCard = new Form(); // Create a new form
            //infoCard.Controls.Add(coachInfoCard); // Add the info card to the form
            //infoCard.Dock = DockStyle.Fill; // Fill the info card inside the form
            //// Resize the form to the control's size
            //infoCard.ClientSize = new Size(coachInfoCard.Width, coachInfoCard.Height);
            //infoCard.Show(); // Display the info card
            //load_coaches();
        }
    }
}
