﻿/*
    Authors: Hamza, Ed, Nick, Camdyn, Kenyang, and Soham
    Date: 6:50 PM 12/9/2024
    Purpose: Defines the interface of the athlete roster info card
*/

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class Ath_info_card : UserControl
    {
        private ProgDB context; // creates a new DB "session"
        private Athlete selection; // selected athlete
        public Ath_info_card()
        {
            InitializeComponent();
            context = new ProgDB();
            context.Database.EnsureCreated(); // does the DB exists?

            // Added by Camdyn
            // Hide buttons based on the property
            this.Load += (s, e) =>
            {
                save.Visible = !HideButtons;
                clr_flds.Visible = !HideButtons;
            };
            // Ends here
        }

        public bool HideButtons { get; set; } // Property to control button visibility

        // populate the fields upon selection
        public void fill_fields(Athlete athlete)
        {
            selection = athlete;
            textBox1.Text = athlete.first_name;
            textBox2.Text = athlete.last_name;
            numericUpDown1.Value = athlete.age;
            comboBox1.SelectedItem = athlete.position;
            numericUpDown2.Value = athlete.id;
            numericUpDown3.Value = athlete.weight;
            numericUpDown4.Value = athlete.height;

            numericUpDown5.Value = athlete.days_attended;
            checkBox1.Checked = athlete.is_ath_of_wk;
        }

        // data validation
        private bool is_valid_ath(Athlete x)
        {
            return x.id != 0 && x.first_name != "" && x.last_name != "" && x.age > 0
                && x.position != "";
        }

        // add or edit the athlete to the DB
        private void save_Click(object sender, EventArgs e)
        {
            // create a new athlete from extracted values
            var ath = new Athlete()
            {
                id = ((int)numericUpDown2.Value),
                first_name = textBox1.Text.ToString(),
                last_name = textBox2.Text.ToString(),
                age = ((int)numericUpDown1.Value),
                position = comboBox1.Text.ToString(),
                weight = ((int)numericUpDown3.Value),
                height = ((int)numericUpDown4.Value),
                days_attended = ((int)numericUpDown5.Value),
                is_ath_of_wk = checkBox1.Checked
            };
            if (context.Athletes.Any(x => x.id == ath.id)) { // edit the athlete
                var selection = context.Athletes.SingleOrDefault(x => x.id == ath.id);
                context.Entry(selection).CurrentValues.SetValues(ath);
                context.SaveChanges();
            }
            else { // add the athlete
                if (is_valid_ath(ath)) {
                    context.Athletes.Add(ath); // add to the athlete table
                    context.SaveChanges();
                }
                else {
                    MessageBox.Show("Error: all fields must be filled out.");
                }
            }
        }

        // clear all fields
        private void clr_flds_Click(object sender, EventArgs e)
        {
            const string empty_field = "";
            textBox1.Text = empty_field;
            textBox2.Text = empty_field;
            numericUpDown1.Value = 0.0m;
            numericUpDown3.Value = 0.0m;
            numericUpDown4.Value = 0.0m;
            numericUpDown5.Value = 0;
            checkBox1.Checked = false;
            comboBox1.SelectedItem = "N/A";
        }

    }
}