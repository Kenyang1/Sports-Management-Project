﻿/*
    Authors: Hamza, Ed, Nick, Camdyn, Kenyang, and Soham
    Date: 7:44 PM 11/4/2024
    Purpose: Defines the interface of the coach roster info card
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace SportsManagement_Dashboard
{
    public partial class Ch_info_card : UserControl
    {
        private ProgDB context; // creates a new DB "session"
        private Coach selection; // selected coach

        public Ch_info_card()
        {
            InitializeComponent();
            context = new ProgDB();
            context.Database.EnsureCreated(); // does the DB exists?
        }

        // populate the fields upon selection
        public void fill_fields(Coach x)
        {
            selection = x;
            textBox1.Text = x.first_name;
            textBox2.Text = x.last_name;
            numericUpDown1.Value = x.age;
            comboBox1.SelectedItem = x.position;
            numericUpDown2.Value = x.id;
        }

        // data validation
        private bool is_valid_coach(Coach x)
        {
            return x.id != 0 && x.first_name != "" && x.last_name != "" && x.age > 0
                && x.position != "";
        }

        // add or edit the coach to the DB
        private void save_Click(object sender, EventArgs e)
        {
            // create a new coach from extracted values
            var ch = new Coach()
            {
                id = ((int)numericUpDown2.Value),
                first_name = textBox1.Text.ToString(),
                last_name = textBox2.Text.ToString(),
                age = ((int)numericUpDown1.Value),
                position = comboBox1.Text.ToString(),
            };
            if (context.Coachs.Any(x => x.id == ch.id)) { // edit the coach
                var selection = context.Coachs.SingleOrDefault(x => x.id == ch.id);
                context.Entry(selection).CurrentValues.SetValues(ch);
                context.SaveChanges();
            }
            else { // add the coach
                if (is_valid_coach(ch)) {
                    context.Coachs.Add(ch); // add to the coach table
                    context.SaveChanges();
                }
                else {
                    MessageBox.Show("Error: all fields must be filled out.");
                }
            }
        }

        // clear all fields
        private void clr_flds_Click(object sender, EventArgs e)
        {
            const string empty_field = "";
            textBox1.Text = empty_field;
            textBox2.Text = empty_field;
            numericUpDown1.Value = 0.0m;
            comboBox1.SelectedItem = "N/A";
        }
    }
}
