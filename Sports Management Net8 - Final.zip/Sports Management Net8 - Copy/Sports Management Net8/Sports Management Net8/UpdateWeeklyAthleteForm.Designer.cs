﻿namespace Sports_Management_Net8
{
    partial class UpdateWeeklyAthleteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbAthletes = new ComboBox();
            cmbDeleteAthlete = new ComboBox();
            btnAddWeeklyAthleteInfo = new Button();
            btnDeleteWeeklyAthlete = new Button();
            txtAccomplishments = new TextBox();
            SuspendLayout();
            // 
            // cmbAthletes
            // 
            cmbAthletes.FormattingEnabled = true;
            cmbAthletes.Location = new Point(107, 46);
            cmbAthletes.Name = "cmbAthletes";
            cmbAthletes.Size = new Size(151, 28);
            cmbAthletes.TabIndex = 0;
            cmbAthletes.Text = "Athlete to Add";
            // 
            // cmbDeleteAthlete
            // 
            cmbDeleteAthlete.FormattingEnabled = true;
            cmbDeleteAthlete.Location = new Point(107, 217);
            cmbDeleteAthlete.Name = "cmbDeleteAthlete";
            cmbDeleteAthlete.Size = new Size(151, 28);
            cmbDeleteAthlete.TabIndex = 1;
            cmbDeleteAthlete.Text = "Athlete To Delete";
            // 
            // btnAddWeeklyAthleteInfo
            // 
            btnAddWeeklyAthleteInfo.Location = new Point(132, 143);
            btnAddWeeklyAthleteInfo.Name = "btnAddWeeklyAthleteInfo";
            btnAddWeeklyAthleteInfo.Size = new Size(94, 29);
            btnAddWeeklyAthleteInfo.TabIndex = 2;
            btnAddWeeklyAthleteInfo.Text = "Add";
            btnAddWeeklyAthleteInfo.UseVisualStyleBackColor = true;
            btnAddWeeklyAthleteInfo.Click += btnAddWeeklyAthleteInfo_Click;
            // 
            // btnDeleteWeeklyAthlete
            // 
            btnDeleteWeeklyAthlete.Location = new Point(132, 267);
            btnDeleteWeeklyAthlete.Name = "btnDeleteWeeklyAthlete";
            btnDeleteWeeklyAthlete.Size = new Size(94, 29);
            btnDeleteWeeklyAthlete.TabIndex = 3;
            btnDeleteWeeklyAthlete.Text = "Remove";
            btnDeleteWeeklyAthlete.UseVisualStyleBackColor = true;
            btnDeleteWeeklyAthlete.Click += btnDeleteAthlete_Click;
            // 
            // txtAccomplishments
            // 
            txtAccomplishments.Location = new Point(118, 90);
            txtAccomplishments.Name = "txtAccomplishments";
            txtAccomplishments.Size = new Size(125, 27);
            txtAccomplishments.TabIndex = 4;
            txtAccomplishments.Text = "Accomplishments";
            // 
            // UpdateWeeklyAthleteForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(368, 450);
            Controls.Add(txtAccomplishments);
            Controls.Add(btnDeleteWeeklyAthlete);
            Controls.Add(btnAddWeeklyAthleteInfo);
            Controls.Add(cmbDeleteAthlete);
            Controls.Add(cmbAthletes);
            Name = "UpdateWeeklyAthleteForm";
            Text = "UpdateWeeklyAthleteForm";
            Load += UpdateWeeklyAthleteForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbAthletes;
        private ComboBox cmbDeleteAthlete;
        private Button btnAddWeeklyAthleteInfo;
        private Button btnDeleteWeeklyAthlete;
        private TextBox txtAccomplishments;
    }
}