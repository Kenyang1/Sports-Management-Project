﻿namespace Sports_Management_Net8
{
    partial class TeamDataForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridViewTeamStats = new DataGridView();
            statIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            statNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            statDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            teamStatsBindingSource = new BindingSource(components);
            saveButton = new Button();
            backButton = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTeamStats).BeginInit();
            ((System.ComponentModel.ISupportInitialize)teamStatsBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewTeamStats
            // 
            dataGridViewTeamStats.AutoGenerateColumns = false;
            dataGridViewTeamStats.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewTeamStats.Columns.AddRange(new DataGridViewColumn[] { statIdDataGridViewTextBoxColumn, statNameDataGridViewTextBoxColumn, statDataGridViewTextBoxColumn });
            dataGridViewTeamStats.DataSource = teamStatsBindingSource;
            dataGridViewTeamStats.Location = new Point(1, 2);
            dataGridViewTeamStats.Name = "dataGridViewTeamStats";
            dataGridViewTeamStats.Size = new Size(344, 248);
            dataGridViewTeamStats.TabIndex = 0;
            // 
            // statIdDataGridViewTextBoxColumn
            // 
            statIdDataGridViewTextBoxColumn.DataPropertyName = "StatId";
            statIdDataGridViewTextBoxColumn.HeaderText = "StatId";
            statIdDataGridViewTextBoxColumn.Name = "statIdDataGridViewTextBoxColumn";
            statIdDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // statNameDataGridViewTextBoxColumn
            // 
            statNameDataGridViewTextBoxColumn.DataPropertyName = "StatName";
            statNameDataGridViewTextBoxColumn.HeaderText = "StatName";
            statNameDataGridViewTextBoxColumn.Name = "statNameDataGridViewTextBoxColumn";
            // 
            // statDataGridViewTextBoxColumn
            // 
            statDataGridViewTextBoxColumn.DataPropertyName = "Stat";
            statDataGridViewTextBoxColumn.HeaderText = "Stat";
            statDataGridViewTextBoxColumn.Name = "statDataGridViewTextBoxColumn";
            // 
            // teamStatsBindingSource
            // 
            teamStatsBindingSource.DataSource = typeof(TeamStats);
            // 
            // saveButton
            // 
            saveButton.Location = new Point(1, 256);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(75, 23);
            saveButton.TabIndex = 1;
            saveButton.Text = "Save";
            saveButton.UseVisualStyleBackColor = true;
            saveButton.Click += saveButton_Click_1;
            // 
            // backButton
            // 
            backButton.Location = new Point(82, 256);
            backButton.Name = "backButton";
            backButton.Size = new Size(75, 23);
            backButton.TabIndex = 2;
            backButton.Text = "Back";
            backButton.UseVisualStyleBackColor = true;
            backButton.Click += backButton_Click;
            // 
            // TeamDataForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(354, 284);
            Controls.Add(backButton);
            Controls.Add(saveButton);
            Controls.Add(dataGridViewTeamStats);
            Name = "TeamDataForm";
            Text = "TeamDataForm";
            ((System.ComponentModel.ISupportInitialize)dataGridViewTeamStats).EndInit();
            ((System.ComponentModel.ISupportInitialize)teamStatsBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewTeamStats;
        private BindingSource teamStatsBindingSource;
        private Button saveButton;
        private DataGridViewTextBoxColumn statIdDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn statNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn statDataGridViewTextBoxColumn;
        private Button backButton;
    }
}