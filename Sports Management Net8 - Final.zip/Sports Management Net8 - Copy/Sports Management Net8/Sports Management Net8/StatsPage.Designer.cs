﻿namespace SportsManagement_Dashboard
{
    partial class StatsPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addStatsButton = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            label26 = new Label();
            SuspendLayout();
            // 
            // addStatsButton
            // 
            addStatsButton.Location = new Point(318, 388);
            addStatsButton.Name = "addStatsButton";
            addStatsButton.Size = new Size(85, 22);
            addStatsButton.TabIndex = 0;
            addStatsButton.Text = "Add Stats";
            addStatsButton.UseVisualStyleBackColor = true;
            addStatsButton.Click += addStatsButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nirmala UI", 24F);
            label1.ForeColor = Color.CornflowerBlue;
            label1.Location = new Point(273, 9);
            label1.Name = "label1";
            label1.Size = new Size(181, 45);
            label1.TabIndex = 1;
            label1.Text = "Team Stats ";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.System;
            label2.Font = new Font("Nirmala UI", 16F);
            label2.ForeColor = Color.CornflowerBlue;
            label2.Location = new Point(12, 63);
            label2.Name = "label2";
            label2.Size = new Size(84, 30);
            label2.TabIndex = 2;
            label2.Text = "Patriots";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.System;
            label3.Font = new Font("Nirmala UI", 16F);
            label3.ForeColor = Color.CornflowerBlue;
            label3.Location = new Point(576, 63);
            label3.Name = "label3";
            label3.Size = new Size(112, 30);
            label3.TabIndex = 3;
            label3.Text = "Opponent";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Nirmala UI", 14F);
            label4.ForeColor = Color.CornflowerBlue;
            label4.Location = new Point(275, 97);
            label4.Name = "label4";
            label4.Size = new Size(154, 25);
            label4.TabIndex = 4;
            label4.Text = "Total First Downs";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Nirmala UI", 14F);
            label5.ForeColor = Color.CornflowerBlue;
            label5.Location = new Point(268, 137);
            label5.Name = "label5";
            label5.Size = new Size(186, 25);
            label5.TabIndex = 5;
            label5.Text = "Total Offensive Yards";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Nirmala UI", 14F);
            label6.ForeColor = Color.CornflowerBlue;
            label6.Location = new Point(268, 175);
            label6.Name = "label6";
            label6.Size = new Size(175, 25);
            label6.TabIndex = 6;
            label6.Text = "Total Rushing Yards";
            label6.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Nirmala UI", 14F);
            label7.ForeColor = Color.CornflowerBlue;
            label7.Location = new Point(268, 211);
            label7.Name = "label7";
            label7.Size = new Size(170, 25);
            label7.TabIndex = 7;
            label7.Text = "Total Passing Yards";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Nirmala UI", 14F);
            label8.ForeColor = Color.CornflowerBlue;
            label8.Location = new Point(321, 246);
            label8.Name = "label8";
            label8.Size = new Size(58, 25);
            label8.TabIndex = 8;
            label8.Text = "Sacks";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Nirmala UI", 14F);
            label9.ForeColor = Color.CornflowerBlue;
            label9.Location = new Point(299, 281);
            label9.Name = "label9";
            label9.Size = new Size(104, 25);
            label9.TabIndex = 9;
            label9.Text = "Field Goals";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Nirmala UI", 14F);
            label10.ForeColor = Color.CornflowerBlue;
            label10.Location = new Point(295, 315);
            label10.Name = "label10";
            label10.Size = new Size(117, 25);
            label10.TabIndex = 10;
            label10.Text = "Touchdowns";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Nirmala UI", 14F);
            label11.ForeColor = Color.CornflowerBlue;
            label11.Location = new Point(295, 350);
            label11.Name = "label11";
            label11.Size = new Size(134, 25);
            label11.TabIndex = 11;
            label11.Text = "Turnover Ratio";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Nirmala UI", 10F);
            label12.ForeColor = SystemColors.Control;
            label12.Location = new Point(33, 103);
            label12.Name = "label12";
            label12.Size = new Size(33, 19);
            label12.TabIndex = 12;
            label12.Text = "243";
            label12.Click += label12_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Nirmala UI", 10F);
            label13.ForeColor = SystemColors.Control;
            label13.Location = new Point(33, 143);
            label13.Name = "label13";
            label13.Size = new Size(41, 19);
            label13.TabIndex = 13;
            label13.Text = "4095";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Nirmala UI", 10F);
            label14.ForeColor = SystemColors.Control;
            label14.Location = new Point(33, 181);
            label14.Name = "label14";
            label14.Size = new Size(41, 19);
            label14.TabIndex = 14;
            label14.Text = "1670";
            label14.Click += label14_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Nirmala UI", 10F);
            label15.ForeColor = SystemColors.Control;
            label15.Location = new Point(33, 217);
            label15.Name = "label15";
            label15.Size = new Size(41, 19);
            label15.TabIndex = 15;
            label15.Text = "2726";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Nirmala UI", 10F);
            label16.ForeColor = SystemColors.Control;
            label16.Location = new Point(33, 252);
            label16.Name = "label16";
            label16.Size = new Size(25, 19);
            label16.TabIndex = 16;
            label16.Text = "45";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Nirmala UI", 10F);
            label17.ForeColor = SystemColors.Control;
            label17.Location = new Point(33, 281);
            label17.Name = "label17";
            label17.Size = new Size(46, 19);
            label17.TabIndex = 17;
            label17.Text = "23/30";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Nirmala UI", 10F);
            label18.ForeColor = SystemColors.Control;
            label18.Location = new Point(33, 321);
            label18.Name = "label18";
            label18.Size = new Size(25, 19);
            label18.TabIndex = 18;
            label18.Text = "24";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Nirmala UI", 10F);
            label19.ForeColor = SystemColors.Control;
            label19.Location = new Point(33, 356);
            label19.Name = "label19";
            label19.Size = new Size(23, 19);
            label19.TabIndex = 19;
            label19.Text = "-7";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Nirmala UI", 10F);
            label20.ForeColor = SystemColors.Control;
            label20.Location = new Point(611, 103);
            label20.Name = "label20";
            label20.Size = new Size(33, 19);
            label20.TabIndex = 20;
            label20.Text = "284";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Nirmala UI", 10F);
            label21.ForeColor = SystemColors.Control;
            label21.Location = new Point(606, 143);
            label21.Name = "label21";
            label21.Size = new Size(41, 19);
            label21.TabIndex = 21;
            label21.Text = "4818";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Nirmala UI", 10F);
            label22.ForeColor = SystemColors.Control;
            label22.Location = new Point(606, 175);
            label22.Name = "label22";
            label22.Size = new Size(41, 19);
            label22.TabIndex = 22;
            label22.Text = "1784";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Nirmala UI", 10F);
            label23.ForeColor = SystemColors.Control;
            label23.Location = new Point(606, 217);
            label23.Name = "label23";
            label23.Size = new Size(41, 19);
            label23.TabIndex = 23;
            label23.Text = "3185";
            label23.Click += label23_Click;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Nirmala UI", 10F);
            label24.ForeColor = SystemColors.Control;
            label24.Location = new Point(611, 252);
            label24.Name = "label24";
            label24.Size = new Size(25, 19);
            label24.TabIndex = 24;
            label24.Text = "27";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Nirmala UI", 10F);
            label25.ForeColor = SystemColors.Control;
            label25.Location = new Point(606, 287);
            label25.Name = "label25";
            label25.Size = new Size(46, 19);
            label25.TabIndex = 25;
            label25.Text = "24/29";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Nirmala UI", 10F);
            label26.ForeColor = SystemColors.Control;
            label26.Location = new Point(611, 321);
            label26.Name = "label26";
            label26.Size = new Size(25, 19);
            label26.TabIndex = 26;
            label26.Text = "38";
            label26.Click += label26_Click;
            // 
            // StatsPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(46, 51, 73);
            ClientSize = new Size(700, 422);
            Controls.Add(label26);
            Controls.Add(label25);
            Controls.Add(label24);
            Controls.Add(label23);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(addStatsButton);
            Name = "StatsPage";
            Text = "StatsPage";
            Load += StatsPage_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button addStatsButton;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
    }
}