﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Sports_Management_Net8;

namespace SportsManagement_Dashboard
{
    public partial class StatsPage : Form
    {
        private StatsContext? dbContext;

        public StatsPage()
        {
            InitializeComponent();
        }

        private void StatsPage_Load(object sender, EventArgs e)
        {
            /*
            using (var dbContext = new StatsContext())
            {
                var team = dbContext.TeamStats.FirstOrDefault();
                var totalWins = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 1);
                var totalLoses = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 2);
                var totalYards = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 3);
                var totalRushingYards = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 4);
                var totalPassingYards = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 5);
                var totalFieldGoals = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 6);
                var totalTouchdowns = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 7);
                var totalPointsScored = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 8);
                var totalYardsAllowed = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 9);
                var totalRushingYardsAllowed = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 10);
                var totalPassingYardsAllowed = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 11);
                var totalFieldGoalsAllowed = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 12);
                var totalTouchdownsAllowed = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 13);
                var totalPointsAllowed = dbContext.TeamStats.FirstOrDefault(stat => stat.StatId == 14);
                
                                if (team != null)
                                {
                                    TotalWinsLabel.Text = $"Total Wins: {totalWins.Stat}";
                                    TotalLossesLabel.Text = $"Total Losses: {totalLoses.Stat}";
                                    TotalYardsLabel.Text = $"Total Yards: {totalYards.Stat}";
                                    TotalRushingYardsLabel.Text = $"Total Rushing Yards: {totalRushingYards.Stat}";
                                    TotalPassingYardsLabel.Text = $"Total Passing Yards: {totalPassingYards.Stat}";
                                    FieldGoalsLabel.Text = $"Total Field Goals: {totalFieldGoals.Stat}";
                                    TouchdownsLabel.Text = $"Total Touchdowns: {totalTouchdowns.Stat}";
                                    TotalPointsLabel.Text = $"Total Points: {totalPointsScored.Stat}";
                                    YardsAllowedLabel.Text = $"Total Yards Allowed: {totalYardsAllowed.Stat}";
                                    RushingYardsAllowedLabel.Text = $"Total Rushing Yards Allowed: {totalRushingYardsAllowed.Stat}";
                                    PassingYardsAllowedLabel.Text = $"Total Passing Yards Allowed: {totalPassingYardsAllowed.Stat}";
                                    TouchDownsAllowedLabel.Text = $"Total Touchdowns Allowed: {totalTouchdownsAllowed.Stat}";
                                    TotalPointsAllowedLabel.Text = $"Total Points Allowed: {totalPointsAllowed.Stat}";
                                }
            }*/
        }

        private void addStatsButton_Click(object sender, EventArgs e)
        {
            TeamDataForm teamStatsTables = new TeamDataForm();
            teamStatsTables.Show();

            //this.Close();
        }

        private void deleteStatsButton_Click(object sender, EventArgs e)
        {

        }

        private void TotalRushingYardsLabel_Click(object sender, EventArgs e)
        {

        }

        private void TeamStatsPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
        public void UpdateLabels(string text12, string text13, string text14)
        {
            label12.Text = text12;
            label13.Text = text13;
            label14.Text = text14;
        }
    }
}
