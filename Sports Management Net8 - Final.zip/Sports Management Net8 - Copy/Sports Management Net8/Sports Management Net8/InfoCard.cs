﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class InfoCard : UserControl
    {
        public InfoCard()
        {
            InitializeComponent();
        }

        public void SetAthleteDetails(string athleteName, string nationality, string position, string team, string height, string weight, string age) // You can expand this to include more details
        {
            // Assuming you have a label to display the name
            lblAthleteName.Text = athleteName;
            lblAthleteNationality.Text = nationality;
            lblAthletePosition.Text = position;
            lblAthleteTeam.Text = team;
            lblAthleteHeight.Text = height;
            lblAthleteWeight.Text = weight;
            lblAthleteAge.Text = age;
        }



        private void InfoCard_Load(object sender, EventArgs e)
        {

        }

        private void InitializeComponent()
        {
            pictureBoxAthlete = new PictureBox();
            lblAthleteName = new Label();
            lblAthletePosition = new Label();
            lblAthleteTeam = new Label();
            lblAthleteNationality = new Label();
            lblAthleteHeight = new Label();
            lblAthleteWeight = new Label();
            lblAthleteAge = new Label();
            ((ISupportInitialize)pictureBoxAthlete).BeginInit();
            SuspendLayout();
            // 
            // pictureBoxAthlete
            // 
            //pictureBoxAthlete.Image = Sports_Management_Net8.Properties.Resources.user1;
            pictureBoxAthlete.Location = new Point(86, 2);
            pictureBoxAthlete.Name = "pictureBoxAthlete";
            pictureBoxAthlete.Size = new Size(71, 58);
            pictureBoxAthlete.TabIndex = 0;
            pictureBoxAthlete.TabStop = false;
            // 
            // lblAthleteName
            // 
            lblAthleteName.AutoSize = true;
            lblAthleteName.Font = new Font("Microsoft Sans Serif", 13.8F);
            lblAthleteName.Location = new Point(63, 63);
            lblAthleteName.Name = "lblAthleteName";
            lblAthleteName.Size = new Size(135, 24);
            lblAthleteName.TabIndex = 1;
            lblAthleteName.Text = "lblAthletename";
            // 
            // lblAthletePosition
            // 
            lblAthletePosition.AutoSize = true;
            lblAthletePosition.Font = new Font("Microsoft Sans Serif", 8.25F);
            lblAthletePosition.Location = new Point(10, 107);
            lblAthletePosition.Name = "lblAthletePosition";
            lblAthletePosition.Size = new Size(35, 13);
            lblAthletePosition.TabIndex = 2;
            lblAthletePosition.Text = "label1";
            // 
            // lblAthleteTeam
            // 
            lblAthleteTeam.AutoSize = true;
            lblAthleteTeam.Font = new Font("Microsoft Sans Serif", 8.25F);
            lblAthleteTeam.Location = new Point(10, 154);
            lblAthleteTeam.Name = "lblAthleteTeam";
            lblAthleteTeam.Size = new Size(35, 13);
            lblAthleteTeam.TabIndex = 3;
            lblAthleteTeam.Text = "label1";
            // 
            // lblAthleteNationality
            // 
            lblAthleteNationality.AutoSize = true;
            lblAthleteNationality.Font = new Font("Microsoft Sans Serif", 8.25F);
            lblAthleteNationality.Location = new Point(10, 201);
            lblAthleteNationality.Name = "lblAthleteNationality";
            lblAthleteNationality.Size = new Size(35, 13);
            lblAthleteNationality.TabIndex = 4;
            lblAthleteNationality.Text = "label1";
            // 
            // lblAthleteHeight
            // 
            lblAthleteHeight.AutoSize = true;
            lblAthleteHeight.Font = new Font("Microsoft Sans Serif", 8.25F);
            lblAthleteHeight.Location = new Point(182, 107);
            lblAthleteHeight.Name = "lblAthleteHeight";
            lblAthleteHeight.Size = new Size(35, 13);
            lblAthleteHeight.TabIndex = 5;
            lblAthleteHeight.Text = "label1";
            // 
            // lblAthleteWeight
            // 
            lblAthleteWeight.AutoSize = true;
            lblAthleteWeight.Font = new Font("Microsoft Sans Serif", 8.25F);
            lblAthleteWeight.Location = new Point(182, 154);
            lblAthleteWeight.Name = "lblAthleteWeight";
            lblAthleteWeight.Size = new Size(35, 13);
            lblAthleteWeight.TabIndex = 6;
            lblAthleteWeight.Text = "label1";
            // 
            // lblAthleteAge
            // 
            lblAthleteAge.AutoSize = true;
            lblAthleteAge.Font = new Font("Microsoft Sans Serif", 8.25F);
            lblAthleteAge.Location = new Point(182, 201);
            lblAthleteAge.Name = "lblAthleteAge";
            lblAthleteAge.Size = new Size(35, 13);
            lblAthleteAge.TabIndex = 7;
            lblAthleteAge.Text = "label1";
            // 
            // InfoCard
            // 
            Controls.Add(lblAthleteAge);
            Controls.Add(lblAthleteWeight);
            Controls.Add(lblAthleteHeight);
            Controls.Add(lblAthleteNationality);
            Controls.Add(lblAthleteTeam);
            Controls.Add(lblAthletePosition);
            Controls.Add(lblAthleteName);
            Controls.Add(pictureBoxAthlete);
            Name = "InfoCard";
            Size = new Size(242, 254);
            ((ISupportInitialize)pictureBoxAthlete).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void InfoCard_Load_1(object sender, EventArgs e)
        {

        }

        private PictureBox pictureBoxAthlete;
        private Label lblAthletePosition;
        private Label lblAthleteTeam;
        private Label lblAthleteNationality;
        private Label lblAthleteHeight;
        private Label lblAthleteWeight;
        private Label lblAthleteAge;
        private Label lblAthleteName;
    }
}
