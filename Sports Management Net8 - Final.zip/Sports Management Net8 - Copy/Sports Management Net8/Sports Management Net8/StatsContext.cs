﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Sports_Management_Net8
{
    public class StatsContext : DbContext
    {
        
        public DbSet<TeamStats> TeamStats { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            => optionsBuilder.UseSqlite("Data Source =teamstats.db");
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TeamStats>()
        .HasKey(ts => ts.StatId);
            modelBuilder.Entity<TeamStats>().HasData(
                new TeamStats { StatId = 1, StatName = "First Downs", Stat = 0 },
                new TeamStats { StatId = 2, StatName = "Offensive Yards", Stat = 0 },
                new TeamStats { StatId = 3, StatName = "Rushing Yards", Stat = 0 },
                new TeamStats { StatId = 4, StatName = "Passing Yards", Stat = 0 },
                new TeamStats { StatId = 5, StatName = "Sacks", Stat = 0 },
                new TeamStats { StatId = 6, StatName = "Field Goals", Stat = 0 },
                new TeamStats { StatId = 7, StatName = "Touchdowns", Stat = 0 },
                new TeamStats { StatId = 8, StatName = "Opponent First Downs", Stat = 0 },
                new TeamStats { StatId = 9, StatName = "Opponent Offensive Yards", Stat = 0 },
                new TeamStats { StatId = 10, StatName = "Opponent Rushing Yards", Stat = 0 },
                new TeamStats { StatId = 11, StatName = "Opponent Passing Yards", Stat = 0 },
                new TeamStats { StatId = 12, StatName = "Opponent Sacks", Stat = 0 },
                new TeamStats { StatId = 13, StatName = "Opponent Field Goals", Stat = 0 },
                new TeamStats { StatId = 14, StatName = "Opponent Touchdowns", Stat = 0 });
        }
    }
}
