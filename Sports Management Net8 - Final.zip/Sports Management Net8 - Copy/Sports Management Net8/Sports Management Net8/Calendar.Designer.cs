﻿
namespace matchInfoPage
{
    partial class Calendar
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnNext = new Button();
            btnPrevious = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            dayContainer = new FlowLayoutPanel();
            panel2 = new Panel();
            panel1 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            panel8 = new Panel();
            panel9 = new Panel();
            panel10 = new Panel();
            panel11 = new Panel();
            panel12 = new Panel();
            panel13 = new Panel();
            panel14 = new Panel();
            panel15 = new Panel();
            panel16 = new Panel();
            panel17 = new Panel();
            panel18 = new Panel();
            panel19 = new Panel();
            panel20 = new Panel();
            panel21 = new Panel();
            panel22 = new Panel();
            panel23 = new Panel();
            panel24 = new Panel();
            panel25 = new Panel();
            panel26 = new Panel();
            panel27 = new Panel();
            panel28 = new Panel();
            panel29 = new Panel();
            panel30 = new Panel();
            panel31 = new Panel();
            panel32 = new Panel();
            panel33 = new Panel();
            panel34 = new Panel();
            panel35 = new Panel();
            panel36 = new Panel();
            panel37 = new Panel();
            panel38 = new Panel();
            panel39 = new Panel();
            panel40 = new Panel();
            panel41 = new Panel();
            panel42 = new Panel();
            LBDATE = new Label();
            button1 = new Button();
            dayContainer.SuspendLayout();
            SuspendLayout();
            // 
            // btnNext
            // 
            btnNext.Location = new Point(902, 615);
            btnNext.Margin = new Padding(1);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(77, 21);
            btnNext.TabIndex = 1;
            btnNext.Text = "Next";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click;
            // 
            // btnPrevious
            // 
            btnPrevious.Location = new Point(823, 615);
            btnPrevious.Margin = new Padding(1);
            btnPrevious.Name = "btnPrevious";
            btnPrevious.Size = new Size(77, 21);
            btnPrevious.TabIndex = 2;
            btnPrevious.Text = "Previous";
            btnPrevious.UseVisualStyleBackColor = true;
            btnPrevious.Click += btnPrevious_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(56, 28);
            label1.Margin = new Padding(1, 0, 1, 0);
            label1.Name = "label1";
            label1.Size = new Size(61, 16);
            label1.TabIndex = 3;
            label1.Text = "Sunday";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(204, 28);
            label2.Margin = new Padding(1, 0, 1, 0);
            label2.Name = "label2";
            label2.Size = new Size(61, 16);
            label2.TabIndex = 4;
            label2.Text = "Monday";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(455, 28);
            label3.Margin = new Padding(1, 0, 1, 0);
            label3.Name = "label3";
            label3.Size = new Size(88, 16);
            label3.TabIndex = 6;
            label3.Text = "Wednesday";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(326, 28);
            label4.Margin = new Padding(1, 0, 1, 0);
            label4.Name = "label4";
            label4.Size = new Size(70, 16);
            label4.TabIndex = 5;
            label4.Text = "Tuesday";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(868, 28);
            label6.Margin = new Padding(1, 0, 1, 0);
            label6.Name = "label6";
            label6.Size = new Size(79, 16);
            label6.TabIndex = 9;
            label6.Text = "Saturday";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(740, 28);
            label7.Margin = new Padding(1, 0, 1, 0);
            label7.Name = "label7";
            label7.Size = new Size(61, 16);
            label7.TabIndex = 8;
            label7.Text = "Friday";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(595, 28);
            label8.Margin = new Padding(1, 0, 1, 0);
            label8.Name = "label8";
            label8.Size = new Size(79, 16);
            label8.TabIndex = 7;
            label8.Text = "Thursday";
            // 
            // dayContainer
            // 
            dayContainer.Controls.Add(panel2);
            dayContainer.Controls.Add(panel1);
            dayContainer.Controls.Add(panel3);
            dayContainer.Controls.Add(panel4);
            dayContainer.Controls.Add(panel5);
            dayContainer.Controls.Add(panel6);
            dayContainer.Controls.Add(panel7);
            dayContainer.Controls.Add(panel8);
            dayContainer.Controls.Add(panel9);
            dayContainer.Controls.Add(panel10);
            dayContainer.Controls.Add(panel11);
            dayContainer.Controls.Add(panel12);
            dayContainer.Controls.Add(panel13);
            dayContainer.Controls.Add(panel14);
            dayContainer.Controls.Add(panel15);
            dayContainer.Controls.Add(panel16);
            dayContainer.Controls.Add(panel17);
            dayContainer.Controls.Add(panel18);
            dayContainer.Controls.Add(panel19);
            dayContainer.Controls.Add(panel20);
            dayContainer.Controls.Add(panel21);
            dayContainer.Controls.Add(panel22);
            dayContainer.Controls.Add(panel23);
            dayContainer.Controls.Add(panel24);
            dayContainer.Controls.Add(panel25);
            dayContainer.Controls.Add(panel26);
            dayContainer.Controls.Add(panel27);
            dayContainer.Controls.Add(panel28);
            dayContainer.Controls.Add(panel29);
            dayContainer.Controls.Add(panel30);
            dayContainer.Controls.Add(panel31);
            dayContainer.Controls.Add(panel32);
            dayContainer.Controls.Add(panel33);
            dayContainer.Controls.Add(panel34);
            dayContainer.Controls.Add(panel35);
            dayContainer.Controls.Add(panel36);
            dayContainer.Controls.Add(panel37);
            dayContainer.Controls.Add(panel38);
            dayContainer.Controls.Add(panel39);
            dayContainer.Controls.Add(panel40);
            dayContainer.Controls.Add(panel41);
            dayContainer.Controls.Add(panel42);
            dayContainer.Location = new Point(31, 54);
            dayContainer.Margin = new Padding(1);
            dayContainer.Name = "dayContainer";
            dayContainer.Size = new Size(948, 546);
            dayContainer.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.Location = new Point(1, 1);
            panel2.Margin = new Padding(1);
            panel2.Name = "panel2";
            panel2.Size = new Size(133, 89);
            panel2.TabIndex = 1;
            panel2.Paint += panel2_Paint;
            // 
            // panel1
            // 
            panel1.Location = new Point(136, 1);
            panel1.Margin = new Padding(1);
            panel1.Name = "panel1";
            panel1.Size = new Size(133, 89);
            panel1.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.Location = new Point(271, 1);
            panel3.Margin = new Padding(1);
            panel3.Name = "panel3";
            panel3.Size = new Size(133, 89);
            panel3.TabIndex = 3;
            // 
            // panel4
            // 
            panel4.Location = new Point(406, 1);
            panel4.Margin = new Padding(1);
            panel4.Name = "panel4";
            panel4.Size = new Size(133, 89);
            panel4.TabIndex = 2;
            // 
            // panel5
            // 
            panel5.Location = new Point(541, 1);
            panel5.Margin = new Padding(1);
            panel5.Name = "panel5";
            panel5.Size = new Size(133, 89);
            panel5.TabIndex = 3;
            // 
            // panel6
            // 
            panel6.Location = new Point(676, 1);
            panel6.Margin = new Padding(1);
            panel6.Name = "panel6";
            panel6.Size = new Size(133, 89);
            panel6.TabIndex = 2;
            // 
            // panel7
            // 
            panel7.Location = new Point(811, 1);
            panel7.Margin = new Padding(1);
            panel7.Name = "panel7";
            panel7.Size = new Size(133, 89);
            panel7.TabIndex = 3;
            // 
            // panel8
            // 
            panel8.Location = new Point(1, 92);
            panel8.Margin = new Padding(1);
            panel8.Name = "panel8";
            panel8.Size = new Size(133, 89);
            panel8.TabIndex = 5;
            // 
            // panel9
            // 
            panel9.Location = new Point(136, 92);
            panel9.Margin = new Padding(1);
            panel9.Name = "panel9";
            panel9.Size = new Size(133, 89);
            panel9.TabIndex = 4;
            // 
            // panel10
            // 
            panel10.Location = new Point(271, 92);
            panel10.Margin = new Padding(1);
            panel10.Name = "panel10";
            panel10.Size = new Size(133, 89);
            panel10.TabIndex = 8;
            // 
            // panel11
            // 
            panel11.Location = new Point(406, 92);
            panel11.Margin = new Padding(1);
            panel11.Name = "panel11";
            panel11.Size = new Size(133, 89);
            panel11.TabIndex = 6;
            // 
            // panel12
            // 
            panel12.Location = new Point(541, 92);
            panel12.Margin = new Padding(1);
            panel12.Name = "panel12";
            panel12.Size = new Size(133, 89);
            panel12.TabIndex = 9;
            // 
            // panel13
            // 
            panel13.Location = new Point(676, 92);
            panel13.Margin = new Padding(1);
            panel13.Name = "panel13";
            panel13.Size = new Size(133, 89);
            panel13.TabIndex = 7;
            // 
            // panel14
            // 
            panel14.Location = new Point(811, 92);
            panel14.Margin = new Padding(1);
            panel14.Name = "panel14";
            panel14.Size = new Size(133, 89);
            panel14.TabIndex = 10;
            // 
            // panel15
            // 
            panel15.Location = new Point(1, 183);
            panel15.Margin = new Padding(1);
            panel15.Name = "panel15";
            panel15.Size = new Size(133, 89);
            panel15.TabIndex = 12;
            // 
            // panel16
            // 
            panel16.Location = new Point(136, 183);
            panel16.Margin = new Padding(1);
            panel16.Name = "panel16";
            panel16.Size = new Size(133, 89);
            panel16.TabIndex = 11;
            // 
            // panel17
            // 
            panel17.Location = new Point(271, 183);
            panel17.Margin = new Padding(1);
            panel17.Name = "panel17";
            panel17.Size = new Size(133, 89);
            panel17.TabIndex = 15;
            // 
            // panel18
            // 
            panel18.Location = new Point(406, 183);
            panel18.Margin = new Padding(1);
            panel18.Name = "panel18";
            panel18.Size = new Size(133, 89);
            panel18.TabIndex = 13;
            // 
            // panel19
            // 
            panel19.Location = new Point(541, 183);
            panel19.Margin = new Padding(1);
            panel19.Name = "panel19";
            panel19.Size = new Size(133, 89);
            panel19.TabIndex = 16;
            // 
            // panel20
            // 
            panel20.Location = new Point(676, 183);
            panel20.Margin = new Padding(1);
            panel20.Name = "panel20";
            panel20.Size = new Size(133, 89);
            panel20.TabIndex = 14;
            // 
            // panel21
            // 
            panel21.Location = new Point(811, 183);
            panel21.Margin = new Padding(1);
            panel21.Name = "panel21";
            panel21.Size = new Size(133, 89);
            panel21.TabIndex = 17;
            // 
            // panel22
            // 
            panel22.Location = new Point(1, 274);
            panel22.Margin = new Padding(1);
            panel22.Name = "panel22";
            panel22.Size = new Size(133, 89);
            panel22.TabIndex = 19;
            // 
            // panel23
            // 
            panel23.Location = new Point(136, 274);
            panel23.Margin = new Padding(1);
            panel23.Name = "panel23";
            panel23.Size = new Size(133, 89);
            panel23.TabIndex = 18;
            // 
            // panel24
            // 
            panel24.Location = new Point(271, 274);
            panel24.Margin = new Padding(1);
            panel24.Name = "panel24";
            panel24.Size = new Size(133, 89);
            panel24.TabIndex = 22;
            // 
            // panel25
            // 
            panel25.Location = new Point(406, 274);
            panel25.Margin = new Padding(1);
            panel25.Name = "panel25";
            panel25.Size = new Size(133, 89);
            panel25.TabIndex = 20;
            // 
            // panel26
            // 
            panel26.Location = new Point(541, 274);
            panel26.Margin = new Padding(1);
            panel26.Name = "panel26";
            panel26.Size = new Size(133, 89);
            panel26.TabIndex = 23;
            // 
            // panel27
            // 
            panel27.Location = new Point(676, 274);
            panel27.Margin = new Padding(1);
            panel27.Name = "panel27";
            panel27.Size = new Size(133, 89);
            panel27.TabIndex = 21;
            // 
            // panel28
            // 
            panel28.Location = new Point(811, 274);
            panel28.Margin = new Padding(1);
            panel28.Name = "panel28";
            panel28.Size = new Size(133, 89);
            panel28.TabIndex = 24;
            // 
            // panel29
            // 
            panel29.Location = new Point(1, 365);
            panel29.Margin = new Padding(1);
            panel29.Name = "panel29";
            panel29.Size = new Size(133, 89);
            panel29.TabIndex = 26;
            // 
            // panel30
            // 
            panel30.Location = new Point(136, 365);
            panel30.Margin = new Padding(1);
            panel30.Name = "panel30";
            panel30.Size = new Size(133, 89);
            panel30.TabIndex = 25;
            // 
            // panel31
            // 
            panel31.Location = new Point(271, 365);
            panel31.Margin = new Padding(1);
            panel31.Name = "panel31";
            panel31.Size = new Size(133, 89);
            panel31.TabIndex = 29;
            // 
            // panel32
            // 
            panel32.Location = new Point(406, 365);
            panel32.Margin = new Padding(1);
            panel32.Name = "panel32";
            panel32.Size = new Size(133, 89);
            panel32.TabIndex = 27;
            // 
            // panel33
            // 
            panel33.Location = new Point(541, 365);
            panel33.Margin = new Padding(1);
            panel33.Name = "panel33";
            panel33.Size = new Size(133, 89);
            panel33.TabIndex = 30;
            // 
            // panel34
            // 
            panel34.Location = new Point(676, 365);
            panel34.Margin = new Padding(1);
            panel34.Name = "panel34";
            panel34.Size = new Size(133, 89);
            panel34.TabIndex = 28;
            // 
            // panel35
            // 
            panel35.Location = new Point(811, 365);
            panel35.Margin = new Padding(1);
            panel35.Name = "panel35";
            panel35.Size = new Size(133, 89);
            panel35.TabIndex = 31;
            // 
            // panel36
            // 
            panel36.Location = new Point(1, 456);
            panel36.Margin = new Padding(1);
            panel36.Name = "panel36";
            panel36.Size = new Size(133, 89);
            panel36.TabIndex = 33;
            // 
            // panel37
            // 
            panel37.Location = new Point(136, 456);
            panel37.Margin = new Padding(1);
            panel37.Name = "panel37";
            panel37.Size = new Size(133, 89);
            panel37.TabIndex = 32;
            // 
            // panel38
            // 
            panel38.Location = new Point(271, 456);
            panel38.Margin = new Padding(1);
            panel38.Name = "panel38";
            panel38.Size = new Size(133, 89);
            panel38.TabIndex = 36;
            // 
            // panel39
            // 
            panel39.Location = new Point(406, 456);
            panel39.Margin = new Padding(1);
            panel39.Name = "panel39";
            panel39.Size = new Size(133, 89);
            panel39.TabIndex = 34;
            // 
            // panel40
            // 
            panel40.Location = new Point(541, 456);
            panel40.Margin = new Padding(1);
            panel40.Name = "panel40";
            panel40.Size = new Size(133, 89);
            panel40.TabIndex = 37;
            // 
            // panel41
            // 
            panel41.Location = new Point(676, 456);
            panel41.Margin = new Padding(1);
            panel41.Name = "panel41";
            panel41.Size = new Size(133, 89);
            panel41.TabIndex = 35;
            // 
            // panel42
            // 
            panel42.Location = new Point(811, 456);
            panel42.Margin = new Padding(1);
            panel42.Name = "panel42";
            panel42.Size = new Size(133, 89);
            panel42.TabIndex = 38;
            // 
            // LBDATE
            // 
            LBDATE.Font = new Font("MingLiU_HKSCS-ExtB", 15.9000006F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LBDATE.Location = new Point(204, 7);
            LBDATE.Margin = new Padding(1, 0, 1, 0);
            LBDATE.Name = "LBDATE";
            LBDATE.Size = new Size(594, 21);
            LBDATE.TabIndex = 10;
            LBDATE.Text = "Month, YEAR";
            LBDATE.TextAlign = ContentAlignment.TopCenter;
            // 
            // button1
            // 
            button1.Location = new Point(919, 5);
            button1.Margin = new Padding(1);
            button1.Name = "button1";
            button1.Size = new Size(76, 22);
            button1.TabIndex = 11;
            button1.Text = "Back";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1005, 715);
            Controls.Add(button1);
            Controls.Add(LBDATE);
            Controls.Add(dayContainer);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnPrevious);
            Controls.Add(btnNext);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Calendar_Load;
            dayContainer.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion
        private Button btnNext;
        private Button btnPrevious;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private FlowLayoutPanel dayContainer;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private Panel panel9;
        private Panel panel10;
        private Panel panel11;
        private Panel panel12;
        private Panel panel13;
        private Panel panel14;
        private Panel panel15;
        private Panel panel16;
        private Panel panel17;
        private Panel panel18;
        private Panel panel19;
        private Panel panel20;
        private Panel panel21;
        private Panel panel22;
        private Panel panel23;
        private Panel panel24;
        private Panel panel25;
        private Panel panel26;
        private Panel panel27;
        private Panel panel28;
        private Panel panel29;
        private Panel panel30;
        private Panel panel31;
        private Panel panel32;
        private Panel panel33;
        private Panel panel34;
        private Panel panel35;
        private Panel panel36;
        private Panel panel37;
        private Panel panel38;
        private Panel panel39;
        private Panel panel40;
        private Panel panel41;
        private Panel panel42;
        private Label LBDATE;
        private Button button1;
    }
}
