﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace matchInfoPage
{
    public partial class UserControlDays : UserControl
    {
        private string databasePath = "Data Source=CalendarDatabase.db"; // Path to your SQLite database
        public static string static_day;

        public UserControlDays()
        {
            InitializeComponent();
            this.Click += UserControlDays_Click; // Ensure click event is attached to UserControlDays
            lbday.Click += lbday_Click;          // Add click event for lbday
            this.Load += UserControlDays_Load;   // Register the Load event
        }

        public void days(int numday)
        {
            lbday.Text = numday.ToString();
        }

        private void UserControlDays_Click(object sender, EventArgs e)
        {
            static_day = lbday.Text;
            displayEvent(); // Display the event for the clicked day
            EventForm eventForm = new EventForm();
            eventForm.ShowDialog(); // Open the event form
        }

        private void lbday_Click(object sender, EventArgs e)
        {
            UserControlDays_Click(sender, e);
        }

        private void UserControlDays_Load(object sender, EventArgs e)
        {
            // Placeholder for additional initialization, if needed
        }

        // Updated to handle the standardized date format (yyyy-MM-dd)
        private void displayEvent()
        {
            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(databasePath))
                {
                    conn.Open();

                    // SQL query to fetch events for the selected date
                    string query = "SELECT EventInfo FROM Calendar WHERE Date = @date";
                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        // Standardize the date format to yyyy-MM-dd
                        string selectedDate = $"{Calendar.static_year}-{Calendar.static_month:D2}-{static_day:D2}";
                        cmd.Parameters.AddWithValue("@date", selectedDate);

                        using (SQLiteDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                lblEvent.Text = reader["EventInfo"].ToString();
                                lblEvent.Visible = true; // Show the event
                            }
                            else
                            {
                                lblEvent.Text = string.Empty;
                                lblEvent.Visible = false; // Hide if no event
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error displaying event: {ex.Message}"); // Added error handling
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            displayEvent(); // Update event display
        }

        private void lbday_Click_1(object sender, EventArgs e)
        {
            // Your logic for the lbday click
        }
    }
}
