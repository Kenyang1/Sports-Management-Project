﻿namespace SportsManagement_Dashboard
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            exit = new Button();
            weeklyAthlete = new Label();
            dataGridViewAthletes = new DataGridView();
            btnUpdateWeeklyAthlete = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAthletes).BeginInit();
            SuspendLayout();
            // 
            // exit
            // 
            exit.Location = new Point(843, 13);
            exit.Margin = new Padding(1);
            exit.Name = "exit";
            exit.Size = new Size(35, 39);
            exit.TabIndex = 1;
            exit.Text = "x";
            exit.UseVisualStyleBackColor = true;
            exit.Click += button1_Click_1;
            // 
            // weeklyAthlete
            // 
            weeklyAthlete.AutoSize = true;
            weeklyAthlete.BackColor = Color.White;
            weeklyAthlete.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            weeklyAthlete.Location = new Point(342, 95);
            weeklyAthlete.Margin = new Padding(6, 0, 6, 0);
            weeklyAthlete.Name = "weeklyAthlete";
            weeklyAthlete.Size = new Size(269, 31);
            weeklyAthlete.TabIndex = 16;
            weeklyAthlete.Text = "Athlete of the Week";
            weeklyAthlete.Click += weeklyAthlete_Click;
            // 
            // dataGridViewAthletes
            // 
            dataGridViewAthletes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewAthletes.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewAthletes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAthletes.Location = new Point(40, 143);
            dataGridViewAthletes.Margin = new Padding(5, 3, 5, 3);
            dataGridViewAthletes.Name = "dataGridViewAthletes";
            dataGridViewAthletes.RowHeadersWidth = 51;
            dataGridViewAthletes.RowTemplate.Height = 24;
            dataGridViewAthletes.Size = new Size(811, 231);
            dataGridViewAthletes.TabIndex = 40;
            dataGridViewAthletes.CellClick += edit_ath;
            dataGridViewAthletes.CellContentDoubleClick += edit_ath;
            // 
            // btnUpdateWeeklyAthlete
            // 
            btnUpdateWeeklyAthlete.Location = new Point(395, 383);
            btnUpdateWeeklyAthlete.Margin = new Padding(6, 7, 6, 7);
            btnUpdateWeeklyAthlete.Name = "btnUpdateWeeklyAthlete";
            btnUpdateWeeklyAthlete.Size = new Size(134, 43);
            btnUpdateWeeklyAthlete.TabIndex = 41;
            btnUpdateWeeklyAthlete.Text = "Update";
            btnUpdateWeeklyAthlete.UseVisualStyleBackColor = true;
            btnUpdateWeeklyAthlete.Click += btnUpdateWeeklyAthlete_Click;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.FromArgb(46, 51, 73);
            ClientSize = new Size(890, 656);
            Controls.Add(btnUpdateWeeklyAthlete);
            Controls.Add(dataGridViewAthletes);
            Controls.Add(weeklyAthlete);
            Controls.Add(exit);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(1);
            Name = "Dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Dashboard_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewAthletes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Label weeklyAthlete;
        private System.Windows.Forms.DataGridView dataGridViewAthletes;
        private System.Windows.Forms.Button btnUpdateWeeklyAthlete;
    }
}

