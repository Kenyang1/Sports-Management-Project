﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using SportsManagement_Dashboard;
using SportsManagementUPDATEDUI;

namespace Sports_Management_Net8
{
    public partial class TeamDataForm : Form
    {
        private StatsContext? dbContext;

        public TeamDataForm()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this.dbContext = new StatsContext();

            //this.dbContext.Database.EnsureDeleted();
            this.dbContext.Database.EnsureCreated();

            this.dbContext.TeamStats.Load();

            this.teamStatsBindingSource.DataSource = dbContext.TeamStats.Local.ToBindingList();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);

            this.dbContext?.Dispose();
            this.dbContext = null;
        }



        private void saveButton_Click_1(object sender, EventArgs e)
        {
            this.dbContext!.SaveChanges();

            this.dataGridViewTeamStats.Refresh();
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.OpenNewForm();
            //17, 145, 72
            //statsPage.Show();
            
            this.Close();
        }
    }
}
