﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Globalization;
using System.Reflection.Emit;
using Sports_Management_Net8;


namespace SportsManagement_Dashboard
{
    public partial class Dashboard : Form
    {
        private ProgDB context; // creates a new DB "session"

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,     // x-coordinate of upper-left corner
            int nTopRect,      // y-coordinate of upper-left corner
            int nRightRect,    // x-coordinate of lower-right corner
            int nBottomRect,   // y-coordinate of lower-right corner
            int nWidthEllipse, // width of ellipse
            int nHeightEllipse // height of ellipse
        );

        private string _username;

        public Dashboard()
        {
            InitializeComponent();

            context = new ProgDB();
            context.Database.EnsureCreated(); // verify that the DB exists
            LoadAthletesIntoDataGridView();
            //Added by Camdyn
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void userName_Label_Click(object sender, EventArgs e)
        {

        }


        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

      
        private void weeklyAthlete_Click(object sender, EventArgs e)
        {

        }




        private void btnUpdateWeeklyAthlete_Click(object sender, EventArgs e)
        {
            // Pass 'this' (Form1) and the displayed athletes list to the UpdateWeeklyAthleteForm constructor
            var updateForm = new UpdateWeeklyAthleteForm(this);

            // Show the update form
            updateForm.ShowDialog();
        }

        public void LoadSelectedAthleteData(int athleteId)
        {
            var selectedAthlete = context.Athletes
                    .Where(a => a.id == athleteId)
                    .Select(a => new
                    {
                        a.id,
                        a.first_name,
                        a.last_name,
                        a.position,
                        a.accomplishments,
                    })
                    .FirstOrDefault();

            if (selectedAthlete != null)
            {
                // Check if the athlete is already in AthleteDisplay table
                var existingAthlete = context.AthleteDisplays
                    .FirstOrDefault(ad => ad.Id == selectedAthlete.id);

                if (existingAthlete == null)
                {
                    // Add new athlete to the AthleteDisplay table
                    AthleteDisplay newAthleteDisplay = new AthleteDisplay
                    {
                        Id = selectedAthlete.id,  // Add the selected athlete's id
                        FirstName = selectedAthlete.first_name,
                        LastName = selectedAthlete.last_name,
                        Position = selectedAthlete.position,
                        Accomplishments = selectedAthlete.accomplishments
                    };

                    // Add to the database
                    context.AthleteDisplays.Add(newAthleteDisplay);
                    context.SaveChanges(); // Save changes to persist in database

                    MessageBox.Show("Athlete data added to AthleteDisplay table.");
                }
                else
                {
                    MessageBox.Show("Athlete is already in the AthleteDisplay table.");
                }

                // Refresh the DataGridView with updated data
                LoadAthletesIntoDataGridView();





                // Show the current count of the AthleteDisplay records
                var athleteDisplayCount = context.AthleteDisplays.Count();
                MessageBox.Show($"AthleteDisplay Count: {athleteDisplayCount}");
            }
            else
            {
                MessageBox.Show("Athlete not found in database.");
            }
        }

        // Method to load AthleteDisplay data into the DataGridView
        public void LoadAthletesIntoDataGridView()
        {
            // Retrieve all athletes from the AthleteDisplay table
            var athleteDisplayList = context.AthleteDisplays
                .Select(ad => new
                {
                    ad.Id,
                    ad.FirstName,
                    ad.LastName,
                    ad.Accomplishments
                })
                .ToList();

            // Bind the data to the DataGridView
            dataGridViewAthletes.DataSource = athleteDisplayList;
        }


        // Method in Form1 to remove an athlete from the DataGridView
        public void RemoveAthleteFromDataGridView(int athleteToRemoveId)
        {
            var selectedRemoval = context.AthleteDisplays.FirstOrDefault(a => a.Id == athleteToRemoveId);

            if (selectedRemoval != null)
            {
                // Remove the athlete from the AthleteDisplays table
                context.AthleteDisplays.Remove(selectedRemoval);

                // Save the changes to the database
                context.SaveChanges();



                // Optionally, remove the athlete from the DataGridView if it's displayed there
                LoadAthletesIntoDataGridView();
            }
            else
            {
                MessageBox.Show("Athlete not found.");
            }
        }



        // Edits the "double clicked" athlete from the roster

        private void edit_ath(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewAthletes.SelectedRows.Count == 0)
            { // No row selected
                return;
            }

            var selectedRow = dataGridViewAthletes.SelectedRows[0]; // Get the first selected row
            int selectedId = (int)selectedRow.Cells["id"].Value; // Assuming the column name is "id"

            var selectedAthlete = context.Athletes.SingleOrDefault(a => a.id == selectedId); // Get athlete by id
            if (selectedAthlete != null)
            {
                var win = new Form { Text = "Edit an Athlete" }; // New window
                var card = new Ath_info_card
                {
                    Dock = DockStyle.Fill,
                    HideButtons = true // Hide Save and Clear All Fields buttons
                }; // New info card
                win.ClientSize = card.Size; // Match window & card sizes

                card.fill_fields(selectedAthlete); // Fill in the fields
                win.Controls.Add(card);
                win.Show();


                win.FormClosed += (s, args) => { // Reload the roster upon closing
                    context.SaveChanges();
                };
            }
        }







    }
}
