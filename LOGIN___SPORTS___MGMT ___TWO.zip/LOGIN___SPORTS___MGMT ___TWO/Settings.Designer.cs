﻿
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    partial class Settings
    {
        private System.ComponentModel.IContainer components = null;
        private Label usernameLabel; // Label for username
        private Label nameLabel; // Label for name
        private Label orgNameLabel; // Label for organization name
        private PictureBox profilePictureBox; // Picture box for profile picture
        private Button saveButton; // Button to save changes
        private Button changePictureButton; // Button to change picture

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        // This method adds all the boxes and buttons to the page
        private void InitializeComponent()
        {
            this.usernameLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.orgNameLabel = new System.Windows.Forms.Label();
            this.profilePictureBox = new System.Windows.Forms.PictureBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.changePictureButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.profilePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // usernameLabel
            // 
            this.usernameLabel.Location = new System.Drawing.Point(50, 30);
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(300, 20);
            this.usernameLabel.TabIndex = 0;
            this.usernameLabel.Text = "Username:";
            // 
            // nameLabel
            // 
            this.nameLabel.Location = new System.Drawing.Point(50, 70);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(300, 20);
            this.nameLabel.TabIndex = 1;
            this.nameLabel.Text = "Name:";
            // 
            // orgNameLabel
            // 
            this.orgNameLabel.Location = new System.Drawing.Point(50, 110);
            this.orgNameLabel.Name = "orgNameLabel";
            this.orgNameLabel.Size = new System.Drawing.Size(300, 20);
            this.orgNameLabel.TabIndex = 2;
            this.orgNameLabel.Text = "Organization Name:";
            // 
            // profilePictureBox
            // 
            this.profilePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.profilePictureBox.Location = new System.Drawing.Point(50, 150);
            this.profilePictureBox.Name = "profilePictureBox";
            this.profilePictureBox.Size = new System.Drawing.Size(100, 100);
            this.profilePictureBox.TabIndex = 3;
            this.profilePictureBox.TabStop = false;
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(50, 270);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 25);
            this.saveButton.TabIndex = 4;
            this.saveButton.Text = "Save";
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // changePictureButton
            // 
            this.changePictureButton.Location = new System.Drawing.Point(160, 150);
            this.changePictureButton.Name = "changePictureButton";
            this.changePictureButton.Size = new System.Drawing.Size(90, 25);
            this.changePictureButton.TabIndex = 5;
            this.changePictureButton.Text = "Change Picture";
            this.changePictureButton.Click += new System.EventHandler(this.changePictureButton_Click);
            // 
            // Settings
            // 
            this.ClientSize = new System.Drawing.Size(578, 357);
            this.Controls.Add(this.usernameLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.orgNameLabel);
            this.Controls.Add(this.profilePictureBox);
            this.Controls.Add(this.changePictureButton);
            this.Controls.Add(this.saveButton);
            this.Name = "Settings";
            this.Text = "Settings";
            ((System.ComponentModel.ISupportInitialize)(this.profilePictureBox)).EndInit();
            this.ResumeLayout(false);

        }
    }
}

