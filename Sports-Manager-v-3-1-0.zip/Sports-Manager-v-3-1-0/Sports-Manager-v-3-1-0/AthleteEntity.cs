﻿/* Special thanks goes to Nick, he found the EntityFrameworkCore Microsoft docs
 * See: https://learn.microsoft.com/en-us/ef/core/get-started/overview/first-app?tabs=netcore-cli
 * 
 * Note: Our WinForms app targets the .NET Framework whereas the EntityFrameworkCore app 
 *       targets .NET. Microsoft, with their knack for naming products, created 3 
 *       versions of NET: .NET Framework, .NET Core, and .NET. The ".NET" is the latest 
 *       "tech" where as ".NET Framework" is the legacy version. Since trying to install 
 *       the latest EntityFrameworkCore failed due to incompatibilites, I frustratingly 
 *       installed version 2.0.0 (deprecated). Miraculously, it "worked". It should 
 *       serve well for our purposes.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

// sports player (football?)
public class Athlete
{
    public int id { get; set; } // athlete's unique ID/primary key
    public string first_name { get; set; }
    public string last_name { get; set; }
    public int age { get; set; }
    public string position { get; set; } // athlete's player position (e.g., quarterback)
}