﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class CoachRoster : Form
    {
        public CoachRoster()
        {
            InitializeComponent();
            // Display the roster size
            label1.Text = "Roster size: " + listBox1.Items.Count.ToString();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("Age: 45;", "", 0);
            CoachInfoCard coachInfoCard = new CoachInfoCard(); // Create an info card control

            Form infoCard = new Form(); // Create a new form
            infoCard.Controls.Add(coachInfoCard); // Add the info card to the form
            infoCard.Dock = DockStyle.Fill; // Fill the info card inside the form
            // Resize the form to the control's size
            infoCard.ClientSize = new Size(coachInfoCard.Width, coachInfoCard.Height);
            infoCard.Show(); // Display the info card

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CoachInfoCard coachInfoCard = new CoachInfoCard(); // Create an info card control

            Form infoCard = new Form(); // Create a new form
            infoCard.Controls.Add(coachInfoCard); // Add the info card to the form
            infoCard.Dock = DockStyle.Fill; // Fill the info card inside the form
            // Resize the form to the control's size
            infoCard.ClientSize = new Size(coachInfoCard.Width, coachInfoCard.Height);
            infoCard.Show(); // Display the info card
        }
    }
}
