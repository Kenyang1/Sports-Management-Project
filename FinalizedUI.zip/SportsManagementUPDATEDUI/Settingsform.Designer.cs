﻿
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    partial class Settingsform
    {
        private System.ComponentModel.IContainer components = null;
        private Label usernameLabel; // Label for username
        private Label nameLabel; // Label for name
        private Label orgNameLabel; // Label for organization name
        private PictureBox profilePictureBox; // Picture box for profile picture
        private Button saveButton; // Button to save changes
        private Button changePictureButton; // Button to change picture

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        // This method adds all the boxes and buttons to the page
        private void InitializeComponent()
        {
            usernameLabel = new Label();
            nameLabel = new Label();
            orgNameLabel = new Label();
            profilePictureBox = new PictureBox();
            saveButton = new Button();
            changePictureButton = new Button();
            ((System.ComponentModel.ISupportInitialize)profilePictureBox).BeginInit();
            SuspendLayout();
            // 
            // usernameLabel
            // 
            usernameLabel.Location = new Point(50, 24);
            usernameLabel.Name = "usernameLabel";
            usernameLabel.Size = new Size(300, 46);
            usernameLabel.TabIndex = 0;
            usernameLabel.Text = "Username:";
            usernameLabel.Click += usernameLabel_Click;
            // 
            // nameLabel
            // 
            nameLabel.Location = new Point(50, 70);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(300, 59);
            nameLabel.TabIndex = 1;
            nameLabel.Text = "Name:";
            // 
            // orgNameLabel
            // 
            orgNameLabel.Location = new Point(50, 122);
            orgNameLabel.Name = "orgNameLabel";
            orgNameLabel.Size = new Size(300, 64);
            orgNameLabel.TabIndex = 2;
            orgNameLabel.Text = "Organization Name:";
            // 
            // profilePictureBox
            // 
            profilePictureBox.BorderStyle = BorderStyle.FixedSingle;
            profilePictureBox.Location = new Point(66, 177);
            profilePictureBox.Name = "profilePictureBox";
            profilePictureBox.Size = new Size(100, 100);
            profilePictureBox.TabIndex = 3;
            profilePictureBox.TabStop = false;
            // 
            // saveButton
            // 
            saveButton.Location = new Point(50, 323);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(175, 82);
            saveButton.TabIndex = 4;
            saveButton.Text = "Save";
            saveButton.Click += saveButton_Click;
            // 
            // changePictureButton
            // 
            changePictureButton.Location = new Point(227, 177);
            changePictureButton.Name = "changePictureButton";
            changePictureButton.Size = new Size(226, 100);
            changePictureButton.TabIndex = 5;
            changePictureButton.Text = "Change Picture";
            changePictureButton.Click += changePictureButton_Click;
            // 
            // Settings
            // 
            ClientSize = new Size(1002, 706);
            Controls.Add(usernameLabel);
            Controls.Add(nameLabel);
            Controls.Add(orgNameLabel);
            Controls.Add(profilePictureBox);
            Controls.Add(changePictureButton);
            Controls.Add(saveButton);
            Name = "Settings";
            Text = "Settings";
            Load += Settings_Load;
            ((System.ComponentModel.ISupportInitialize)profilePictureBox).EndInit();
            ResumeLayout(false);
        }
    }
}

