﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagementUPDATEDUI
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
        }

        private void About_Load(object sender, EventArgs e)
        {
            this.Text = "About the Sports Management Dashboard Application";
            aboutTextLabel.Text = "Sports Management Dashboard is an application designed to streamline " +
                                  "sports team management. It allows coaches, managers, and team administrators " +
                                  "to track rosters, manage matches, view statistics, and customize settings. " +
                                  "\n\nKey Features:\n" +
                                  "- Manage team and coach rosters\n" +
                                  "- View match schedules and results\n" +
                                  "- Analyze team and player statistics\n" +
                                  "- Customize settings for personalized use";
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
