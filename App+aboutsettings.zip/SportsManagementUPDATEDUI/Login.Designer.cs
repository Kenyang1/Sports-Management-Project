﻿namespace SportsManagement_Dashboard
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            passwordTextBox = new TextBox();
            usernameTextBox = new TextBox();
            createAccountButton = new Button();
            enterButton = new Button();
            loginExitbtn = new Button();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Impact", 15.9000006F);
            label3.Location = new Point(307, 641);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(254, 66);
            label3.TabIndex = 11;
            label3.Text = "Password:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Impact", 15.9000006F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(306, 548);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(266, 66);
            label2.TabIndex = 10;
            label2.Text = "Username:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Impact", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(563, 336);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(218, 98);
            label1.TabIndex = 9;
            label1.Text = "Login";
            // 
            // passwordTextBox
            // 
            passwordTextBox.BackColor = Color.FromArgb(46, 51, 73);
            passwordTextBox.ForeColor = Color.White;
            passwordTextBox.Location = new Point(598, 566);
            passwordTextBox.Margin = new Padding(6, 8, 6, 8);
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.Size = new Size(383, 47);
            passwordTextBox.TabIndex = 8;
            passwordTextBox.TextChanged += passwordTextBox_TextChanged_1;
            // 
            // usernameTextBox
            // 
            usernameTextBox.BackColor = Color.FromArgb(46, 51, 73);
            usernameTextBox.ForeColor = Color.White;
            usernameTextBox.Location = new Point(598, 659);
            usernameTextBox.Margin = new Padding(6, 8, 6, 8);
            usernameTextBox.Name = "usernameTextBox";
            usernameTextBox.Size = new Size(383, 47);
            usernameTextBox.TabIndex = 7;
            usernameTextBox.TextChanged += usernameTextBox_TextChanged_1;
            // 
            // createAccountButton
            // 
            createAccountButton.BackColor = Color.FromArgb(24, 30, 54);
            createAccountButton.Location = new Point(306, 779);
            createAccountButton.Margin = new Padding(6, 8, 6, 8);
            createAccountButton.Name = "createAccountButton";
            createAccountButton.Size = new Size(320, 109);
            createAccountButton.TabIndex = 14;
            createAccountButton.Text = "Create Account";
            createAccountButton.UseVisualStyleBackColor = false;
            createAccountButton.Click += createAccountButton_Click;
            // 
            // enterButton
            // 
            enterButton.BackColor = Color.FromArgb(24, 30, 54);
            enterButton.Location = new Point(763, 779);
            enterButton.Margin = new Padding(6, 8, 6, 8);
            enterButton.Name = "enterButton";
            enterButton.Size = new Size(218, 109);
            enterButton.TabIndex = 15;
            enterButton.Text = "Login";
            enterButton.UseVisualStyleBackColor = false;
            enterButton.Click += enterButton_Click;
            // 
            // loginExitbtn
            // 
            loginExitbtn.ForeColor = Color.Brown;
            loginExitbtn.Location = new Point(1212, 49);
            loginExitbtn.Name = "loginExitbtn";
            loginExitbtn.Size = new Size(85, 58);
            loginExitbtn.TabIndex = 16;
            loginExitbtn.Text = "Exit";
            loginExitbtn.UseVisualStyleBackColor = true;
            loginExitbtn.Click += loginExitbtn_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(46, 51, 73);
            ClientSize = new Size(1366, 1153);
            Controls.Add(loginExitbtn);
            Controls.Add(enterButton);
            Controls.Add(createAccountButton);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(passwordTextBox);
            Controls.Add(usernameTextBox);
            ForeColor = Color.CornflowerBlue;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(6, 8, 6, 8);
            Name = "Login";
            Text = "Login";
            Load += Login_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.TextBox usernameTextBox;
        private System.Windows.Forms.Button createAccountButton;
        private System.Windows.Forms.Button enterButton;
        private Button loginExitbtn;
    }
}