﻿namespace SportsManagementUPDATEDUI
{
    partial class form_home
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_home));
            sidebar = new FlowLayoutPanel();
            panel1 = new Panel();
            label1 = new Label();
            menuButton = new PictureBox();
            panel3 = new Panel();
            dashboardBtn = new Button();
            panel4 = new Panel();
            playerBtn = new Button();
            panel5 = new Panel();
            coachBtn = new Button();
            panel6 = new Panel();
            statsBtn = new Button();
            panel7 = new Panel();
            calendarBtn = new Button();
            panel8 = new Panel();
            aboutBtn = new Button();
            panel9 = new Panel();
            settingsBtn = new Button();
            panel2 = new Panel();
            button1 = new Button();
            sidebarTimer = new System.Windows.Forms.Timer(components);
            panel10 = new Panel();
            mainPanel = new Panel();
            sidebar.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)menuButton).BeginInit();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            panel9.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // sidebar
            // 
            sidebar.BackColor = Color.FromArgb(8, 34, 65);
            sidebar.Controls.Add(panel1);
            sidebar.Controls.Add(panel3);
            sidebar.Controls.Add(panel4);
            sidebar.Controls.Add(panel5);
            sidebar.Controls.Add(panel6);
            sidebar.Controls.Add(panel7);
            sidebar.Controls.Add(panel8);
            sidebar.Controls.Add(panel9);
            sidebar.Dock = DockStyle.Left;
            sidebar.ForeColor = Color.Transparent;
            sidebar.Location = new Point(0, 0);
            sidebar.MaximumSize = new Size(389, 1446);
            sidebar.MinimumSize = new Size(164, 1446);
            sidebar.Name = "sidebar";
            sidebar.Size = new Size(389, 1446);
            sidebar.TabIndex = 0;
            sidebar.Paint += flowLayoutPanel1_Paint;
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Controls.Add(menuButton);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(500, 251);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Dutch801 XBd BT", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(151, 48);
            label1.Name = "label1";
            label1.Size = new Size(149, 48);
            label1.TabIndex = 1;
            label1.Text = "  Menu";
            // 
            // menuButton
            // 
            menuButton.Image = Properties.Resources.icons8_menu_50;
            menuButton.Location = new Point(45, 35);
            menuButton.Name = "menuButton";
            menuButton.Size = new Size(79, 67);
            menuButton.SizeMode = PictureBoxSizeMode.StretchImage;
            menuButton.TabIndex = 0;
            menuButton.TabStop = false;
            menuButton.Click += menuButton_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(dashboardBtn);
            panel3.Location = new Point(3, 260);
            panel3.Name = "panel3";
            panel3.Size = new Size(500, 103);
            panel3.TabIndex = 3;
            // 
            // dashboardBtn
            // 
            dashboardBtn.BackgroundImageLayout = ImageLayout.Zoom;
            dashboardBtn.FlatAppearance.BorderSize = 0;
            dashboardBtn.FlatStyle = FlatStyle.Flat;
            dashboardBtn.Font = new Font("Dutch801 XBd BT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dashboardBtn.ForeColor = Color.White;
            dashboardBtn.Image = (Image)resources.GetObject("dashboardBtn.Image");
            dashboardBtn.ImageAlign = ContentAlignment.MiddleLeft;
            dashboardBtn.Location = new Point(-21, 14);
            dashboardBtn.Name = "dashboardBtn";
            dashboardBtn.Padding = new Padding(60, 0, 0, 0);
            dashboardBtn.Size = new Size(401, 69);
            dashboardBtn.TabIndex = 2;
            dashboardBtn.Text = "              Dashboard";
            dashboardBtn.TextAlign = ContentAlignment.MiddleLeft;
            dashboardBtn.UseVisualStyleBackColor = true;
            dashboardBtn.Click += dashboardBtn_Click;
            // 
            // panel4
            // 
            panel4.Controls.Add(playerBtn);
            panel4.Location = new Point(3, 369);
            panel4.Name = "panel4";
            panel4.Size = new Size(500, 103);
            panel4.TabIndex = 4;
            // 
            // playerBtn
            // 
            playerBtn.BackgroundImageLayout = ImageLayout.Zoom;
            playerBtn.FlatAppearance.BorderSize = 0;
            playerBtn.FlatStyle = FlatStyle.Flat;
            playerBtn.Font = new Font("Dutch801 XBd BT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            playerBtn.ForeColor = Color.White;
            playerBtn.Image = (Image)resources.GetObject("playerBtn.Image");
            playerBtn.ImageAlign = ContentAlignment.MiddleLeft;
            playerBtn.Location = new Point(-21, 10);
            playerBtn.Name = "playerBtn";
            playerBtn.Padding = new Padding(60, 0, 0, 0);
            playerBtn.Size = new Size(401, 69);
            playerBtn.TabIndex = 2;
            playerBtn.Text = "              Player Roster";
            playerBtn.TextAlign = ContentAlignment.MiddleLeft;
            playerBtn.UseVisualStyleBackColor = true;
            playerBtn.Click += playerBtn_Click;
            // 
            // panel5
            // 
            panel5.Controls.Add(coachBtn);
            panel5.Location = new Point(3, 478);
            panel5.Name = "panel5";
            panel5.Size = new Size(500, 103);
            panel5.TabIndex = 5;
            // 
            // coachBtn
            // 
            coachBtn.BackgroundImageLayout = ImageLayout.Zoom;
            coachBtn.FlatAppearance.BorderSize = 0;
            coachBtn.FlatStyle = FlatStyle.Flat;
            coachBtn.Font = new Font("Dutch801 XBd BT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            coachBtn.ForeColor = Color.White;
            coachBtn.Image = (Image)resources.GetObject("coachBtn.Image");
            coachBtn.ImageAlign = ContentAlignment.MiddleLeft;
            coachBtn.Location = new Point(-21, 14);
            coachBtn.Name = "coachBtn";
            coachBtn.Padding = new Padding(60, 0, 0, 0);
            coachBtn.Size = new Size(401, 69);
            coachBtn.TabIndex = 2;
            coachBtn.Text = "              Coach Roster";
            coachBtn.TextAlign = ContentAlignment.MiddleLeft;
            coachBtn.UseVisualStyleBackColor = true;
            coachBtn.Click += coachBtn_Click;
            // 
            // panel6
            // 
            panel6.Controls.Add(statsBtn);
            panel6.Location = new Point(3, 587);
            panel6.Name = "panel6";
            panel6.Size = new Size(500, 103);
            panel6.TabIndex = 6;
            // 
            // statsBtn
            // 
            statsBtn.BackgroundImageLayout = ImageLayout.Zoom;
            statsBtn.FlatAppearance.BorderSize = 0;
            statsBtn.FlatStyle = FlatStyle.Flat;
            statsBtn.Font = new Font("Dutch801 XBd BT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            statsBtn.ForeColor = Color.White;
            statsBtn.Image = (Image)resources.GetObject("statsBtn.Image");
            statsBtn.ImageAlign = ContentAlignment.MiddleLeft;
            statsBtn.Location = new Point(-21, 16);
            statsBtn.Name = "statsBtn";
            statsBtn.Padding = new Padding(60, 0, 0, 0);
            statsBtn.Size = new Size(401, 69);
            statsBtn.TabIndex = 2;
            statsBtn.Text = "              Statistics";
            statsBtn.TextAlign = ContentAlignment.MiddleLeft;
            statsBtn.UseVisualStyleBackColor = true;
            statsBtn.Click += statsBtn_Click;
            // 
            // panel7
            // 
            panel7.Controls.Add(calendarBtn);
            panel7.Location = new Point(3, 696);
            panel7.Name = "panel7";
            panel7.Size = new Size(500, 103);
            panel7.TabIndex = 7;
            // 
            // calendarBtn
            // 
            calendarBtn.BackgroundImageLayout = ImageLayout.Zoom;
            calendarBtn.FlatAppearance.BorderSize = 0;
            calendarBtn.FlatStyle = FlatStyle.Flat;
            calendarBtn.Font = new Font("Dutch801 XBd BT", 8.1F, FontStyle.Regular, GraphicsUnit.Point, 0);
            calendarBtn.ForeColor = Color.White;
            calendarBtn.Image = (Image)resources.GetObject("calendarBtn.Image");
            calendarBtn.ImageAlign = ContentAlignment.MiddleLeft;
            calendarBtn.Location = new Point(-21, 12);
            calendarBtn.Name = "calendarBtn";
            calendarBtn.Padding = new Padding(60, 0, 0, 0);
            calendarBtn.Size = new Size(401, 69);
            calendarBtn.TabIndex = 2;
            calendarBtn.Text = "              Team Calendar";
            calendarBtn.TextAlign = ContentAlignment.MiddleLeft;
            calendarBtn.UseVisualStyleBackColor = true;
            calendarBtn.Click += calendarBtn_Click;
            // 
            // panel8
            // 
            panel8.Controls.Add(aboutBtn);
            panel8.Location = new Point(3, 805);
            panel8.Name = "panel8";
            panel8.Size = new Size(500, 103);
            panel8.TabIndex = 8;
            // 
            // aboutBtn
            // 
            aboutBtn.BackgroundImageLayout = ImageLayout.Zoom;
            aboutBtn.FlatAppearance.BorderSize = 0;
            aboutBtn.FlatStyle = FlatStyle.Flat;
            aboutBtn.Font = new Font("Dutch801 XBd BT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            aboutBtn.ForeColor = Color.White;
            aboutBtn.Image = (Image)resources.GetObject("aboutBtn.Image");
            aboutBtn.ImageAlign = ContentAlignment.MiddleLeft;
            aboutBtn.Location = new Point(-21, 17);
            aboutBtn.Name = "aboutBtn";
            aboutBtn.Padding = new Padding(60, 0, 0, 0);
            aboutBtn.Size = new Size(401, 69);
            aboutBtn.TabIndex = 2;
            aboutBtn.Text = "              About";
            aboutBtn.TextAlign = ContentAlignment.MiddleLeft;
            aboutBtn.UseVisualStyleBackColor = true;
            aboutBtn.Click += aboutBtn_Click;
            // 
            // panel9
            // 
            panel9.Controls.Add(settingsBtn);
            panel9.Location = new Point(3, 914);
            panel9.Name = "panel9";
            panel9.Size = new Size(500, 103);
            panel9.TabIndex = 9;
            // 
            // settingsBtn
            // 
            settingsBtn.BackgroundImageLayout = ImageLayout.Zoom;
            settingsBtn.FlatAppearance.BorderSize = 0;
            settingsBtn.FlatStyle = FlatStyle.Flat;
            settingsBtn.Font = new Font("Dutch801 XBd BT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            settingsBtn.ForeColor = Color.White;
            settingsBtn.Image = (Image)resources.GetObject("settingsBtn.Image");
            settingsBtn.ImageAlign = ContentAlignment.MiddleLeft;
            settingsBtn.Location = new Point(-21, 15);
            settingsBtn.Name = "settingsBtn";
            settingsBtn.Padding = new Padding(60, 0, 0, 0);
            settingsBtn.Size = new Size(401, 69);
            settingsBtn.TabIndex = 2;
            settingsBtn.Text = "              Settings";
            settingsBtn.TextAlign = ContentAlignment.MiddleLeft;
            settingsBtn.UseVisualStyleBackColor = true;
            settingsBtn.Click += settingsBtn_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(button1);
            panel2.Location = new Point(3, 260);
            panel2.Name = "panel2";
            panel2.Size = new Size(500, 113);
            panel2.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlDarkDark;
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Image = Properties.Resources.icons8_home_24;
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(3, 379);
            button1.Name = "button1";
            button1.Padding = new Padding(30, 0, 0, 0);
            button1.Size = new Size(377, 84);
            button1.TabIndex = 0;
            button1.Text = "          Home";
            button1.TextAlign = ContentAlignment.MiddleLeft;
            button1.UseVisualStyleBackColor = false;
            // 
            // sidebarTimer
            // 
            sidebarTimer.Interval = 10;
            sidebarTimer.Tick += sidebarTimer_Tick;
            // 
            // panel10
            // 
            panel10.BackColor = Color.FromArgb(8, 34, 65);
            panel10.Location = new Point(6, -2);
            panel10.Name = "panel10";
            panel10.Size = new Size(2276, 105);
            panel10.TabIndex = 2;
            // 
            // mainPanel
            // 
            mainPanel.Location = new Point(389, 100);
            mainPanel.Name = "mainPanel";
            mainPanel.Size = new Size(1893, 1349);
            mainPanel.TabIndex = 3;
            // 
            // form_home
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(2281, 1446);
            Controls.Add(mainPanel);
            Controls.Add(sidebar);
            Controls.Add(panel2);
            Controls.Add(panel10);
            FormBorderStyle = FormBorderStyle.None;
            Name = "form_home";
            Text = "Home Page";
            sidebar.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)menuButton).EndInit();
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel9.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private FlowLayoutPanel sidebar;
        private Panel panel1;
        private Panel panel2;
        private Button button1;
        private Button dashboardBtn;
        private Panel panel3;
        private Panel panel4;
        private Button playerBtn;
        private Panel panel5;
        private Button coachBtn;
        private Panel panel6;
        private Button statsBtn;
        private Panel panel7;
        private Button calendarBtn;
        private Panel panel8;
        private Button aboutBtn;
        private Label label1;
        private PictureBox menuButton;
        private System.Windows.Forms.Timer sidebarTimer;
        private Panel panel9;
        private Button settingsBtn;
        private Panel panel10;
        private Panel mainPanel;
    }
}
