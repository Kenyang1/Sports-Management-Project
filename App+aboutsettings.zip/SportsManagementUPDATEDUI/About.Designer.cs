﻿namespace SportsManagementUPDATEDUI
{
    partial class About
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            aboutTextLabel = new Label();
            closeButton = new Button();
            SuspendLayout();
            // 
            // aboutTextLabel
            // 
            aboutTextLabel.AutoSize = true;
            aboutTextLabel.Font = new Font("Segoe UI", 12F);
            aboutTextLabel.ForeColor = Color.FromArgb(50, 50, 50);
            aboutTextLabel.Location = new Point(50, 60);
            aboutTextLabel.Name = "aboutTextLabel";
            aboutTextLabel.Size = new Size(889, 63);
            aboutTextLabel.TabIndex = 0;
            aboutTextLabel.Text = "Welcome to the Sports Management Dashboard!\n\nThis app helps coaches, managers, and team administrators manage rosters, track schedules, view stats, and customize settings.";
            // 
            // closeButton
            // 
            closeButton.BackColor = Color.FromArgb(0, 120, 215);
            closeButton.FlatStyle = FlatStyle.Flat;
            closeButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            closeButton.ForeColor = Color.White;
            closeButton.Location = new Point(581, 203);
            closeButton.Name = "closeButton";
            closeButton.Size = new Size(100, 40);
            closeButton.TabIndex = 1;
            closeButton.Text = "Close";
            closeButton.UseVisualStyleBackColor = false;
            closeButton.Click += closeButton_Click;
            // 
            // About
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(704, 281);
            Controls.Add(closeButton);
            Controls.Add(aboutTextLabel);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "About";
            StartPosition = FormStartPosition.CenterParent;
            Text = "About Sports Management Dashboard";
            Load += About_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label aboutTextLabel;
        private Button closeButton;
    }
}
