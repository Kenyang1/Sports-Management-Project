using matchInfoPage;
using SportsManagement_Dashboard;

namespace SportsManagementUPDATEDUI
{
    public partial class form_home : Form
    {
        bool sideBarExpand;
        public form_home()
        {
            InitializeComponent();
        }

        public void loadForm(object Form)
        {
            if (this.mainPanel.Controls.Count > 0)
            {
                this.mainPanel.Controls.RemoveAt(0);
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.mainPanel.Controls.Add(f);
            this.mainPanel.Tag = f;
            f.Show();
        }
        private void form_home_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sideBarExpand)
            {
                sidebar.Width -= 10;
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sideBarExpand = false;
                    sidebarTimer.Stop();

                }
            }
            else
            {
                sidebar.Width += 10;
                if (sidebar.Width == sidebar.MaximumSize.Width)
                {
                    sideBarExpand = true;
                    sidebarTimer.Stop();
                }
            }
        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            //set timer interval to lowest to make it smoothe
            sidebarTimer.Start();
        }

        private void dashboardBtn_Click(object sender, EventArgs e)
        {
            loadForm(new Dashboardform());
        }

        private void playerBtn_Click(object sender, EventArgs e)
        {
            loadForm(new AthleteRoster());
        }

        private void coachBtn_Click(object sender, EventArgs e)
        {
            // loadForm(new CoachRoster());
        }

        private void statsBtn_Click(object sender, EventArgs e)
        {
            loadForm(new Statisticsform());
        }

        private void aboutBtn_Click(object sender, EventArgs e)
        {
            //loadForm(new Aboutform());
            About aboutPage = new About();
            aboutPage.Show();
        }

        private void calendarBtn_Click(object sender, EventArgs e)
        {
            Form1 calendar = new Form1();
            calendar.Show();
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            // loadForm(new Settingsform());
            string currentUsername = "admin"; // Example username
            SettingsForm settingsForm = new SettingsForm(currentUsername);
            settingsForm.ShowDialog();
        }
    }
}
