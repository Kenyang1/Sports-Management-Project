﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace dashboard
{
    public partial class dashboardForm : Form
    {
        public dashboardForm()
        {
            InitializeComponent();
        }

        private void updateAthleteButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(enterAthleteInfo.Text) && !athleteInfo.Items.Contains(enterAthleteInfo.Text))
                athleteInfo.Items.Add(enterAthleteInfo.Text);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void clearAthleteInfoButton_Click(object sender, EventArgs e)
        {
            // Check if the entered text is in the list
            if (!string.IsNullOrWhiteSpace(enterAthleteInfo.Text) && athleteInfo.Items.Contains(enterAthleteInfo.Text))
            {
                // Remove the entered text from the list
                athleteInfo.Items.Remove(enterAthleteInfo.Text);
            }
            // Alternatively, if no specific text is entered, you could clear the selected item
            else if (athleteInfo.SelectedItem != null)
            {
                athleteInfo.Items.Remove(athleteInfo.SelectedItem);
            }
        }

        private void addEventInfo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(enterEventInfo.Text) && !upcomingEvents.Items.Contains(enterEventInfo.Text))
                upcomingEvents.Items.Add(enterEventInfo.Text);
        }

        private void clearEventInfo_Click(object sender, EventArgs e)
        {
            // Check if the entered text is in the list
            if (!string.IsNullOrWhiteSpace(enterEventInfo.Text) && upcomingEvents.Items.Contains(enterEventInfo.Text))
            {
                // Remove the entered text from the list
                upcomingEvents.Items.Remove(enterEventInfo.Text);
            }
            // Alternatively, if no specific text is entered, you could clear the selected item
            else if (upcomingEvents.SelectedItem != null)
            {
                upcomingEvents.Items.Remove(upcomingEvents.SelectedItem);
            }
        }

        private void matchesButton_Click(object sender, EventArgs e)
        {
            // Instantiate the matchesForm
            matchesForm newMatchesForm = new matchesForm();


            // Show the matchesForm as a non-modal window
            newMatchesForm.Show();

            this.Hide();

        }
    }
}
