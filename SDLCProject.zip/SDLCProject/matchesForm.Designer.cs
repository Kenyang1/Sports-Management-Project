﻿namespace dashboard
{
    partial class matchesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gamesButton = new System.Windows.Forms.Button();
            this.calendarButton = new System.Windows.Forms.Button();
            this.coachesButton = new System.Windows.Forms.Button();
            this.rosterButton = new System.Windows.Forms.Button();
            this.dashboardButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearGameInfoButton = new System.Windows.Forms.Button();
            this.gamesLabel = new System.Windows.Forms.Label();
            this.gameInfo = new System.Windows.Forms.ListBox();
            this.enterGameInfo = new System.Windows.Forms.TextBox();
            this.addGameInfoButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // gamesButton
            // 
            this.gamesButton.Location = new System.Drawing.Point(7, 432);
            this.gamesButton.Name = "gamesButton";
            this.gamesButton.Size = new System.Drawing.Size(101, 77);
            this.gamesButton.TabIndex = 31;
            this.gamesButton.Text = "Games";
            this.gamesButton.UseVisualStyleBackColor = true;
            // 
            // calendarButton
            // 
            this.calendarButton.Location = new System.Drawing.Point(7, 349);
            this.calendarButton.Name = "calendarButton";
            this.calendarButton.Size = new System.Drawing.Size(101, 77);
            this.calendarButton.TabIndex = 30;
            this.calendarButton.Text = "Calendar";
            this.calendarButton.UseVisualStyleBackColor = true;
            // 
            // coachesButton
            // 
            this.coachesButton.Location = new System.Drawing.Point(7, 266);
            this.coachesButton.Name = "coachesButton";
            this.coachesButton.Size = new System.Drawing.Size(101, 77);
            this.coachesButton.TabIndex = 29;
            this.coachesButton.Text = "Coaches";
            this.coachesButton.UseVisualStyleBackColor = true;
            // 
            // rosterButton
            // 
            this.rosterButton.Location = new System.Drawing.Point(7, 183);
            this.rosterButton.Name = "rosterButton";
            this.rosterButton.Size = new System.Drawing.Size(101, 77);
            this.rosterButton.TabIndex = 28;
            this.rosterButton.Text = "Roster";
            this.rosterButton.UseVisualStyleBackColor = true;
            // 
            // dashboardButton
            // 
            this.dashboardButton.Location = new System.Drawing.Point(7, 100);
            this.dashboardButton.Name = "dashboardButton";
            this.dashboardButton.Size = new System.Drawing.Size(101, 77);
            this.dashboardButton.TabIndex = 27;
            this.dashboardButton.Text = "Dashboard";
            this.dashboardButton.UseVisualStyleBackColor = true;
            this.dashboardButton.Click += new System.EventHandler(this.dashboardButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(763, 10);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(50, 23);
            this.exitButton.TabIndex = 18;
            this.exitButton.Text = "X";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearGameInfoButton
            // 
            this.clearGameInfoButton.Location = new System.Drawing.Point(373, 341);
            this.clearGameInfoButton.Name = "clearGameInfoButton";
            this.clearGameInfoButton.Size = new System.Drawing.Size(75, 23);
            this.clearGameInfoButton.TabIndex = 36;
            this.clearGameInfoButton.Text = "Clear Item";
            this.clearGameInfoButton.UseVisualStyleBackColor = true;
            this.clearGameInfoButton.Click += new System.EventHandler(this.clearGameInfoButton_Click);
            // 
            // gamesLabel
            // 
            this.gamesLabel.AutoSize = true;
            this.gamesLabel.BackColor = System.Drawing.Color.White;
            this.gamesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gamesLabel.Location = new System.Drawing.Point(387, 148);
            this.gamesLabel.Name = "gamesLabel";
            this.gamesLabel.Size = new System.Drawing.Size(61, 20);
            this.gamesLabel.TabIndex = 35;
            this.gamesLabel.Text = "Games";
            // 
            // gameInfo
            // 
            this.gameInfo.FormattingEnabled = true;
            this.gameInfo.Location = new System.Drawing.Point(339, 189);
            this.gameInfo.Name = "gameInfo";
            this.gameInfo.Size = new System.Drawing.Size(146, 82);
            this.gameInfo.TabIndex = 34;
            // 
            // enterGameInfo
            // 
            this.enterGameInfo.Location = new System.Drawing.Point(361, 286);
            this.enterGameInfo.Name = "enterGameInfo";
            this.enterGameInfo.Size = new System.Drawing.Size(100, 20);
            this.enterGameInfo.TabIndex = 33;
            // 
            // addGameInfoButton
            // 
            this.addGameInfoButton.Location = new System.Drawing.Point(373, 312);
            this.addGameInfoButton.Name = "addGameInfoButton";
            this.addGameInfoButton.Size = new System.Drawing.Size(75, 23);
            this.addGameInfoButton.TabIndex = 32;
            this.addGameInfoButton.Text = "Add";
            this.addGameInfoButton.UseVisualStyleBackColor = true;
            this.addGameInfoButton.Click += new System.EventHandler(this.addGameInfoButton_Click);
            // 
            // matchesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(820, 518);
            this.Controls.Add(this.clearGameInfoButton);
            this.Controls.Add(this.gamesLabel);
            this.Controls.Add(this.gameInfo);
            this.Controls.Add(this.enterGameInfo);
            this.Controls.Add(this.addGameInfoButton);
            this.Controls.Add(this.gamesButton);
            this.Controls.Add(this.calendarButton);
            this.Controls.Add(this.coachesButton);
            this.Controls.Add(this.rosterButton);
            this.Controls.Add(this.dashboardButton);
            this.Controls.Add(this.exitButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "matchesForm";
            this.Text = "matchesForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button gamesButton;
        private System.Windows.Forms.Button calendarButton;
        private System.Windows.Forms.Button coachesButton;
        private System.Windows.Forms.Button rosterButton;
        private System.Windows.Forms.Button dashboardButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearGameInfoButton;
        private System.Windows.Forms.Label gamesLabel;
        private System.Windows.Forms.ListBox gameInfo;
        private System.Windows.Forms.TextBox enterGameInfo;
        private System.Windows.Forms.Button addGameInfoButton;
    }
}