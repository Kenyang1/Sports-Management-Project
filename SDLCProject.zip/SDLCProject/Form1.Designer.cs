﻿namespace dashboard
{
    partial class dashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.updateAthleteButton = new System.Windows.Forms.Button();
            this.enterAthleteInfo = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.athleteInfo = new System.Windows.Forms.ListBox();
            this.weeklyAthlete = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // updateAthleteButton
            // 
            this.updateAthleteButton.Location = new System.Drawing.Point(169, 438);
            this.updateAthleteButton.Name = "updateAthleteButton";
            this.updateAthleteButton.Size = new System.Drawing.Size(75, 23);
            this.updateAthleteButton.TabIndex = 0;
            this.updateAthleteButton.Text = "Update";
            this.updateAthleteButton.UseVisualStyleBackColor = true;
            this.updateAthleteButton.Click += new System.EventHandler(this.updateAthleteButton_Click);
            // 
            // enterAthleteInfo
            // 
            this.enterAthleteInfo.Location = new System.Drawing.Point(158, 392);
            this.enterAthleteInfo.Name = "enterAthleteInfo";
            this.enterAthleteInfo.Size = new System.Drawing.Size(100, 20);
            this.enterAthleteInfo.TabIndex = 1;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(758, 12);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(50, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "X";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // athleteInfo
            // 
            this.athleteInfo.FormattingEnabled = true;
            this.athleteInfo.Location = new System.Drawing.Point(138, 268);
            this.athleteInfo.Name = "athleteInfo";
            this.athleteInfo.Size = new System.Drawing.Size(146, 82);
            this.athleteInfo.TabIndex = 3;
            // 
            // weeklyAthlete
            // 
            this.weeklyAthlete.AutoSize = true;
            this.weeklyAthlete.BackColor = System.Drawing.Color.White;
            this.weeklyAthlete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weeklyAthlete.Location = new System.Drawing.Point(134, 221);
            this.weeklyAthlete.Name = "weeklyAthlete";
            this.weeklyAthlete.Size = new System.Drawing.Size(150, 20);
            this.weeklyAthlete.TabIndex = 4;
            this.weeklyAthlete.Text = "Athlete of the Week";
            // 
            // dashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(820, 518);
            this.Controls.Add(this.weeklyAthlete);
            this.Controls.Add(this.athleteInfo);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.enterAthleteInfo);
            this.Controls.Add(this.updateAthleteButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "dashboardForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button updateAthleteButton;
        private System.Windows.Forms.TextBox enterAthleteInfo;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox athleteInfo;
        private System.Windows.Forms.Label weeklyAthlete;
    }
}

