﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dashboard
{
    public partial class matchesForm : Form
    {
        public matchesForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void addGameInfoButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(enterGameInfo.Text) && !gameInfo.Items.Contains(enterGameInfo.Text))
                gameInfo.Items.Add(enterGameInfo.Text);
        }

        private void clearGameInfoButton_Click(object sender, EventArgs e)
        {
            // Check if the entered text is in the list
            if (!string.IsNullOrWhiteSpace(enterGameInfo.Text) && gameInfo.Items.Contains(enterGameInfo.Text))
            {
                // Remove the entered text from the list
                gameInfo.Items.Remove(enterGameInfo.Text);
            }
            // Alternatively, if no specific text is entered, you could clear the selected item
            else if (gameInfo.SelectedItem != null)
            {
                gameInfo.Items.Remove(gameInfo.SelectedItem);
            }
        }

        private void dashboardButton_Click(object sender, EventArgs e)
        {
            // Instantiate the matchesForm
            dashboardForm newDashboardForm = new dashboardForm();


            // Show the matchesForm as a non-modal window
            newDashboardForm.Show();

            this.Hide();
        }
    }
}
