﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace matchInfoPage
{
    public partial class EventForm : Form
    {
        public EventForm()
        {
            InitializeComponent();

            // Initialize SQLite library
            SQLitePCL.Batteries.Init();

            // Ensure the database and table exist
            InitializeDatabase();

            btnsave.Click += btnsave_Click; // Ensure Click event is connected
        }

        private void EventForm_Load(object sender, EventArgs e)
        {
            // Populate txtdate with selected date information
            txtdate.Text = $"{Form1.static_year}-{Form1.static_month:D2}-{UserControlDays.static_day:D2}";
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!DateTime.TryParse(txtdate.Text, out DateTime eventDate))
                {
                    MessageBox.Show("Please enter a valid date in the format YYYY-MM-DD.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtevent.Text))
                {
                    MessageBox.Show("Please enter the event details.");
                    return;
                }

                using (SQLiteConnection conn = new SQLiteConnection("Data Source=CalendarDatabase.db"))
                {
                    conn.Open();

                    // Use INSERT OR REPLACE to handle unique events per date
                    string query = "INSERT OR REPLACE INTO Calendar (Date, EventInfo) VALUES (@date, @event)";
                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@date", eventDate.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@event", txtevent.Text);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Event saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void InitializeDatabase()
        {
            try
            {
                using (SQLiteConnection conn = new SQLiteConnection("Data Source=CalendarDatabase.db"))
                {
                    conn.Open();

                    // Create the Calendar table if it does not exist
                    string createTableQuery = @"
                        CREATE TABLE IF NOT EXISTS Calendar (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            Date TEXT NOT NULL UNIQUE, -- Ensure Date is unique
                            EventInfo TEXT NOT NULL
                        )";

                    using (SQLiteCommand cmd = new SQLiteCommand(createTableQuery, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing database: {ex.Message}");
            }
        }
        private void txtevent_TextChanged(object sender, EventArgs e)
        {
        }
    }
}




   