﻿namespace SportsManagementUPDATEDUI
{
    partial class Dashboardform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            test1 = new Label();
            dataGridView1 = new DataGridView();
            Date = new DataGridViewTextBoxColumn();
            Event = new DataGridViewTextBoxColumn();
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // test1
            // 
            test1.AutoSize = true;
            test1.Location = new Point(103, 116);
            test1.Name = "test1";
            test1.Size = new Size(251, 41);
            test1.TabIndex = 0;
            test1.Text = "Upcoming events";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Date, Event });
            dataGridView1.Location = new Point(103, 252);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 102;
            dataGridView1.Size = new Size(600, 375);
            dataGridView1.TabIndex = 1;
            // 
            // Date
            // 
            Date.HeaderText = "Date";
            Date.MinimumWidth = 12;
            Date.Name = "Date";
            Date.Width = 250;
            // 
            // Event
            // 
            Event.HeaderText = "Event";
            Event.MinimumWidth = 12;
            Event.Name = "Event";
            Event.Width = 250;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(1318, 141);
            label1.Name = "label1";
            label1.Size = new Size(281, 41);
            label1.TabIndex = 2;
            label1.Text = "Athlete of the Week";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(1332, 336);
            label2.Name = "label2";
            label2.Size = new Size(277, 41);
            label2.TabIndex = 3;
            label2.Text = "Enter info card here";
            // 
            // Dashboardform
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1893, 1349);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(test1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Dashboardform";
            Text = "Dashboardform";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label test1;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Date;
        private DataGridViewTextBoxColumn Event;
        private Label label1;
        private Label label2;
    }
}