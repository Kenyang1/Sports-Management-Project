﻿namespace SportsManagementUPDATEDUI
{
    internal class CalendarDatabase
    {
        public int Id { get; set; }  // Primary Key
        public DateTime Date { get; set; }  // Changed to DateTime type for dates
        public string? EventInfo { get; set; }  // Event details
    }
}
