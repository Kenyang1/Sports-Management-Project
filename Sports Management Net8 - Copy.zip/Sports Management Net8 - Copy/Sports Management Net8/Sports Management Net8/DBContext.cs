﻿/* Special thanks goes to Nick, he found the EntityFrameworkCore Microsoft docs
See: https://learn.microsoft.com/en-us/ef/core/get-started/overview/first-app?tabs=netcore-cli
Note: Our WinForms app targets the .NET Framework whereas the EntityFrameworkCore app 
      targets .NET. Microsoft, with their knack for naming products, created 3 
      versions of NET: .NET Framework, .NET Core, and .NET. The ".NET" is the latest 
      "tech" where as ".NET Framework" is the legacy version. Since trying to install 
      the latest EntityFrameworkCore failed due to incompatibilites, I frustratingly 
      installed version 2.0.0 (deprecated). Miraculously, it "worked". It should 
      serve well for our purposes.
      
      From some brief research, the line "optionsBuilder.UseSqlite("Data Source=team.db")"
      automatically specifies the connection string.
      See: https://learn.microsoft.com/en-us/ef/core/miscellaneous/connection-strings?tabs=dotnet-core-cli#winforms--wpf-applications
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

public class ProgDB : DbContext // DB connection
{
    public DbSet<Athlete> Athletes { get; set; } // athlete table
    public DbSet<Coach> Coachs { get; set; } // coach table

    // SQLite is the DB provider & create a .db file
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Data Source=team.db"); // .db file is inside "\bin\Debug"
    }
}