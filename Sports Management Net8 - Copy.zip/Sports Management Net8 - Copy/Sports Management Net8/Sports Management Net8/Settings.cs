﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class Settings : Form
    {
        private string _username;
        private string _name;
        private string _orgName;
        private string _profilePicturePath;

        public Settings(string username)
        {
            InitializeComponent();
            _username = username;
            LoadUserInfo();
        }

        private void LoadUserInfo()
        {
            string filePath = "LoginData.txt";

            if (!File.Exists(filePath))
            {
                MessageBox.Show($"File {filePath} does not exist. Loading default values.");
                SetDefaultValues();
                return;
            }

            string[] lines = File.ReadAllLines(filePath);
            MessageBox.Show($"Loading user data from file: {filePath}\nNumber of lines read from file: {lines.Length}");

            bool isUsernameFound = false;
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].StartsWith("Username: ") && lines[i].Substring(9).Trim() == _username)
                {
                    isUsernameFound = true;

                    _name = lines[i + 2].Substring(5).Trim();
                    _orgName = lines[i + 3].Substring(8).Trim();
                    _profilePicturePath = lines[i + 4].Substring(18).Trim();

                    // Display the values with labels
                    usernameLabel.Text = $"Username: {_username}";
                    nameLabel.Text = $"Name: {_name}";
                    orgNameLabel.Text = $"Organization Name: {_orgName}";

                    // Load profile picture if exists
                    if (File.Exists(_profilePicturePath))
                    {
                        profilePictureBox.Image = Image.FromFile(_profilePicturePath);
                    }
                    else
                    {
                        MessageBox.Show("Profile picture not found, using default.");
                        profilePictureBox.Image = null; // You can set a default image if desired
                    }
                    break;
                }
            }

            if (!isUsernameFound)
            {
                MessageBox.Show("User not found in the file.");
                SetDefaultValues();
            }
        }

        private void SetDefaultValues()
        {
            // Set default values if the username isn't found
            _username = "admin";
            _name = "administrator";
            _orgName = "snhu";

            // Display with the appropriate labels
            usernameLabel.Text = $"Username: {_username}";
            nameLabel.Text = $"Name: {_name}";
            orgNameLabel.Text = $"Organization Name: {_orgName}";

            profilePictureBox.Image = null; // Set to null or a default image if you have one
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_username) && string.IsNullOrEmpty(_name) && string.IsNullOrEmpty(_orgName))
            {
                MessageBox.Show("There is no data to change here.");
                return;
            }

            _name = nameLabel.Text.Substring(6).Trim(); // Extract the name from label
            _orgName = orgNameLabel.Text.Substring(18).Trim(); // Extract orgName from label

            if (!string.IsNullOrEmpty(_profilePicturePath))
            {
                using (StreamWriter sw = new StreamWriter("LoginData.txt", false))
                {
                    sw.WriteLine($"Username: {_username}");
                    sw.WriteLine($"Name: {_name}");
                    sw.WriteLine($"Organization Name: {_orgName}");
                    sw.WriteLine($"Profile Picture Path: {_profilePicturePath}");
                }
            }

            MessageBox.Show("Data Saved");
        }

        private void changePictureButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                _profilePicturePath = openFileDialog.FileName;
                profilePictureBox.Image = Image.FromFile(_profilePicturePath);
            }
        }

        private void Settings_Load(object sender, EventArgs e)
        {

        }
    }
}
