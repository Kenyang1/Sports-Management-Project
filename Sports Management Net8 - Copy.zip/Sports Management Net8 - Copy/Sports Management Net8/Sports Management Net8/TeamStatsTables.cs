﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sports_Management_Net8
{
    public partial class TeamStatsTables : Form
    {
        public TeamStatsTables()
        {
            InitializeComponent();
        }

        private StatsContext _statsContext;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this._statsContext = new StatsContext();

            this._statsContext.Database.EnsureCreated();

            this._statsContext.TeamStats.Load();

            this.teamStatsBindingSource.DataSource = _statsContext.TeamStats.Local.ToBindingList();
        }

        private void dataGridTeamStats_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);

            this._statsContext?.Dispose();
            this._statsContext = null;
        }
    }
}
