using matchInfoPage;
using SportsManagement_Dashboard;

namespace SportsManagementUPDATEDUI
{
    public partial class Form1 : Form
    {
        bool sideBarExpand;
        public static List<Control> statsControls = null;

        public Form1()
        {
            InitializeComponent();

            if (statsControls == null)
            {
                statsControls = new List<Control>();
            }

            // Add sample controls for testing
            statsControls.Add(new Label() { Name = "testLabel", Text = "Initial Text", Visible = false });
        }

        public void OpenNewForm()
        {
            Form1 form = new Form1();

            form.updateStatsLabels(Form1.statsControls);
        }

        public void loadForm(object Form)
        {
            if (this.mainPanel.Controls.Count > 0)
            {
                this.mainPanel.Controls.RemoveAt(0);
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.mainPanel.Controls.Add(f);
            this.mainPanel.Tag = f;
            f.Show();

        }

        public void updateStatsLabels(List<Control> controls)
        {
            foreach (Control c in controls) //"260", "4240", "1742"
            {
                if (c == null) continue;
                if (c.Name == "label12")
                {
                    c.Text = "260";
                }
                else if (c.Name == "label13")
                {
                    c.Text = "4240";
                }
                else if (c.Name == "label14")
                {
                    c.Text = "1742";
                }
            }
        }

        public void loadStatsForm(object Form)
        {
            if (this.mainPanel.Controls.Count > 0)
            {
                this.mainPanel.Controls.RemoveAt(0);
            }
            Form fS = Form as Form;
            fS.TopLevel = false;
            fS.Dock = DockStyle.Fill;
            this.mainPanel.Controls.Add(fS);
            this.mainPanel.Tag = fS;
            fS.Show();
            foreach(Control control in fS.Controls)
            {
                statsControls.Add(control);
            }

        }

       

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sideBarExpand)
            {
                sidebar.Width -= 10;
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sideBarExpand = false;
                    sidebarTimer.Stop();

                }
            }
            else
            {
                sidebar.Width += 10;
                if (sidebar.Width == sidebar.MaximumSize.Width)
                {
                    sideBarExpand = true;
                    sidebarTimer.Stop();
                }
            }
        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            //set timer interval to lowest to make it smoothe
            sidebarTimer.Start();
        }

        private void dashboardBtn_Click(object sender, EventArgs e)
        {
            loadForm(new Dashboard());
        }

        private void playerBtn_Click(object sender, EventArgs e)
        {
            loadForm(new AthleteRoster());
        }

        private void coachBtn_Click(object sender, EventArgs e)
        {
            loadForm(new CoachRoster());
        }

        private void statsBtn_Click(object sender, EventArgs e)
        {
            loadStatsForm(new StatsPage());
        }

        private void aboutBtn_Click(object sender, EventArgs e)
        {
            //loadForm(new Aboutform());
        }

        private void calendarBtn_Click(object sender, EventArgs e)
        {
            Calendar calendar = new Calendar();
            calendar.Show();
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            // loadForm(new Settingsform());
        }
    }
}
