﻿namespace SportsManagement_Dashboard
{
    partial class AthleteRoster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            label1 = new Label();
            listBox1 = new ListBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Font = new Font("Microsoft Sans Serif", 11F);
            button2.Location = new Point(621, 400);
            button2.Margin = new Padding(2);
            button2.Name = "button2";
            button2.Size = new Size(131, 42);
            button2.TabIndex = 31;
            button2.Text = "Delete athlete";
            button2.UseVisualStyleBackColor = true;
            button2.Click += del_ath;
            // 
            // button1
            // 
            button1.Font = new Font("Microsoft Sans Serif", 11F);
            button1.Location = new Point(507, 400);
            button1.Margin = new Padding(2);
            button1.Name = "button1";
            button1.Size = new Size(110, 42);
            button1.TabIndex = 30;
            button1.Text = "Add athlete";
            button1.TextImageRelation = TextImageRelation.TextAboveImage;
            button1.UseVisualStyleBackColor = true;
            button1.Click += add_ath;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 10F);
            label1.Location = new Point(11, 414);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(87, 17);
            label1.TabIndex = 29;
            label1.Text = "Roster size: ";
            // 
            // listBox1
            // 
            listBox1.Font = new Font("Consolas", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox1.FormattingEnabled = true;
            listBox1.HorizontalScrollbar = true;
            listBox1.ItemHeight = 17;
            listBox1.Location = new Point(13, 36);
            listBox1.Margin = new Padding(2);
            listBox1.Name = "listBox1";
            listBox1.ScrollAlwaysVisible = true;
            listBox1.Size = new Size(748, 344);
            listBox1.TabIndex = 28;
            listBox1.DoubleClick += edit_ath;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Consolas", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(14, 10);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(344, 18);
            label2.TabIndex = 32;
            label2.Text = "#.  First Name  Last Name  Age  Position  ";
            // 
            // AthleteRoster
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(763, 453);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(listBox1);
            Margin = new Padding(2);
            Name = "AthleteRoster";
            Text = "AthleteRoster";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label2;
    }
}