﻿using Microsoft.EntityFrameworkCore;

namespace SportsManagementUPDATEDUI
{
    internal class CalendarDatabaseContext : DbContext
    {
        public DbSet<CalendarDatabase> Calendar { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=CalendarDatabase.db");
        }
    }
}
