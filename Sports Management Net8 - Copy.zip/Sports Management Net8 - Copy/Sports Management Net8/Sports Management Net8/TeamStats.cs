﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sports_Management_Net8
{
    public class TeamStats
    {
        public int StatId { get; set; }
        public string? StatName { get; set; }
        public int Stat {  get; set; }
    }
}
