﻿namespace SportsManagement_Dashboard
{
    partial class Calendar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            LBDATE = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            dayContainer = new FlowLayoutPanel();
            panel1 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            panel8 = new Panel();
            panel9 = new Panel();
            panel10 = new Panel();
            panel11 = new Panel();
            panel12 = new Panel();
            panel13 = new Panel();
            panel14 = new Panel();
            panel15 = new Panel();
            panel16 = new Panel();
            panel17 = new Panel();
            panel18 = new Panel();
            panel19 = new Panel();
            panel20 = new Panel();
            panel21 = new Panel();
            panel22 = new Panel();
            panel23 = new Panel();
            panel24 = new Panel();
            panel25 = new Panel();
            panel26 = new Panel();
            panel27 = new Panel();
            panel28 = new Panel();
            panel29 = new Panel();
            panel30 = new Panel();
            panel31 = new Panel();
            panel32 = new Panel();
            panel33 = new Panel();
            panel34 = new Panel();
            panel35 = new Panel();
            btnPrevious = new Button();
            btnNext = new Button();
            dayContainer.SuspendLayout();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold);
            label2.Location = new Point(465, 92);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(143, 40);
            label2.TabIndex = 2;
            label2.Text = "Monday";
            // 
            // LBDATE
            // 
            LBDATE.AutoSize = true;
            LBDATE.Font = new Font("MingLiU_HKSCS-ExtB", 15.9F, FontStyle.Bold);
            LBDATE.Location = new Point(1009, 23);
            LBDATE.Margin = new Padding(6, 0, 6, 0);
            LBDATE.Name = "LBDATE";
            LBDATE.Size = new Size(331, 53);
            LBDATE.TabIndex = 3;
            LBDATE.Text = "Month, YEAR";
            LBDATE.TextAlign = ContentAlignment.TopCenter;
            LBDATE.Click += LBDATE_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold);
            label7.Location = new Point(130, 90);
            label7.Margin = new Padding(6, 0, 6, 0);
            label7.Name = "label7";
            label7.Size = new Size(143, 40);
            label7.TabIndex = 13;
            label7.Text = "Sunday";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold);
            label6.Location = new Point(2108, 92);
            label6.Margin = new Padding(6, 0, 6, 0);
            label6.Name = "label6";
            label6.Size = new Size(185, 40);
            label6.TabIndex = 12;
            label6.Text = "Saturday";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold);
            label5.Location = new Point(1779, 90);
            label5.Margin = new Padding(6, 0, 6, 0);
            label5.Name = "label5";
            label5.Size = new Size(143, 40);
            label5.TabIndex = 11;
            label5.Text = "Friday";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold);
            label4.Location = new Point(1428, 90);
            label4.Margin = new Padding(6, 0, 6, 0);
            label4.Name = "label4";
            label4.Size = new Size(185, 40);
            label4.TabIndex = 10;
            label4.Text = "Thursday";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold);
            label3.Location = new Point(1088, 92);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(206, 40);
            label3.TabIndex = 9;
            label3.Text = "Wednseday";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold);
            label1.Location = new Point(774, 92);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(164, 40);
            label1.TabIndex = 8;
            label1.Text = "Tuesday";
            // 
            // dayContainer
            // 
            dayContainer.Controls.Add(panel1);
            dayContainer.Controls.Add(panel2);
            dayContainer.Controls.Add(panel3);
            dayContainer.Controls.Add(panel4);
            dayContainer.Controls.Add(panel5);
            dayContainer.Controls.Add(panel6);
            dayContainer.Controls.Add(panel7);
            dayContainer.Controls.Add(panel8);
            dayContainer.Controls.Add(panel9);
            dayContainer.Controls.Add(panel10);
            dayContainer.Controls.Add(panel11);
            dayContainer.Controls.Add(panel12);
            dayContainer.Controls.Add(panel13);
            dayContainer.Controls.Add(panel14);
            dayContainer.Controls.Add(panel15);
            dayContainer.Controls.Add(panel16);
            dayContainer.Controls.Add(panel17);
            dayContainer.Controls.Add(panel18);
            dayContainer.Controls.Add(panel19);
            dayContainer.Controls.Add(panel20);
            dayContainer.Controls.Add(panel21);
            dayContainer.Controls.Add(panel22);
            dayContainer.Controls.Add(panel23);
            dayContainer.Controls.Add(panel24);
            dayContainer.Controls.Add(panel25);
            dayContainer.Controls.Add(panel26);
            dayContainer.Controls.Add(panel27);
            dayContainer.Controls.Add(panel28);
            dayContainer.Controls.Add(panel29);
            dayContainer.Controls.Add(panel30);
            dayContainer.Controls.Add(panel31);
            dayContainer.Controls.Add(panel32);
            dayContainer.Controls.Add(panel33);
            dayContainer.Controls.Add(panel34);
            dayContainer.Controls.Add(panel35);
            dayContainer.Location = new Point(32, 153);
            dayContainer.Margin = new Padding(2, 3, 2, 3);
            dayContainer.Name = "dayContainer";
            dayContainer.Size = new Size(2363, 1668);
            dayContainer.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Location = new Point(6, 8);
            panel1.Margin = new Padding(6, 8, 6, 8);
            panel1.Name = "panel1";
            panel1.Size = new Size(323, 316);
            panel1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.Location = new Point(341, 8);
            panel2.Margin = new Padding(6, 8, 6, 8);
            panel2.Name = "panel2";
            panel2.Size = new Size(323, 316);
            panel2.TabIndex = 1;
            // 
            // panel3
            // 
            panel3.Location = new Point(676, 8);
            panel3.Margin = new Padding(6, 8, 6, 8);
            panel3.Name = "panel3";
            panel3.Size = new Size(323, 316);
            panel3.TabIndex = 2;
            // 
            // panel4
            // 
            panel4.Location = new Point(1011, 8);
            panel4.Margin = new Padding(6, 8, 6, 8);
            panel4.Name = "panel4";
            panel4.Size = new Size(323, 316);
            panel4.TabIndex = 3;
            // 
            // panel5
            // 
            panel5.Location = new Point(1346, 8);
            panel5.Margin = new Padding(6, 8, 6, 8);
            panel5.Name = "panel5";
            panel5.Size = new Size(323, 316);
            panel5.TabIndex = 4;
            // 
            // panel6
            // 
            panel6.Location = new Point(1681, 8);
            panel6.Margin = new Padding(6, 8, 6, 8);
            panel6.Name = "panel6";
            panel6.Size = new Size(323, 316);
            panel6.TabIndex = 5;
            // 
            // panel7
            // 
            panel7.Location = new Point(2016, 8);
            panel7.Margin = new Padding(6, 8, 6, 8);
            panel7.Name = "panel7";
            panel7.Size = new Size(323, 316);
            panel7.TabIndex = 6;
            // 
            // panel8
            // 
            panel8.Location = new Point(6, 340);
            panel8.Margin = new Padding(6, 8, 6, 8);
            panel8.Name = "panel8";
            panel8.Size = new Size(323, 316);
            panel8.TabIndex = 7;
            // 
            // panel9
            // 
            panel9.Location = new Point(341, 340);
            panel9.Margin = new Padding(6, 8, 6, 8);
            panel9.Name = "panel9";
            panel9.Size = new Size(323, 316);
            panel9.TabIndex = 8;
            // 
            // panel10
            // 
            panel10.Location = new Point(676, 340);
            panel10.Margin = new Padding(6, 8, 6, 8);
            panel10.Name = "panel10";
            panel10.Size = new Size(323, 316);
            panel10.TabIndex = 9;
            // 
            // panel11
            // 
            panel11.Location = new Point(1011, 340);
            panel11.Margin = new Padding(6, 8, 6, 8);
            panel11.Name = "panel11";
            panel11.Size = new Size(323, 316);
            panel11.TabIndex = 10;
            // 
            // panel12
            // 
            panel12.Location = new Point(1346, 340);
            panel12.Margin = new Padding(6, 8, 6, 8);
            panel12.Name = "panel12";
            panel12.Size = new Size(323, 316);
            panel12.TabIndex = 11;
            // 
            // panel13
            // 
            panel13.Location = new Point(1681, 340);
            panel13.Margin = new Padding(6, 8, 6, 8);
            panel13.Name = "panel13";
            panel13.Size = new Size(323, 316);
            panel13.TabIndex = 12;
            // 
            // panel14
            // 
            panel14.Location = new Point(2016, 340);
            panel14.Margin = new Padding(6, 8, 6, 8);
            panel14.Name = "panel14";
            panel14.Size = new Size(323, 316);
            panel14.TabIndex = 13;
            // 
            // panel15
            // 
            panel15.Location = new Point(6, 672);
            panel15.Margin = new Padding(6, 8, 6, 8);
            panel15.Name = "panel15";
            panel15.Size = new Size(323, 316);
            panel15.TabIndex = 14;
            // 
            // panel16
            // 
            panel16.Location = new Point(341, 672);
            panel16.Margin = new Padding(6, 8, 6, 8);
            panel16.Name = "panel16";
            panel16.Size = new Size(323, 316);
            panel16.TabIndex = 15;
            // 
            // panel17
            // 
            panel17.Location = new Point(676, 672);
            panel17.Margin = new Padding(6, 8, 6, 8);
            panel17.Name = "panel17";
            panel17.Size = new Size(323, 316);
            panel17.TabIndex = 16;
            // 
            // panel18
            // 
            panel18.Location = new Point(1011, 672);
            panel18.Margin = new Padding(6, 8, 6, 8);
            panel18.Name = "panel18";
            panel18.Size = new Size(323, 316);
            panel18.TabIndex = 17;
            // 
            // panel19
            // 
            panel19.Location = new Point(1346, 672);
            panel19.Margin = new Padding(6, 8, 6, 8);
            panel19.Name = "panel19";
            panel19.Size = new Size(323, 316);
            panel19.TabIndex = 18;
            // 
            // panel20
            // 
            panel20.Location = new Point(1681, 672);
            panel20.Margin = new Padding(6, 8, 6, 8);
            panel20.Name = "panel20";
            panel20.Size = new Size(323, 316);
            panel20.TabIndex = 19;
            // 
            // panel21
            // 
            panel21.Location = new Point(2016, 672);
            panel21.Margin = new Padding(6, 8, 6, 8);
            panel21.Name = "panel21";
            panel21.Size = new Size(323, 316);
            panel21.TabIndex = 20;
            // 
            // panel22
            // 
            panel22.Location = new Point(6, 1004);
            panel22.Margin = new Padding(6, 8, 6, 8);
            panel22.Name = "panel22";
            panel22.Size = new Size(323, 316);
            panel22.TabIndex = 21;
            // 
            // panel23
            // 
            panel23.Location = new Point(341, 1004);
            panel23.Margin = new Padding(6, 8, 6, 8);
            panel23.Name = "panel23";
            panel23.Size = new Size(323, 316);
            panel23.TabIndex = 22;
            // 
            // panel24
            // 
            panel24.Location = new Point(676, 1004);
            panel24.Margin = new Padding(6, 8, 6, 8);
            panel24.Name = "panel24";
            panel24.Size = new Size(323, 316);
            panel24.TabIndex = 23;
            // 
            // panel25
            // 
            panel25.Location = new Point(1011, 1004);
            panel25.Margin = new Padding(6, 8, 6, 8);
            panel25.Name = "panel25";
            panel25.Size = new Size(323, 316);
            panel25.TabIndex = 24;
            // 
            // panel26
            // 
            panel26.Location = new Point(1346, 1004);
            panel26.Margin = new Padding(6, 8, 6, 8);
            panel26.Name = "panel26";
            panel26.Size = new Size(323, 316);
            panel26.TabIndex = 25;
            // 
            // panel27
            // 
            panel27.Location = new Point(1681, 1004);
            panel27.Margin = new Padding(6, 8, 6, 8);
            panel27.Name = "panel27";
            panel27.Size = new Size(323, 316);
            panel27.TabIndex = 26;
            // 
            // panel28
            // 
            panel28.Location = new Point(2016, 1004);
            panel28.Margin = new Padding(6, 8, 6, 8);
            panel28.Name = "panel28";
            panel28.Size = new Size(323, 316);
            panel28.TabIndex = 27;
            // 
            // panel29
            // 
            panel29.Location = new Point(6, 1336);
            panel29.Margin = new Padding(6, 8, 6, 8);
            panel29.Name = "panel29";
            panel29.Size = new Size(323, 316);
            panel29.TabIndex = 28;
            // 
            // panel30
            // 
            panel30.Location = new Point(341, 1336);
            panel30.Margin = new Padding(6, 8, 6, 8);
            panel30.Name = "panel30";
            panel30.Size = new Size(323, 316);
            panel30.TabIndex = 29;
            // 
            // panel31
            // 
            panel31.Location = new Point(676, 1336);
            panel31.Margin = new Padding(6, 8, 6, 8);
            panel31.Name = "panel31";
            panel31.Size = new Size(323, 316);
            panel31.TabIndex = 30;
            // 
            // panel32
            // 
            panel32.Location = new Point(1011, 1336);
            panel32.Margin = new Padding(6, 8, 6, 8);
            panel32.Name = "panel32";
            panel32.Size = new Size(323, 316);
            panel32.TabIndex = 31;
            // 
            // panel33
            // 
            panel33.Location = new Point(1346, 1336);
            panel33.Margin = new Padding(6, 8, 6, 8);
            panel33.Name = "panel33";
            panel33.Size = new Size(323, 316);
            panel33.TabIndex = 32;
            // 
            // panel34
            // 
            panel34.Location = new Point(1681, 1336);
            panel34.Margin = new Padding(6, 8, 6, 8);
            panel34.Name = "panel34";
            panel34.Size = new Size(323, 316);
            panel34.TabIndex = 33;
            // 
            // panel35
            // 
            panel35.Location = new Point(2016, 1336);
            panel35.Margin = new Padding(6, 8, 6, 8);
            panel35.Name = "panel35";
            panel35.Size = new Size(323, 316);
            panel35.TabIndex = 34;
            // 
            // btnPrevious
            // 
            btnPrevious.Font = new Font("Segoe UI", 9F);
            btnPrevious.Location = new Point(1834, 1846);
            btnPrevious.Margin = new Padding(6, 8, 6, 8);
            btnPrevious.Name = "btnPrevious";
            btnPrevious.Size = new Size(183, 95);
            btnPrevious.TabIndex = 14;
            btnPrevious.Text = "Previous";
            btnPrevious.UseVisualStyleBackColor = true;
            btnPrevious.Click += btnPrevious_Click_1;
            // 
            // btnNext
            // 
            btnNext.Font = new Font("Segoe UI", 9F);
            btnNext.Location = new Point(2067, 1846);
            btnNext.Margin = new Padding(6, 8, 6, 8);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(200, 95);
            btnNext.TabIndex = 15;
            btnNext.Text = "Next";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click_1;
            // 
            // Calendar
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(2406, 2032);
            Controls.Add(btnNext);
            Controls.Add(btnPrevious);
            Controls.Add(dayContainer);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(LBDATE);
            Controls.Add(label2);
            Margin = new Padding(6, 8, 6, 8);
            Name = "Calendar";
            Text = "Calendar";
            dayContainer.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LBDATE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel dayContainer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
    }
}