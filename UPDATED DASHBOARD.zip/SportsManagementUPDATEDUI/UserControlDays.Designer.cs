﻿namespace SportsManagement_Dashboard
{
    partial class UserControlDays
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbday = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbday
            // 
            this.lbday.AutoSize = true;
            this.lbday.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Bold);
            this.lbday.Location = new System.Drawing.Point(101, 21);
            this.lbday.Name = "lbday";
            this.lbday.Size = new System.Drawing.Size(31, 20);
            this.lbday.TabIndex = 0;
            this.lbday.Text = "00";
            this.lbday.Click += new System.EventHandler(this.lbday_Click);
            // 
            // UserControlDays
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lbday);
            this.Name = "UserControlDays";
            this.Load += new System.EventHandler(this.UserControlDays_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbday;
    }
}
