USE DashboardInfoTrial;  -- Ensure you are using the correct database
GO
CREATE TABLE AthleteOfWeekTable
(
 fullName varchar(100)NOT NULL,
 athleteID nchar(10)NOT NULL,
 gradeYear nchar(5) NULL,
 athletePosition varchar(50) NULL,
 Achievements varchar(500) NULL,
 ProfileImagePath varchar(255) NULL,
 DateSelected date NULL, 
 PRIMARY KEY (athleteID)
)

USE DashboardInfoTrial;  -- Ensure you are using the correct database
GO
CREATE TABLE UpcomingEventsTable
(
    eventType varchar(100) NOT NULL,
    eventID nchar(10) NOT NULL,
    eventDate date NULL,
    eventLength varchar(50) NULL,
    eventDescription varchar(500) NULL,
    PRIMARY KEY (eventID)
);

SELECT TABLE_SCHEMA, TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_CATALOG = 'DashboardInfoTrial';


DROP TABLE IF EXISTS AthleteOfWeekTable;
DROP TABLE IF EXISTS UpcomingEventsTable;
