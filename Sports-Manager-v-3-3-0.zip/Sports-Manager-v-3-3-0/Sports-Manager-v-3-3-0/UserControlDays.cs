﻿using SportsManagement_Dashboard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class UserControlDays : UserControl
    {
        public static string static_day;
        public UserControlDays()
        {
            InitializeComponent();
        }

        private void UserControlDays_Load(object sender, EventArgs e)
        {

        }
        public void days(int numday)
        {
            lbday.Text = numday.ToString();
        }

        private void UserControlDays_Click(object sender, EventArgs e)
        {
            static_day = lbday.Text;
            EventForm eventForm = new EventForm();
            eventForm.Show();
        }

        private void lbday_Click(object sender, EventArgs e)
        {

        }

        private void UserControlDays_Load_1(object sender, EventArgs e)
        {

        }
    }
}
