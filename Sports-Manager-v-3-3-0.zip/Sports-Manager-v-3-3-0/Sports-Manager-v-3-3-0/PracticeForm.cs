﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class PracticeForm : Form
    {
        //Declaring variables

        AttendanceTracking attendanceTracking = new AttendanceTracking();
        List<Panel> playerTemplates = new List<Panel>(); 

        public PracticeForm()
        {
            InitializeComponent();

            //Create all player templates in the panel
            playerTemplates = attendanceTracking.CreatePlayerTemplates(5);
            Panel mainPanel = new Panel();
            mainPanel.SetBounds(10, 5, 375, 634);
            mainPanel.Visible = true;
            mainPanel.AutoScroll = true;
            mainPanel.AutoSize = true;
            foreach (Panel p in playerTemplates)
            {
                mainPanel.Controls.Add(p);
            }
            this.Controls.Add(mainPanel);

        }

        private void PresentCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            //Save data via player somewhere??
            //Need to create class that creates panels based on players saved data


        }

        private void PracticeForm_Load(object sender, EventArgs e)
        {

        }
    }
}
