﻿using System;
using System.Data.SqlClient; // For MSSQL database connection
using System.Windows.Forms;

namespace matchInfoPage
{
    public partial class EventForm : Form
    {
        // Updated connection string
        private readonly string connString = @"Data Source=.\SQLEXPRESS02;Initial Catalog=forum2024;Integrated Security=True;Encrypt=False";

        public EventForm()
        {
            InitializeComponent();
        }

        private void EventForm_Load(object sender, EventArgs e)
        {
            // Populate txtdate with selected date information
            txtdate.Text = Form1.static_month + "/" + UserControlDays.static_day + "/" + Form1.static_year;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Button Clicked");

            using (SqlConnection conn = new SqlConnection(connString))
            {
                try
                {
                    // Validate and parse the date input
                    if (!DateTime.TryParse(txtdate.Text, out DateTime eventDate))
                    {
                        MessageBox.Show("Please enter a valid date in the format MM/DD/YYYY.");
                        return;
                    }

                    // Check if the event text is not empty
                    if (string.IsNullOrWhiteSpace(txtevent.Text))
                    {
                        MessageBox.Show("Please enter the event details.");
                        return;
                    }

                    // SQL Insert query with parameters
                    string sql = "INSERT INTO calendar(date, event) VALUES (@date, @event)";
                    SqlCommand cmd = new SqlCommand(sql, conn);

                    // Assign parsed DateTime and event text to parameters
                    cmd.Parameters.AddWithValue("@date", eventDate);
                    cmd.Parameters.AddWithValue("@event", txtevent.Text);

                    // Open connection, execute query, and confirm save
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Saved successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
    }
}
