using System;
using System.Globalization;
using System.Windows.Forms;

namespace matchInfoPage
{
    public partial class Form1 : Form
    {
        private int month, year;
        public static int static_month, static_year;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Initialize month and year to the current date
            DateTime now = DateTime.Now;
            month = now.Month;
            year = now.Year;
            static_month = month;
            static_year = year;

            // Display the current month when the form loads
            displayDays();
        }

        private void displayDays()
        {
            dayContainer.Controls.Clear(); // Clear previous controls

            // Display month and year in label
            string monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            LBDATE.Text = $"{monthname} {year}";

            // First day of month
            DateTime startOfMonth = new DateTime(year, month, 1);
            int daysInMonth = DateTime.DaysInMonth(year, month);
            int dayOfWeek = (int)startOfMonth.DayOfWeek; // DayOfWeek as int (0=Sunday)

            // Add empty controls for days before the start of the month
            for (int i = 0; i < dayOfWeek; i++)
            {
                dayContainer.Controls.Add(new UserControlBlank());
            }

            // Add day controls for each day in the month
            for (int i = 1; i <= daysInMonth; i++)
            {
                UserControlDays dayControl = new UserControlDays();
                dayControl.days(i); // Set day number on the control
                dayContainer.Controls.Add(dayControl);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            month++;

            if (month > 12)
            {
                month = 1;
                year++;
            }

            static_month = month;
            static_year = year;
            displayDays();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            month--;

            if (month < 1)
            {
                month = 12;
                year--;
            }

            static_month = month;
            static_year = year;
            displayDays();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
