﻿namespace matchInfoPage
{
    partial class UserControlDays
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lbday = new Label();
            lbevent = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // lbday
            // 
            lbday.AutoSize = true;
            lbday.Font = new Font("MingLiU_HKSCS-ExtB", 12F, FontStyle.Bold);
            lbday.Location = new Point(214, 43);
            lbday.Name = "lbday";
            lbday.Size = new Size(59, 40);
            lbday.TabIndex = 1;
            lbday.Text = "00";
            // 
            // lbevent
            // 
            lbevent.Location = new Point(15, 127);
            lbevent.Name = "lbevent";
            lbevent.Size = new Size(292, 116);
            lbevent.TabIndex = 2;
            lbevent.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // UserControlDays
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(lbevent);
            Controls.Add(lbday);
            Name = "UserControlDays";
            Size = new Size(323, 243);
            Click += UserControlDays_Click;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbday;
        private Label lbevent;
        private System.Windows.Forms.Timer timer1;
    }
}
