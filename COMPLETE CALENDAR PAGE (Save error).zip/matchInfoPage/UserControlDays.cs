﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace matchInfoPage
{
    public partial class UserControlDays : UserControl
    {
        String connString = "Data Source=.\\SQLEXPRESS02;Initial Catalog=forum2024;Integrated Security=True;Encrypt=False";
        public static string static_day;

        public UserControlDays()
        {
            InitializeComponent();
            this.Click += UserControlDays_Click; // Ensure click event is attached to UserControlDays
            lbday.Click += lbday_Click;          // Add click event for lbday
            this.Load += UserControlDays_Load;   // Register the Load event
        }

        public void days(int numday)
        {
            lbday.Text = numday.ToString();
        }

        private void UserControlDays_Click(object sender, EventArgs e)
        {
            static_day = lbday.Text;
            timer1.Start();
            EventForm eventForm = new EventForm();
            eventForm.ShowDialog();
        }

        private void lbday_Click(object sender, EventArgs e)
        {
            // Redirect lbday click to UserControlDays_Click
            UserControlDays_Click(sender, e);
        }

        private void UserControlDays_Load(object sender, EventArgs e)
        {


        }

        //Display events
        private void displayEvent()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                // Updated SQL syntax with @date parameter
                String sql = "SELECT * FROM calendar WHERE date = @date";
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = sql;
                    // Added full date format as required for datetime fields
                    string formattedDate = $"{Form1.static_month}/{UserControlDays.static_day}/{DateTime.Now.Year}";
                    cmd.Parameters.AddWithValue("@date", formattedDate);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            lbevent.Text = reader["event"].ToString();
                        }
                    }
                }
            }
        }

        // Timer for auto display event
        private void timer1_Tick(object sender, EventArgs e)
        {
            displayEvent();
        }
    }
}