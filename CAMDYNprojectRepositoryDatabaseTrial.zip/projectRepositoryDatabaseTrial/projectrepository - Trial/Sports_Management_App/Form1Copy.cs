﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
using System.Configuration;

namespace SportsManagement_Dashboard
{
    public partial class Form1 : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,     // x-coordinate of upper-left corner
            int nTopRect,      // y-coordinate of upper-left corner
            int nRightRect,    // x-coordinate of lower-right corner
            int nBottomRect,   // y-coordinate of lower-right corner
            int nWidthEllipse, // width of ellipse
            int nHeightEllipse // height of ellipse
        );

        public Form1()
        {
            InitializeComponent();
            pnlNav.Height = btnDashboard.Height;
            pnlNav.Top = btnDashboard.Top;
            pnlNav.Left = btnDashboard.Left;
            btnDashboard.BackColor = Color.FromArgb(46, 51, 73);

        }

        private void LoadAthletes()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["AthleteDBConnection"].ConnectionString;
            string selectQuery = "SELECT fullName, Achievements FROM AthleteOfWeekTable"; // Select both fullName and Achievements

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    SqlDataReader reader = command.ExecuteReader();
                    athleteInfo.Items.Clear(); // Clear the ListBox before adding items

                    while (reader.Read())
                    {
                        string fullName = reader["fullName"].ToString();
                        string achievements = reader["Achievements"].ToString();
                        // Format the string to display both the name and achievements
                        string displayText = $"{fullName} - Achievements: {achievements}";
                        athleteInfo.Items.Add(displayText); // Add the formatted string to the ListBox
                    }
                }
            }
        }

        private void LoadEvents()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["AthleteDBConnection"].ConnectionString;
            string selectQuery = "SELECT eventType FROM UpcomingEventsTable"; // Adjust this to load the appropriate column

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    SqlDataReader reader = command.ExecuteReader();
                    upcomingEvents.Items.Clear(); // Clear the ListBox before adding items

                    while (reader.Read())
                    {
                        string eventType = reader["eventType"].ToString();
                        upcomingEvents.Items.Add(eventType); // Add each event's type to the ListBox
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadAthletes(); // Call the method to load athletes into the ListBox
            LoadEvents();   // Call the method to load events
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void userName_Label_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = coachbutton1.Height;
            pnlNav.Top = coachbutton1.Top;
            pnlNav.Left = coachbutton1.Left;
            coachbutton1.BackColor = Color.FromArgb(46, 51, 73);
            CoachRoster coachRoster = new CoachRoster();
            coachRoster.Show();
        }


        private void btnDashboard_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btnDashboard.Height;
            pnlNav.Top = btnDashboard.Top;
            pnlNav.Left = btnDashboard.Left;
            btnDashboard.BackColor = Color.FromArgb(46, 51, 73);
        }

        private void teambutton1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = teambutton1.Height;
            pnlNav.Top = teambutton1.Top;
            pnlNav.Left = teambutton1.Left;
            teambutton1.BackColor = Color.FromArgb(46, 51, 73);
            //AthleteRoster athleteRoster = new AthleteRoster();
            //athleteRoster.Show();
        }

        private void matchesbutton3_Click(object sender, EventArgs e)
        {
            pnlNav.Height = matchesbutton3.Height;
            pnlNav.Top = matchesbutton3.Top;
            pnlNav.Left = matchesbutton3.Left;
            matchesbutton3.BackColor = Color.FromArgb(46, 51, 73);
            // Instantiate the matchesForm
            matchesForm newMatchesForm = new matchesForm();


            // Show the matchesForm as a non-modal window
            newMatchesForm.Show();

            this.Hide();
        }

        private void statsbutton1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = statsbutton1.Height;
            pnlNav.Top = statsbutton1.Top;
            pnlNav.Left = statsbutton1.Left;
            statsbutton1.BackColor = Color.FromArgb(46, 51, 73);
        }

        private void settingsbutton1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = settingsbutton1.Height;
            pnlNav.Top = settingsbutton1.Top;
            pnlNav.Left = settingsbutton1.Left;
            settingsbutton1.BackColor = Color.FromArgb(46, 51, 73);
        }

        private void btnDashboard_Leave(object sender, EventArgs e)
        {
            btnDashboard.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void teambutton1_Leave(object sender, EventArgs e)
        {
            teambutton1.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void coachbutton1_Leave(object sender, EventArgs e)
        {
            coachbutton1.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void matchesbutton3_Leave(object sender, EventArgs e)
        {
            matchesbutton3.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void statsbutton1_Leave(object sender, EventArgs e)
        {
            statsbutton1.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void settingsbutton1_Leave(object sender, EventArgs e)
        {
            settingsbutton1.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void addAthleteInfoButton_Click(object sender, EventArgs e)
        {
            // Assuming you have TextBoxes for athlete's details
            string fullName = enterAthleteInfo.Text.Trim(); // Replace with actual TextBox for full name
            string athleteID = athleteIdTextBox.Text.Trim(); // TextBox for athlete ID
            string gradeYear = gradeYearTextBox.Text.Trim(); // TextBox for grade year
            string athletePosition = athletePositionTextBox.Text.Trim(); // TextBox for athlete position
            string achievements = achievementsTextBox.Text.Trim(); // TextBox for achievements
            string profileImagePath = profileImagePathTextBox.Text.Trim(); // TextBox for image path

            if (!string.IsNullOrWhiteSpace(fullName) && !string.IsNullOrWhiteSpace(athleteID))
            {
                // Insert data into the database
                string connectionString = ConfigurationManager.ConnectionStrings["AthleteDBConnection"].ConnectionString;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sqlQuery = "INSERT INTO AthleteOfWeekTable (fullName, athleteID, gradeYear, athletePosition, Achievements, ProfileImagePath, DateSelected) VALUES (@fullName, @athleteID, @gradeYear, @athletePosition, @Achievements, @ProfileImagePath, @DateSelected)";

                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        command.Parameters.AddWithValue("@fullName", fullName);
                        command.Parameters.AddWithValue("@athleteID", athleteID);
                        command.Parameters.AddWithValue("@gradeYear", gradeYear);
                        command.Parameters.AddWithValue("@athletePosition", athletePosition);
                        command.Parameters.AddWithValue("@Achievements", achievements);
                        command.Parameters.AddWithValue("@ProfileImagePath", profileImagePath);
                        command.Parameters.AddWithValue("@DateSelected", DateTime.Now);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"{rowsAffected} athlete(s) added successfully.");

                            // Add the athlete's full name and achievements to the athleteInfo ListBox
                            string displayText = $"{fullName} - Achievements: {achievements}";
                            athleteInfo.Items.Add(displayText); // Update this line to include achievements
                        }
                        else
                        {
                            MessageBox.Show("Failed to add athlete.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter valid information.");
            }
        }

        private void clearAthleteInfoButton_Click(object sender, EventArgs e)
        {
            // Check if an item is selected in the ListBox
            if (athleteInfo.SelectedItem != null)
            {
                string athleteInfoText = athleteInfo.SelectedItem.ToString(); // Get the selected athlete's name

                // Remove athlete from the ListBox
                athleteInfo.Items.Remove(athleteInfoText);

                // Delete data from SQL Server
                string connectionString = ConfigurationManager.ConnectionStrings["AthleteDBConnection"].ConnectionString;
                string deleteQuery = "DELETE FROM AthleteOfWeekTable WHERE fullName = @fullName";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@fullName", athleteInfoText);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Athlete information removed from the database.");
                    }
                }
            }
            else
            {
                // Show a message if no athlete is selected
                MessageBox.Show("Please select a valid athlete to remove.");
            }
        }

        private void addEventInfo_Click(object sender, EventArgs e)
        {
            // Assuming you have TextBoxes for event details like eventType, eventID, etc.
            string eventType = eventTypeTextBox.Text.Trim(); // TextBox for event type
            string eventID = eventIDTextBox.Text.Trim(); // TextBox for event ID
            DateTime eventDate = eventDatePicker.Value; // DateTimePicker for event date
            string eventLength = eventLengthTextBox.Text.Trim(); // TextBox for event length
            string eventDescription = eventDescriptionTextBox.Text.Trim(); // TextBox for event description

            if (!string.IsNullOrWhiteSpace(eventType) && !string.IsNullOrWhiteSpace(eventID))
            {
                // Insert event data into the UpcomingEventsTable
                string connectionString = ConfigurationManager.ConnectionStrings["AthleteDBConnection"].ConnectionString;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sqlQuery = "INSERT INTO UpcomingEventsTable (eventType, eventID, eventDate, eventLength, eventDescription) VALUES (@eventType, @eventID, @eventDate, @eventLength, @eventDescription)";

                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        command.Parameters.AddWithValue("@eventType", eventType);
                        command.Parameters.AddWithValue("@eventID", eventID);
                        command.Parameters.AddWithValue("@eventDate", eventDate);
                        command.Parameters.AddWithValue("@eventLength", eventLength);
                        command.Parameters.AddWithValue("@eventDescription", eventDescription);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"{rowsAffected} event(s) added successfully.");
                            upcomingEvents.Items.Add(eventType); // Add event to ListBox
                        }
                        else
                        {
                            MessageBox.Show("Failed to add event.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter valid event information.");
            }
        }

        private void clearEventInfo_Click(object sender, EventArgs e)
        {
            // Check if an item is selected in the ListBox
            if (upcomingEvents.SelectedItem != null)
            {
                string eventType = upcomingEvents.SelectedItem.ToString(); // Get the selected event's type

                // Remove event from the ListBox
                upcomingEvents.Items.Remove(eventType);

                // Delete event data from SQL Server
                string connectionString = ConfigurationManager.ConnectionStrings["AthleteDBConnection"].ConnectionString;
                string deleteQuery = "DELETE FROM UpcomingEventsTable WHERE eventType = @eventType";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@eventType", eventType);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Event information removed from the database.");
                    }
                }
            }
            else
            {
                // Show a message if no event is selected
                MessageBox.Show("Please select a valid event to remove.");
            }
        }
    }
}
