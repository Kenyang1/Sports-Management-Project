﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


//This whole form was added by Camdyn

namespace SportsManagement_Dashboard
{
    public partial class UpdateWeeklyAthleteForm : Form
    {
        public Form1 MyParentForm { get; set; }

        public UpdateWeeklyAthleteForm(Form1 ParentForm)
        {
            InitializeComponent();
            MyParentForm = ParentForm;
        }


        private void UpdateWeeklyAthleteForm_Load(object sender, EventArgs e)
        {
            LoadAthletesIntoAddComboBox();
            LoadAthletesIntoDeleteComboBox();
        }


        private void LoadAthletesIntoAddComboBox()
        {
            using (var context = new ProgDB())
            {
                // Get the list of athlete IDs that are already in the AthletesDisplay table
                var displayedAthleteIds = context.AthleteDisplays.Select(ad => ad.Id).ToList();


                var athletesToAdd = context.Athletes
                    .Where(a => !displayedAthleteIds.Contains(a.id))
                    .Select(a => new { a.id, FullName = a.first_name + " " + a.last_name })
                    .ToList();

                cmbAthletes.DataSource = athletesToAdd;
                cmbAthletes.DisplayMember = "FullName";
                cmbAthletes.ValueMember = "id";
                cmbAthletes.SelectedIndex = -1; // Ensure no default selection
            }


        }


        private void LoadAthletesIntoDeleteComboBox()
        {
            using (var context = new ProgDB())
            {
                var athletesToDelete = context.AthleteDisplays
                    .Select(a => new { a.Id, FullName = a.FirstName + " " + a.LastName })
                    .ToList();

                cmbDeleteAthlete.DataSource = athletesToDelete;
                cmbDeleteAthlete.DisplayMember = "FullName";
                cmbDeleteAthlete.ValueMember = "id";
                cmbDeleteAthlete.SelectedIndex = -1; // Ensure no default selection
            }

        }


        private void btnAddWeeklyAthleteInfo_Click(object sender, EventArgs e)
        {

            if (cmbAthletes.SelectedValue == null || string.IsNullOrWhiteSpace(txtAccomplishments.Text))
            {
                MessageBox.Show("Please select an athlete and enter accomplishments.");
                return;
            }

            int athleteId = (int)cmbAthletes.SelectedValue; // Get selected athlete ID
            string accomplishments = txtAccomplishments.Text;

            using (var context = new ProgDB())
            {
                var athlete = context.Athletes.FirstOrDefault(a => a.id == athleteId);

                if (athlete != null)
                {
                    //dont need this line its for error checking
                    Console.WriteLine($"Before Save: {athlete.accomplishments}"); // Log the current accomplishments value

                    athlete.accomplishments = accomplishments; // Set the new accomplishments

                    try
                    {
                        context.SaveChanges(); // Save changes to the database

                        MessageBox.Show("Accomplishments added successfully!");


                        if (MyParentForm != null)
                        {
                            MyParentForm.LoadSelectedAthleteData(athleteId);  // Pass the athleteId to refresh the data
                            MessageBox.Show($"Athlete ID: {athleteId}");
                        }


                        txtAccomplishments.Clear();
                        cmbAthletes.SelectedIndex = -1;
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error saving accomplishments: {ex.Message}");
                    }
                }
                else
                {
                    MessageBox.Show("Athlete not found.");
                }
            }

        }


        private void btnDeleteAthlete_Click(object sender, EventArgs e)
        {
            if (cmbDeleteAthlete.SelectedValue == null)
            {
                MessageBox.Show("Please select an athlete.");
                return;
            }

            int athleteToRemoveId = (int)cmbDeleteAthlete.SelectedValue; // Get selected athlete ID


            using (var context = new ProgDB())
            {
                var athlete = context.Athletes.FirstOrDefault(a => a.id == athleteToRemoveId);

                if (athlete != null)
                {
                    athlete.accomplishments = "No accomplishments added yet"; // Set the new accomplishments

                    try
                    {
                        context.SaveChanges(); // Save changes to the database

                        MessageBox.Show("Accomplishments removed successfully!");


                        if (MyParentForm != null)
                        {
                            MyParentForm.RemoveAthleteFromDataGridView(athleteToRemoveId);  // Pass the athleteId to refresh the data
                            MessageBox.Show($"Athlete ID: {athleteToRemoveId}");
                        }

                        cmbDeleteAthlete.SelectedIndex = -1;
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error removing accomplishments: {ex.Message}");
                    }
                }
                else
                {
                    MessageBox.Show("Athlete not found.");
                }

            }
        }




    }
}

