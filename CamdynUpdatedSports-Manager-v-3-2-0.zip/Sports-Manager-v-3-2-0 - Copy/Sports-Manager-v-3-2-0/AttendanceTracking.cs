﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public class AttendanceTracking
    {

        public AttendanceTracking()
        {

        }

        public List<Panel> CreatePlayerTemplates(int numPlayers)
        {
            List<Panel> playerTemplates = new List<Panel>();
            for (int i = 0; i < numPlayers; i++)
            {
                //Create pannel
                Panel p = new Panel();
                p.BackColor = Color.Gray;
                p.SetBounds(0, i * 150, 275, 125);

                ;               //Add Picture Box
                PictureBox playerPicture = new PictureBox();
                playerPicture.SetBounds(5, 5, 110, 120);
                p.Controls.Add(playerPicture);

                //Add Labels
                Label playerName = new Label();
                playerName.SetBounds(120, 15, 85, 15);
                playerName.Text = "Player Name";
                p.Controls.Add(playerName);

                Label playerNum = new Label();
                playerNum.SetBounds(120, 40, 85, 15);
                playerNum.Text = "Player Number";
                p.Controls.Add(playerNum);

                //Add Checkbox
                CheckBox presentCheckBox = new CheckBox();
                presentCheckBox.SetBounds(120, 75, 75, 20);
                presentCheckBox.Text = "Present";
                p.Controls.Add(presentCheckBox);

                //Add Panel to List
                playerTemplates.Add(p);
            }
            return playerTemplates;
        }



    }
}
