﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsManagement_Dashboard
{
    public partial class Ath_info_card : UserControl
    {
        private ProgDB context; // creates a new DB "session"
        private Athlete selection; // selected athlete
        public Ath_info_card()
        {
            InitializeComponent();
            context = new ProgDB();
            context.Database.EnsureCreated(); // verify that the DB exists
        }

        // populate the fields with the athlete's data upon selection
        public void fill_fields(Athlete athlete)
        {
            selection = athlete;
            textBox1.Text = athlete.first_name;
            textBox2.Text = athlete.last_name;
            numericUpDown1.Value = athlete.age;
            comboBox1.SelectedItem = athlete.position;
            numericUpDown2.Value = athlete.id;
        }

        private void Ath_info_card_Load(object sender, EventArgs e)
        {

        }

        private bool is_valid_ath(Athlete x)
        {
            return x.id != 0 && x.first_name != "" && x.last_name != "" && x.age > 0
                && x.position != "";
        }

        private void clr_flds_Click(object sender, EventArgs e)
        {
            const string empty_field = "";
            textBox1.Text = empty_field;
            textBox2.Text = empty_field;
            numericUpDown1.Value = 0;
            comboBox1.SelectedItem = "N/A";
        }

        private void save_Click(object sender, EventArgs e)
        {
            // create a new athlete from the text boxes' extracted values (bio data)
            var ath = new Athlete()
            {
                // id = context.Athletes.Max(x => x.id) + 1,
                id = ((int)numericUpDown2.Value),
                first_name = textBox1.Text.ToString(),
                last_name = textBox2.Text.ToString(),
                age = ((int)numericUpDown1.Value),
                position = comboBox1.Text.ToString()
            };
            // determine if the fields have been filled out, add the athlete if they are filled out
            if (is_valid_ath(ath))
            {
                context.Athletes.Add(ath); // add the newly created athlete to the athlete table
                context.SaveChanges(); // save the changes made to the DB after adding the athlete
            }
            else
            {
                MessageBox.Show("Error: all fields must be filled out.");
            }
        }

        private void cancle_Click(object sender, EventArgs e)
        {
            
        }
    }
}